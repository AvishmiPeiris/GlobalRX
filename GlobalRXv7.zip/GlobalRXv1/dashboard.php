<?php
session_start();

if (empty($_SESSION['signed_in']) || $_SESSION['signed_in'] !== true) {
    header('Location: signin.php');
    exit;
}

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');
$initial   = !empty($firstName) ? strtoupper($firstName[0]) : '?';
if (empty($fullName) && !empty($firstName)) $fullName = $firstName;

if ($role === 'admin' || $role === 'temp_admin') {
    header('Location: admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Dashboard — Global RX</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --red:#e63946;--green:#2d9c5f;--yellow:#f4c430;
  --dark:#0d0d0d;--offblack:#151515;--card:#1a1a1a;
  --border:#252525;--muted:#555;--text:#f0f0f0;--sub:#888;
}
body{font-family:'DM Sans',sans-serif;background:var(--dark);color:var(--text);min-height:100vh;}

/* NAV */
nav{
  position:fixed;top:0;left:0;right:0;
  background:rgba(13,13,13,0.95);backdrop-filter:blur(12px);
  border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;
  padding:14px 48px;z-index:999;
}
.nav-logo{font-size:1.1rem;font-weight:800;letter-spacing:1px;color:#fff;text-decoration:none;}
.nav-logo span{color:var(--red);}
.nav-links{display:flex;gap:28px;list-style:none;align-items:center;}
.nav-links a{text-decoration:none;color:#aaa;font-size:0.88rem;font-weight:500;transition:color .2s;}
.nav-links a:hover{color:#fff;}

/* Nav dropdown */
.nav-dropdown{position:relative;}
.nav-dropdown-toggle{display:flex;align-items:center;gap:5px;color:#aaa;font-size:0.88rem;font-weight:500;cursor:pointer;background:none;border:none;font-family:inherit;padding:0;transition:color .2s;}
.nav-dropdown-toggle:hover{color:#fff;}
.nav-dropdown-toggle .chevron{width:14px;height:14px;display:flex;align-items:center;justify-content:center;transition:transform .25s;}
.nav-dropdown-toggle .chevron svg{width:10px;height:10px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;}
.nav-dropdown.open .chevron{transform:rotate(180deg);}
.dropdown-menu{position:absolute;top:calc(100% + 14px);left:50%;background:#1e1e1e;border:1px solid var(--border);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.4);min-width:260px;padding:8px;opacity:0;pointer-events:none;transform:translateX(-50%) translateY(-6px);transition:opacity .2s,transform .2s;}
.nav-dropdown.open .dropdown-menu{opacity:1;pointer-events:all;transform:translateX(-50%) translateY(0);}
.dropdown-item{display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:9px;text-decoration:none;color:#ccc;font-size:0.88rem;font-weight:500;transition:background .15s,color .15s;}
.dropdown-item:hover{background:#2a2a2a;color:#fff;}
.dropdown-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
.dropdown-divider{height:1px;background:var(--border);margin:4px 8px;}

/* Nav user widget */
.nav-user{position:relative;}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #333;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#fff;transition:border-color .2s;font-family:inherit;}
.nav-user-toggle:hover{border-color:var(--red);}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0;}
.nav-user-name{font-size:14px;font-weight:600;color:#fff;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.nav-chevron{display:flex;align-items:center;}
.nav-chevron svg{width:10px;height:6px;stroke:#aaa;fill:none;stroke-width:2;transition:transform .25s;}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg);}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:260px;background:#1e1e1e;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.5);border:1px solid var(--border);padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000;}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all;}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px;}
.num-avatar-lg{width:44px;height:44px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:17px;color:#fff;flex-shrink:0;}
.num-info{flex:1;min-width:0;}
.num-name{font-size:13px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.num-email{font-size:11px;color:#666;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#2a2a2a;color:#888;font-size:10px;font-weight:700;border-radius:50px;}
.num-divider{height:1px;background:var(--border);margin:4px 0;}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#ccc;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit;}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#555;fill:currentColor;}
.num-item:hover{background:#252525;color:#fff;}
.num-logout{color:var(--red)!important;}
.num-logout svg{color:var(--red)!important;}
.num-logout:hover{background:#1f0a0a!important;}

/* LAYOUT */
.page-wrap{padding-top:72px;min-height:100vh;}
.dash-hero{
  background:linear-gradient(135deg,#0d0d0d 0%,#1a1a1a 100%);
  border-bottom:1px solid var(--border);
  padding:48px 60px 40px;
  position:relative;overflow:hidden;
}
.dash-hero::before{
  content:'DASHBOARD';
  position:absolute;right:-20px;top:50%;transform:translateY(-50%);
  font-family:'Playfair Display',Georgia,serif;
  font-size:clamp(4rem,10vw,8rem);font-weight:700;
  color:rgba(255,255,255,0.03);letter-spacing:4px;white-space:nowrap;pointer-events:none;
}
.dash-hero-inner{max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap;}
.dash-greeting{display:flex;align-items:center;gap:20px;}
.dash-avatar-lg{
  width:64px;height:64px;border-radius:50%;background:var(--red);
  display:flex;align-items:center;justify-content:center;
  font-family:'Playfair Display',Georgia,serif;font-size:26px;font-weight:700;color:#fff;
  box-shadow:0 0 0 3px rgba(230,57,70,0.25);
}
.dash-welcome{color:#aaa;font-size:0.8rem;font-weight:600;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px;}
.dash-name{font-family:'Playfair Display',Georgia,serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:700;color:#fff;line-height:1.2;}
.dash-email{font-size:0.82rem;color:#666;margin-top:4px;}
.dash-meta{display:flex;gap:12px;flex-wrap:wrap;}
.dash-tag{display:flex;align-items:center;gap:6px;background:#1e1e1e;border:1px solid var(--border);border-radius:50px;padding:6px 14px;font-size:0.78rem;font-weight:600;color:#aaa;}
.dash-tag-dot{width:6px;height:6px;border-radius:50%;background:var(--green);}

/* MAIN CONTENT */
.dash-content{max-width:1200px;margin:0 auto;padding:40px 60px 60px;}
.dash-grid{display:grid;grid-template-columns:1fr 340px;gap:28px;align-items:start;}

/* SECTION HEADERS */
.section-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
.section-head h2{font-family:'Playfair Display',Georgia,serif;font-size:1.2rem;font-weight:700;color:#fff;}
.section-head-line{display:flex;align-items:center;gap:10px;}
.section-head-line::before{content:'';width:3px;height:16px;background:var(--red);border-radius:2px;display:block;}
.badge-count{background:var(--red);color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:50px;}

/* APPLICATIONS PANEL */
.panel{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;}
.panel-header{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.panel-header h3{font-size:0.88rem;font-weight:700;color:#fff;letter-spacing:0.5px;}
.panel-body{padding:0;}

/* Application item */
.app-item{display:flex;align-items:center;gap:16px;padding:18px 24px;border-bottom:1px solid var(--border);transition:background .15s;cursor:default;}
.app-item:last-child{border-bottom:none;}
.app-item:hover{background:#1e1e1e;}
.app-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;}
.app-icon.red{background:rgba(230,57,70,0.12);}
.app-icon.green{background:rgba(45,156,95,0.12);}
.app-icon.yellow{background:rgba(244,196,48,0.12);}
.app-info{flex:1;min-width:0;}
.app-title{font-size:0.88rem;font-weight:600;color:#fff;margin-bottom:3px;}
.app-sub{font-size:0.75rem;color:#666;}
.app-status{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}
.status-pill{font-size:0.7rem;font-weight:700;padding:3px 10px;border-radius:50px;letter-spacing:0.5px;}
.status-pill.pending{background:rgba(244,196,48,0.15);color:var(--yellow);}
.status-pill.active{background:rgba(45,156,95,0.15);color:var(--green);}
.status-pill.review{background:rgba(230,57,70,0.15);color:var(--red);}
.app-date{font-size:0.7rem;color:#555;}

/* Empty state */
.empty-state{padding:48px 24px;text-align:center;}
.empty-icon{font-size:2.5rem;margin-bottom:12px;opacity:0.4;}
.empty-title{font-size:0.9rem;font-weight:600;color:#555;margin-bottom:6px;}
.empty-sub{font-size:0.78rem;color:#444;}

/* Loading state */
.loading-state{padding:32px 24px;}
.skeleton{background:linear-gradient(90deg,#1e1e1e 25%,#252525 50%,#1e1e1e 75%);background-size:200% 100%;animation:shimmer 1.4s infinite;border-radius:8px;}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
.skel-row{display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--border);}
.skel-row:last-child{border-bottom:none;}
.skel-circle{width:42px;height:42px;border-radius:10px;flex-shrink:0;}
.skel-lines{flex:1;}
.skel-line{height:10px;border-radius:4px;margin-bottom:6px;}
.skel-line.w70{width:70%;}
.skel-line.w45{width:45%;}

/* NOTIFICATIONS PANEL */
.notif-item{display:flex;align-items:flex-start;gap:14px;padding:16px 24px;border-bottom:1px solid var(--border);transition:background .15s;}
.notif-item:last-child{border-bottom:none;}
.notif-item:hover{background:#1e1e1e;}
.notif-item.unread{background:rgba(230,57,70,0.04);}
.notif-dot{width:8px;height:8px;border-radius:50%;background:var(--red);margin-top:5px;flex-shrink:0;}
.notif-dot.read{background:#333;}
.notif-body{flex:1;min-width:0;}
.notif-title{font-size:0.83rem;font-weight:600;color:#ddd;margin-bottom:3px;line-height:1.4;}
.notif-item.unread .notif-title{color:#fff;}
.notif-time{font-size:0.72rem;color:#555;}

/* Quick links */
.quick-links{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:20px;}
.quick-link{display:flex;flex-direction:column;align-items:flex-start;gap:6px;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;text-decoration:none;transition:border-color .2s,background .2s;}
.quick-link:hover{border-color:var(--red);background:#1e1e1e;}
.ql-icon{font-size:1.2rem;}
.ql-label{font-size:0.78rem;font-weight:600;color:#ccc;}
.ql-sub{font-size:0.7rem;color:#555;}

/* Stats row */
.stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:28px;}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px;display:flex;flex-direction:column;gap:6px;}
.stat-card-num{font-family:'Playfair Display',Georgia,serif;font-size:1.8rem;font-weight:700;color:#fff;line-height:1;}
.stat-card-label{font-size:0.7rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#555;}
.stat-card-sub{font-size:0.72rem;color:#444;margin-top:2px;}

/* FOOTER */
footer{background:#0a0a0a;border-top:1px solid var(--border);padding:24px 60px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
footer span{font-size:0.78rem;color:#444;}
.footer-dots{display:flex;gap:8px;}
.dot{width:8px;height:8px;border-radius:50%;}

@media(max-width:960px){
  .dash-content{padding:32px 24px 48px;}
  .dash-hero{padding:36px 24px 32px;}
  .dash-grid{grid-template-columns:1fr;}
  .stats-row{grid-template-columns:1fr 1fr;}
  footer{padding:20px 24px;}
}
@media(max-width:600px){
  nav{padding:14px 20px;}
  .nav-user-name{display:none;}
  .stats-row{grid-template-columns:1fr;}
  .quick-links{grid-template-columns:1fr;}
}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot" style="background:var(--red)"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.html" class="dropdown-item"><span class="dropdown-dot" style="background:var(--green)"></span>A-Squared Higher Education</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot" style="background:var(--yellow)"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.html">About Us</a></li>
    <li><a href="contactus.html">Contact Us</a></li>
  </ul>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        My Dashboard
      </a>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z" fill="currentColor"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z" fill="currentColor"/></svg>
        Log Out
      </a>
    </div>
  </div>
</nav>

<div class="page-wrap">

  <!-- HERO STRIP -->
  <div class="dash-hero">
    <div class="dash-hero-inner">
      <div class="dash-greeting">
        <div class="dash-avatar-lg"><?= $initial ?></div>
        <div>
          <div class="dash-welcome">Welcome back</div>
          <div class="dash-name"><?= $fullName ?></div>
          <div class="dash-email"><?= $email ?></div>
        </div>
      </div>
      <div class="dash-meta">
        <div class="dash-tag"><div class="dash-tag-dot"></div><span id="statusTag">Active</span></div>
        <div class="dash-tag" style="color:#666;" id="lastLoginTag">Last login: —</div>
      </div>
    </div>
  </div>

  <!-- MAIN -->
  <div class="dash-content">

    <!-- Stats row -->
    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-card-num" id="statApplications">—</div>
        <div class="stat-card-label">Applications</div>
        <div class="stat-card-sub">Total submitted</div>
      </div>
      <div class="stat-card">
        <div class="stat-card-num" id="statActive">—</div>
        <div class="stat-card-label">Active</div>
        <div class="stat-card-sub">Currently enrolled</div>
      </div>
      <div class="stat-card">
        <div class="stat-card-num" id="statNotifs">—</div>
        <div class="stat-card-label">Notifications</div>
        <div class="stat-card-sub">Unread alerts</div>
      </div>
    </div>

    <div class="dash-grid">

      <!-- LEFT: Applications -->
      <div>
        <div class="section-head">
          <div class="section-head-line"><h2>My Applications & Enrolments</h2></div>
          <span class="badge-count" id="appCount">0</span>
        </div>
        <div class="panel">
          <div class="panel-header">
            <h3>ALL RECORDS</h3>
            <span style="font-size:0.75rem;color:#555;" id="appLastUpdated">Loading…</span>
          </div>
          <div class="panel-body" id="applicationsContainer">
            <!-- Loading skeletons -->
            <div class="loading-state">
              <div class="skel-row">
                <div class="skeleton skel-circle"></div>
                <div class="skel-lines"><div class="skeleton skel-line w70"></div><div class="skeleton skel-line w45"></div></div>
              </div>
              <div class="skel-row">
                <div class="skeleton skel-circle"></div>
                <div class="skel-lines"><div class="skeleton skel-line w70"></div><div class="skeleton skel-line w45"></div></div>
              </div>
              <div class="skel-row">
                <div class="skeleton skel-circle"></div>
                <div class="skel-lines"><div class="skeleton skel-line w70"></div><div class="skeleton skel-line w45"></div></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Quick links -->
        <div style="margin-top:24px;">
          <div class="section-head-line" style="margin-bottom:14px;"><h2 style="font-family:'Playfair Display',Georgia,serif;font-size:1.1rem;font-weight:700;color:#fff;">Explore Our Divisions</h2></div>
          <div class="quick-links">
            <a href="visa.php" class="quick-link">
              <span class="ql-icon">✈️</span>
              <span class="ql-label">Visa Consultation</span>
              <span class="ql-sub">Immigration & documentation</span>
            </a>
            <a href="higherEducation.html" class="quick-link">
              <span class="ql-icon">🎓</span>
              <span class="ql-label">Higher Education</span>
              <span class="ql-sub">University placements</span>
            </a>
            <a href="english.php" class="quick-link">
              <span class="ql-icon">📚</span>
              <span class="ql-label">English Academy</span>
              <span class="ql-sub">Language certification</span>
            </a>
            <a href="contactus.html" class="quick-link">
              <span class="ql-icon">💬</span>
              <span class="ql-label">Talk to an Advisor</span>
              <span class="ql-sub">Get personalised help</span>
            </a>
          </div>
        </div>
      </div>

      <!-- RIGHT: Notifications -->
      <div>
        <div class="section-head">
          <div class="section-head-line"><h2>Notifications</h2></div>
          <span class="badge-count" id="notifCount">0</span>
        </div>
        <div class="panel">
          <div class="panel-body" id="notificationsContainer">
            <div class="loading-state">
              <div class="skel-row"><div class="skeleton skel-circle" style="width:8px;height:8px;border-radius:50%;"></div><div class="skel-lines"><div class="skeleton skel-line w70"></div><div class="skeleton skel-line w45"></div></div></div>
              <div class="skel-row"><div class="skeleton skel-circle" style="width:8px;height:8px;border-radius:50%;"></div><div class="skel-lines"><div class="skeleton skel-line w70"></div><div class="skeleton skel-line w45"></div></div></div>
            </div>
          </div>
        </div>

        <!-- Profile card -->
        <div class="panel" style="margin-top:20px;">
          <div class="panel-header"><h3>MY ACCOUNT</h3></div>
          <div class="panel-body">
            <div style="padding:20px 24px;display:flex;flex-direction:column;gap:12px;" id="profileSnippet">
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;">
                <span style="color:#555;">Status</span>
                <span id="accountStatus" style="color:var(--green);font-weight:600;">—</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;">
                <span style="color:#555;">Country</span>
                <span id="accountCountry" style="color:#ccc;">—</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;">
                <span style="color:#555;">Phone</span>
                <span id="accountPhone" style="color:#ccc;">—</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;">
                <span style="color:#555;">Member since</span>
                <span id="accountSince" style="color:#ccc;">—</span>
              </div>
              <div style="border-top:1px solid var(--border);padding-top:14px;margin-top:4px;">
                <a href="profile.php" style="display:block;text-align:center;background:var(--red);color:#fff;padding:10px;border-radius:8px;font-size:0.82rem;font-weight:700;text-decoration:none;transition:opacity .2s;" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">Edit Profile & Password</a>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <span>© 2026 Global RX Business. All rights reserved.</span>
  <div class="footer-dots">
    <div class="dot" style="background:var(--red)"></div>
    <div class="dot" style="background:var(--green)"></div>
    <div class="dot" style="background:var(--yellow)"></div>
  </div>
</footer>

<!-- Firebase -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, doc, getDoc, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// ── YOUR FIREBASE CONFIG ──
const firebaseConfig = {
  apiKey: "AIzaSyA8wy_aEO2Pc3uMaNPyEEN2UsoGE9nQzeU",
  authDomain: "globalrx-9085e.firebaseapp.com",
  projectId: "globalrx-9085e",
  storageBucket: "globalrx-9085e.firebasestorage.app",
  messagingSenderId: "632389557622",
  appId: "1:632389557622:web:1f5da5ef9ecb13b018ae57"
};

const app  = initializeApp(firebaseConfig);
const db   = getFirestore(app);
const auth = getAuth(app);

const userEmail = <?= json_encode($email) ?>;

// ── LOAD USER PROFILE from Firestore ──
async function loadUserProfile() {
  try {
    const usersRef  = collection(db, 'users');
    const q         = query(usersRef, where('email', '==', userEmail));
    const snapshot  = await getDocs(q);

    if (!snapshot.empty) {
      const data = snapshot.docs[0].data();

      // Last login
      if (data.lastLogin) {
        const d = data.lastLogin.toDate ? data.lastLogin.toDate() : new Date(data.lastLogin);
        document.getElementById('lastLoginTag').textContent = 'Last login: ' + d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
      }

      // Account snippet
      document.getElementById('accountStatus').textContent  = data.status  ? capitalise(data.status)  : '—';
      document.getElementById('accountCountry').textContent = data.country  || '—';
      document.getElementById('accountPhone').textContent   = data.telephone || '—';
      if (data.createdAt) {
        const d = data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt);
        document.getElementById('accountSince').textContent = d.toLocaleDateString('en-US',{month:'long',year:'numeric'});
      }

      // Status tag colour
      if (data.status === 'active') {
        document.getElementById('statusTag').textContent = 'Active';
      } else if (data.status) {
        document.getElementById('statusTag').textContent = capitalise(data.status);
        document.querySelector('.dash-tag-dot').style.background = '#f4c430';
      }
    }
  } catch(e) { console.error('Profile load error:', e); }
}

// ── LOAD APPLICATIONS ──
// Adjust collection name / field names to match your Firestore schema
async function loadApplications() {
  const container = document.getElementById('applicationsContainer');
  try {
    const appsRef  = collection(db, 'applications');
    const q        = query(appsRef, where('userEmail', '==', userEmail));
    const snapshot = await getDocs(q);

    document.getElementById('appLastUpdated').textContent = 'Updated just now';

    if (snapshot.empty) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">📋</div>
          <div class="empty-title">No applications yet</div>
          <div class="empty-sub">Your enrolled courses and applications will appear here.</div>
        </div>`;
      document.getElementById('appCount').textContent = '0';
      document.getElementById('statApplications').textContent = '0';
      document.getElementById('statActive').textContent = '0';
      return;
    }

    let html = '';
    let activeCount = 0;
    const iconMap   = { visa:'✈️', education:'🎓', english:'📚' };
    const colorMap  = { visa:'red', education:'green', english:'yellow' };

    snapshot.forEach(docSnap => {
      const d    = docSnap.data();
      const type = (d.type || 'education').toLowerCase();
      const icon = iconMap[type]  || '📄';
      const col  = colorMap[type] || 'green';
      const statusClass = d.status === 'active' ? 'active' : d.status === 'review' ? 'review' : 'pending';
      const date = d.createdAt ? (d.createdAt.toDate ? d.createdAt.toDate() : new Date(d.createdAt)).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}) : '—';
      if (d.status === 'active') activeCount++;

      html += `
        <div class="app-item">
          <div class="app-icon ${col}">${icon}</div>
          <div class="app-info">
            <div class="app-title">${d.title || d.courseName || 'Application'}</div>
            <div class="app-sub">${d.division || capitalise(type)} Division</div>
          </div>
          <div class="app-status">
            <span class="status-pill ${statusClass}">${capitalise(d.status || 'Pending')}</span>
            <span class="app-date">${date}</span>
          </div>
        </div>`;
    });

    container.innerHTML = html;
    const total = snapshot.size;
    document.getElementById('appCount').textContent = total;
    document.getElementById('statApplications').textContent = total;
    document.getElementById('statActive').textContent = activeCount;

  } catch(e) {
    console.error('Applications load error:', e);
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">Could not load applications</div><div class="empty-sub">${e.message}</div></div>`;
  }
}

// ── LOAD NOTIFICATIONS ──
// Adjust collection name to match your Firestore schema
async function loadNotifications() {
  const container = document.getElementById('notificationsContainer');
  try {
    const notifsRef = collection(db, 'notifications');
    const q         = query(notifsRef, where('userEmail', '==', userEmail));
    const snapshot  = await getDocs(q);

    if (snapshot.empty) {
      container.innerHTML = `<div class="empty-state"><div class="empty-icon">🔔</div><div class="empty-title">No notifications</div><div class="empty-sub">You're all caught up!</div></div>`;
      document.getElementById('notifCount').textContent = '0';
      document.getElementById('statNotifs').textContent = '0';
      return;
    }

    let html = '';
    let unreadCount = 0;

    snapshot.forEach(docSnap => {
      const d      = docSnap.data();
      const unread = !d.read;
      if (unread) unreadCount++;
      const time = d.createdAt ? (d.createdAt.toDate ? d.createdAt.toDate() : new Date(d.createdAt)).toLocaleDateString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '';

      html += `
        <div class="notif-item ${unread ? 'unread' : ''}">
          <div class="notif-dot ${unread ? '' : 'read'}"></div>
          <div class="notif-body">
            <div class="notif-title">${d.message || d.title || 'Notification'}</div>
            <div class="notif-time">${time}</div>
          </div>
        </div>`;
    });

    container.innerHTML = html;
    document.getElementById('notifCount').textContent = unreadCount;
    document.getElementById('statNotifs').textContent = unreadCount;

  } catch(e) {
    console.error('Notifications load error:', e);
    container.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><div class="empty-title">Could not load notifications</div></div>`;
  }
}

function capitalise(str) {
  if (!str) return '—';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// Run all loaders
loadUserProfile();
loadApplications();
loadNotifications();
</script>

<script>
// Nav dropdowns
function toggleDropdown() {
  document.getElementById('divDropdown').classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('divDropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});

const navUserToggle = document.getElementById('navUserToggle');
const navUserMenu   = document.getElementById('navUserMenu');
if (navUserToggle && navUserMenu) {
  navUserToggle.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = navUserMenu.classList.toggle('open');
    navUserToggle.setAttribute('aria-expanded', isOpen);
  });
  document.addEventListener('click', e => {
    const navUser = document.getElementById('navUser');
    if (navUser && !navUser.contains(e.target)) {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
}
</script>
</body>
</html>