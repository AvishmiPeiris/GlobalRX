<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');

$initial = !empty($firstName) ? strtoupper($firstName[0]) : '?';

if (empty($fullName) && !empty($firstName)) {
    $fullName = $firstName;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Global RX Business</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="index.css">
<style>
/* ── FALLBACK / PATCH STYLES ──
   These fix issues even if index.css fails to load or is missing styles */

* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --red: #e63946;
  --green: #2d9c5f;
  --yellow: #f4c430;
  --dark: #111;
  --offblack: #1a1a1a;
  --light: #f9f9f9;
  --mid: #e0e0e0;
}
body { font-family: 'Segoe UI', sans-serif; background: #fff; color: #111; }

/* NAV */
nav {
  position: fixed; top: 0; left: 0; right: 0;
  width: 100%; max-width: none;
  background: rgba(255,255,255,0.95);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid #e0e0e0;
  border-radius: 0;
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 48px;
  z-index: 999;
  box-shadow: 0 4px 24px rgba(0,0,0,0.06);
}
.nav-logo { font-size: 1.15rem; font-weight: 800; letter-spacing: 1px; color: #111; text-decoration: none; }
.nav-logo span { color: var(--red); }
.nav-links { display: flex; gap: 32px; list-style: none; align-items: center; }
.nav-links a { text-decoration: none; color: #333; font-size: 0.92rem; font-weight: 500; transition: color .2s; }
.nav-links a:hover { color: var(--red); }
.nav-btn {
  background: #111; color: #fff; border: none; padding: 9px 22px;
  border-radius: 50px; font-size: 0.88rem; font-weight: 600; cursor: pointer;
  transition: background .2s;
}
.nav-btn:hover { background: var(--red); }

/* DROPDOWN */
.nav-dropdown { position: relative; }
.nav-dropdown-toggle {
  display: flex; align-items: center; gap: 5px;
  text-decoration: none; color: #333; font-size: 0.92rem; font-weight: 500;
  cursor: pointer; background: none; border: none; font-family: inherit; padding: 0; transition: color .2s;
}
.nav-dropdown-toggle:hover,
.nav-dropdown.open .nav-dropdown-toggle { color: var(--red); }
.nav-dropdown-toggle .chevron {
  width: 14px; height: 14px; display: flex; align-items: center; justify-content: center;
  transition: transform .25s;
}
.nav-dropdown-toggle .chevron svg { width: 10px; height: 10px; stroke: currentColor; fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; }
.nav-dropdown.open .chevron { transform: rotate(180deg); }
.dropdown-menu {
  position: absolute; top: calc(100% + 14px); left: 50%; transform: translateX(-50%);
  background: #fff; border: 1px solid #e8e8e8; border-radius: 14px;
  box-shadow: 0 12px 40px rgba(0,0,0,0.12);
  min-width: 260px; padding: 8px;
  opacity: 0; pointer-events: none;
  transform: translateX(-50%) translateY(-6px);
  transition: opacity .2s, transform .2s;
}
.nav-dropdown.open .dropdown-menu {
  opacity: 1; pointer-events: all;
  transform: translateX(-50%) translateY(0);
}
.dropdown-item {
  display: flex; align-items: center; gap: 12px;
  padding: 11px 14px; border-radius: 9px;
  text-decoration: none; color: #222;
  font-size: 0.88rem; font-weight: 500;
  transition: background .15s, color .15s;
}
.dropdown-item:hover { background: var(--light); color: var(--red); }
.dropdown-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.dropdown-item:nth-child(1) .dropdown-dot { background: var(--red); }
.dropdown-item:nth-child(2) .dropdown-dot { background: var(--green); }
.dropdown-item:nth-child(3) .dropdown-dot { background: var(--yellow); }
.dropdown-divider { height: 1px; background: #f0f0f0; margin: 4px 8px; }

/* ── NAV USER WIDGET ── */
.nav-user { position: relative; }
.nav-user-toggle {
  display: flex; align-items: center; gap: 8px;
  background: none; border: 1.5px solid #d0d0d0;
  border-radius: 50px; padding: 5px 14px 5px 6px;
  cursor: pointer; color: #111; transition: border-color .2s, background .2s;
  font-family: inherit;
}
.nav-user-toggle:hover { border-color: var(--red); background: rgba(230,57,70,0.05); }
.nav-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  background: var(--red); overflow: hidden;
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: 14px; color: #fff; flex-shrink: 0;
}
.nav-avatar img { width: 100%; height: 100%; object-fit: cover; }
.nav-user-name {
  font-size: 14px; font-weight: 600;
  max-width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  color: #111;
}
.nav-chevron { display: flex; align-items: center; }
.nav-chevron svg {
  width: 10px; height: 6px; stroke: #555;
  fill: none; stroke-width: 2; transition: transform .25s;
}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg { transform: rotate(180deg); }

/* Dropdown panel */
.nav-user-menu {
  position: absolute; right: 0; top: calc(100% + 12px);
  width: 280px; background: #fff; border-radius: 16px;
  box-shadow: 0 12px 40px rgba(0,0,0,0.14);
  border: 1px solid #ececec;
  padding: 8px;
  opacity: 0; transform: translateY(-8px) scale(.97);
  pointer-events: none; transition: opacity .22s, transform .22s;
  z-index: 1000;
}
.nav-user-menu.open {
  opacity: 1; transform: translateY(0) scale(1); pointer-events: all;
}

/* Profile header */
.num-header {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 8px 12px;
}
.num-avatar-lg {
  width: 48px; height: 48px; border-radius: 50%; background: var(--red);
  display: flex; align-items: center; justify-content: center;
  font-weight: 800; font-size: 19px; color: #fff; flex-shrink: 0; overflow: hidden;
}
.num-avatar-lg img { width: 100%; height: 100%; object-fit: cover; }
.num-info { flex: 1; min-width: 0; }
.num-name  { font-size: 14px; font-weight: 700; color: #111; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.num-email { font-size: 12px; color: #888; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

/* ── FIXED: num-badge was missing from index.css ── */
.num-badge {
  display: inline-block;
  margin-top: 4px;
  padding: 2px 8px;
  background: #f0f0f0;
  color: #555;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.5px;
  border-radius: 50px;
  text-transform: capitalize;
}

.num-divider { height: 1px; background: #f0f0f0; margin: 4px 0; }

/* ── FIXED: SVG icons — constrained size, correct color, no blue bleed ── */
.num-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px; border-radius: 10px; font-size: 13px; font-weight: 500;
  color: #222; text-decoration: none; transition: background .15s;
  width: 100%; background: none; border: none; cursor: pointer;
  text-align: left; font-family: inherit;
}
.num-item svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  color: #888;
  fill: currentColor;
}
.num-item:hover { background: #f6f6f6; }
.num-logout { color: var(--red) !important; }
.num-logout svg { color: var(--red) !important; }
.num-logout:hover { background: #fff3f3 !important; }

/* HERO */
.hero {
  height: 100vh; min-height: 600px;
  background: linear-gradient(160deg, #0a0a0a 0%, #1c1c1c 50%, #2e2e2e 100%);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  text-align: center; padding: 70px 20px 0; position: relative; overflow: hidden;
}
.hero::before {
  content: '';
  position: absolute; inset: 0;
  background: url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1600&q=80') center/cover no-repeat;
  opacity: 0.10;
}
.hero::after {
  content: '';
  position: absolute; inset: 0;
  background: radial-gradient(ellipse at center, rgba(255,255,255,0.04) 0%, transparent 70%);
}
.hero-tag {
  background: rgba(255,255,255,0.1); color: #ddd;
  border: 1px solid rgba(255,255,255,0.18);
  font-size: 0.75rem; font-weight: 700; letter-spacing: 2px;
  padding: 5px 16px; border-radius: 50px;
  margin-bottom: 22px; position: relative; z-index: 1;
}
.hero h1 {
  font-size: clamp(2.2rem, 5vw, 4rem); font-weight: 900;
  color: #fff; line-height: 1.12; position: relative;
  max-width: 780px; z-index: 1;
}
.hero h1 span { color: #e0e0e0; font-style: italic; }
.hero p {
  color: #888; font-size: 1.05rem; margin-top: 18px;
  max-width: 520px; position: relative; line-height: 1.7; z-index: 1;
}
.hero-btns { display: flex; gap: 14px; margin-top: 34px; position: relative; z-index: 1; }
.btn-primary {
  background: #fff; color: #111; padding: 13px 30px;
  border-radius: 50px; font-weight: 700; font-size: 0.95rem;
  text-decoration: none; transition: transform .2s, background .2s;
}
.btn-primary:hover { transform: translateY(-2px); background: #e0e0e0; }
.btn-outline {
  border: 2px solid rgba(255,255,255,0.25); color: #aaa; padding: 13px 30px;
  border-radius: 50px; font-weight: 700; font-size: 0.95rem;
  text-decoration: none; transition: border-color .2s, color .2s;
}
.btn-outline:hover { border-color: rgba(255,255,255,0.6); color: #fff; }
.scroll-hint {
  position: absolute; bottom: 34px; left: 50%; transform: translateX(-50%);
  color: var(--red); font-size: 0.78rem; letter-spacing: 1px;
  display: flex; flex-direction: column; align-items: center; gap: 6px; z-index: 1;
}
.scroll-hint::after { content: ''; width: 1px; height: 40px; background: var(--red); display: block; }

/* STATS BAR */
.stats-bar {
  background: var(--red); padding: 0 60px;
  display: flex; align-items: center; justify-content: space-between;
  height: 72px; overflow: hidden;
}
.stats-bar-item { display: flex; align-items: center; gap: 10px; flex: 1; justify-content: center; }
.stats-bar-item + .stats-bar-item { border-left: 1px solid rgba(255,255,255,0.2); }
.stat-number {
  font-family: 'Playfair Display', Georgia, serif;
  font-size: 1.5rem; font-weight: 700; color: #fff;
  letter-spacing: -0.5px; min-width: 52px; text-align: right;
}
.stat-suffix { font-family: 'Playfair Display', Georgia, serif; font-size: 1.5rem; font-weight: 700; color: #fff; }
.stat-label { font-size: 0.65rem; font-weight: 700; letter-spacing: 2.5px; text-transform: uppercase; color: rgba(255,255,255,0.65); white-space: nowrap; }
.stats-bar-item { opacity: 0; transform: translateY(10px); transition: opacity 0.5s ease, transform 0.5s ease; }
.stats-bar-item.visible { opacity: 1; transform: translateY(0); }

/* DIVISIONS */
.divisions { padding: 100px 20px 80px; background: #fff; text-align: center; }
.section-label { font-size: 0.75rem; font-weight: 700; letter-spacing: 3px; color: #999; text-transform: uppercase; margin-bottom: 10px; }
.section-title { font-size: clamp(1.8rem, 3.5vw, 2.8rem); font-weight: 900; color: #111; margin-bottom: 12px; }
.section-title span { color: var(--red); }
.section-sub { color: #777; font-size: 1rem; max-width: 480px; margin: 0 auto 60px; line-height: 1.7; }
.cards-scene { position: relative; width: 100%; max-width: 1000px; margin: 0 auto; height: 540px; }
.card {
  position: absolute; background: var(--offblack); color: #fff;
  border-radius: 18px; padding: 28px 28px 24px; width: 280px;
  box-shadow: 0 12px 40px rgba(0,0,0,0.18); text-align: left;
  transition: transform .3s, box-shadow .3s; cursor: default;
}
.card:hover { transform: translateY(-8px) rotate(0deg) !important; box-shadow: 0 24px 56px rgba(0,0,0,0.28); }
.card-pin { width: 12px; height: 12px; border-radius: 50%; background: #555; margin-bottom: 16px; box-shadow: inset 0 1px 3px rgba(0,0,0,0.5); }
.card-num { font-size: 0.72rem; font-weight: 700; letter-spacing: 2px; color: #666; margin-bottom: 6px; }
.card-name { font-size: 1.1rem; font-weight: 800; margin-bottom: 10px; }
.card-desc { font-size: 0.8rem; color: #aaa; line-height: 1.6; }
.card-btn { display: inline-block; margin-top: 18px; padding: 7px 16px; border-radius: 50px; font-size: 0.75rem; font-weight: 700; text-decoration: none; cursor: pointer; border: none; transition: opacity .2s, transform .2s; }
.card-btn:hover { opacity: 0.85; transform: translateY(-1px); }
.card-1 .card-btn { background: var(--red); color: #fff; }
.card-2 .card-btn { background: var(--green); color: #fff; }
.card-3 .card-btn { background: var(--yellow); color: #111; }
.card-1 { top: 10px; right: 20px; transform: rotate(2deg); border-bottom: 3px solid var(--red); }
.card-2 { top: 180px; left: 0px; transform: rotate(-3deg); border-bottom: 3px solid var(--green); }
.card-3 { top: 320px; right: 60px; transform: rotate(1.5deg); border-bottom: 3px solid var(--yellow); }
.cards-scene svg { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; overflow: visible; }

/* WHY CHOOSE US */
.why { background: #111; padding: 80px 60px; }
.why-header { margin-bottom: 40px; }
.why-label { display: flex; align-items: center; gap: 10px; font-size: 0.72rem; font-weight: 700; letter-spacing: 3px; color: #555; text-transform: uppercase; margin-bottom: 16px; }
.why-label::before { content: ''; width: 3px; height: 14px; background: var(--red); border-radius: 2px; display: block; }
.why-header h2 { font-family: 'Playfair Display', Georgia, serif; font-size: clamp(2rem, 4vw, 3rem); font-weight: 700; color: #fff; line-height: 1.2; }
.why-header h2 em { font-style: italic; color: var(--red); }
.why-body { display: grid; grid-template-columns: 1fr 1fr 320px; gap: 0; border: 1px solid #2a2a2a; border-radius: 4px; overflow: hidden; }
.why-feature { padding: 36px 32px; border-right: 1px solid #2a2a2a; border-bottom: 1px solid #2a2a2a; background: #181818; transition: background .2s; }
.why-feature:hover { background: #1f1f1f; }
.why-feature:nth-child(3), .why-feature:nth-child(4) { border-bottom: none; }
.why-feature:nth-child(2), .why-feature:nth-child(4) { border-right: none; }
.why-feature-icon { font-size: 1.4rem; margin-bottom: 18px; display: block; color: var(--red); }
.why-feature h3 { font-family: 'Playfair Display', Georgia, serif; font-size: 1.05rem; font-weight: 700; color: #fff; margin-bottom: 10px; }
.why-feature p { font-size: 0.82rem; color: #777; line-height: 1.7; }
.why-stats { background: var(--red); grid-row: 1 / 3; grid-column: 3; display: flex; flex-direction: column; justify-content: center; padding: 48px 36px; gap: 48px; }
.why-stat-num { font-family: 'Playfair Display', Georgia, serif; font-size: clamp(3rem, 5vw, 4rem); font-weight: 700; color: #fff; line-height: 1; margin-bottom: 10px; }
.why-stat-lbl { font-size: 0.7rem; font-weight: 700; letter-spacing: 2.5px; text-transform: uppercase; color: rgba(255,255,255,0.6); }
.why-stat-divider { width: 40px; height: 1px; background: rgba(255,255,255,0.25); }

/* CTA BANNER */
.cta-banner { background: var(--red); padding: 64px 60px; display: flex; align-items: center; justify-content: space-between; position: relative; overflow: hidden; gap: 40px; }
.cta-watermark { position: absolute; right: -10px; top: 50%; transform: translateY(-50%); font-family: 'Playfair Display', Georgia, serif; font-size: clamp(5rem, 12vw, 9rem); font-weight: 700; color: rgba(255,255,255,0.08); letter-spacing: 4px; white-space: nowrap; pointer-events: none; user-select: none; line-height: 1; }
.cta-left { position: relative; z-index: 1; max-width: 560px; }
.cta-left h2 { font-family: 'Playfair Display', Georgia, serif; font-size: clamp(1.7rem, 3.5vw, 2.4rem); font-weight: 700; color: #fff; line-height: 1.25; margin-bottom: 14px; }
.cta-left p { font-size: 0.88rem; color: rgba(255,255,255,0.65); line-height: 1.6; }
.cta-right { position: relative; z-index: 1; flex-shrink: 0; }
.cta-apply-btn { display: inline-flex; align-items: center; gap: 10px; background: #fff; color: var(--red); padding: 14px 30px; border-radius: 4px; font-size: 0.88rem; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; text-decoration: none; transition: background .2s, color .2s, transform .2s; white-space: nowrap; }
.cta-apply-btn:hover { background: #111; color: #fff; transform: translateY(-2px); }

/* FOOTER */
footer { background: #111; color: #ccc; padding: 60px 20px 30px; border-top: 1px solid #2a2a2a; }
.footer-inner { max-width: 1100px; margin: 0 auto; }
.footer-top { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 40px; padding-bottom: 40px; border-bottom: 1px solid #2a2a2a; }
.footer-brand .nav-logo { font-size: 1.3rem; color: #fff; display: block; margin-bottom: 12px; }
.footer-brand p { font-size: 0.85rem; color: #777; line-height: 1.7; max-width: 240px; }
.footer-col h4 { color: #fff; font-size: 0.88rem; font-weight: 700; letter-spacing: 1px; margin-bottom: 14px; }
.footer-col ul { list-style: none; }
.footer-col ul li { margin-bottom: 9px; }
.footer-col ul li a { color: #777; text-decoration: none; font-size: 0.84rem; transition: color .2s; }
.footer-col ul li a:hover { color: #fff; }
.footer-col ul li span { color: #666; font-size: 0.84rem; }
.footer-bottom { display: flex; justify-content: space-between; align-items: center; padding-top: 24px; font-size: 0.8rem; color: #555; flex-wrap: wrap; gap: 10px; }
.footer-dots { display: flex; gap: 8px; }
.dot { width: 8px; height: 8px; border-radius: 50%; }

/* RESPONSIVE */
@media(max-width: 900px) {
  .stats-bar { padding: 0 20px; height: auto; flex-wrap: wrap; gap: 0; }
  .stats-bar-item { padding: 16px 10px; border-left: none !important; border-bottom: 1px solid rgba(255,255,255,0.15); }
  .why { padding: 60px 24px; }
  .why-body { grid-template-columns: 1fr 1fr; }
  .why-stats { grid-row: auto; grid-column: 1 / 3; flex-direction: row; justify-content: space-around; padding: 36px 24px; gap: 24px; }
  .why-stat-divider { display: none; }
  .why-feature:nth-child(3), .why-feature:nth-child(4) { border-bottom: 1px solid #2a2a2a; }
  .cta-banner { flex-direction: column; text-align: center; padding: 52px 30px; }
}
@media(max-width: 768px) {
  nav { padding: 14px 20px; }
  .cards-scene { height: 780px; }
  .card { width: 240px; }
  .card-1 { top: 20px; right: 10px; left: auto; }
  .card-2 { top: 270px; left: 10px; }
  .card-3 { top: 520px; right: 10px; }
  .why-body { grid-template-columns: 1fr; }
  .why-stats { grid-column: auto; flex-direction: column; }
  .why-feature { border-right: none; }
  .why-feature:nth-child(3) { border-bottom: 1px solid #2a2a2a; }
  .footer-top { grid-template-columns: 1fr 1fr; }
  .nav-user-menu { width: 260px; right: -10px; }
  .nav-user-name { display: none; }
}
</style>
</head>
<body>
<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron">
        <svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg>
      </span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z" fill="currentColor"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z" fill="currentColor"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <div id="navLoggedOut">
    <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  </div>
  <?php endif; ?>
</nav>

<!-- HERO -->
<section class="hero" id="home">
  <div class="hero-tag">Welcome to Global RX Business</div>
  <h1>Empowering Futures,<br><span>One Division</span> at a Time</h1>
  <p>A unified organization driving excellence across education, language learning, and international consultation.</p>
  <div class="hero-btns">
    <a href="#divisions" class="btn-primary">Explore Divisions</a>
    <a href="aboutus.html" class="btn-outline">Learn More</a>
  </div>
  <div class="scroll-hint">scroll</div>
</section>

<!-- STATS TICKER BAR -->
<div class="stats-bar" id="statsBar">
  <div class="stats-bar-item">
    <span class="stat-number" data-target="1200">0</span><span class="stat-suffix">+</span>
    <span class="stat-label">Students Enrolled</span>
  </div>
  <div class="stats-bar-item">
    <span class="stat-number" data-target="3">0</span><span class="stat-suffix"></span>
    <span class="stat-label">Active Divisions</span>
  </div>
  <div class="stats-bar-item">
    <span class="stat-number" data-target="95">0</span><span class="stat-suffix">%</span>
    <span class="stat-label">Placement Rate</span>
  </div>
  <div class="stats-bar-item">
    <span class="stat-number" data-target="40">0</span><span class="stat-suffix">+</span>
    <span class="stat-label">Partner Institutions</span>
  </div>
</div>

<!-- DIVISIONS -->
<section class="divisions" id="divisions">
  <div class="section-label">Our Structure</div>
  <div class="section-title">Three Divisions, <span>One Mission</span></div>
  <p class="section-sub">Each subsidiary is purpose-built to deliver world-class services — together, they form the Global RX ecosystem.</p>
  <div class="cards-scene">
    <svg>
      <line x1="570" y1="110" x2="290" y2="260" stroke="#ddd" stroke-width="1.5" stroke-dasharray="6,5"/>
      <line x1="290" y1="330" x2="590" y2="420" stroke="#ddd" stroke-width="1.5" stroke-dasharray="6,5"/>
    </svg>
    <div class="card card-1">
      <div class="card-pin"></div>
      <div class="card-num">01</div>
      <div class="card-name">A-Squared Visa<br>Consultation</div>
      <div class="card-desc">Expert guidance for international visa processes, immigration pathways, and documentation support.</div>
      <a href="visa.php" class="card-btn">Learn More →</a>
    </div>
    <div class="card card-2">
      <div class="card-pin"></div>
      <div class="card-num">02</div>
      <div class="card-name">A-Squared Higher<br>Education Institute</div>
      <div class="card-desc">Connecting students with globally recognized universities and higher education programs worldwide.</div>
      <a href="higherEducation.html" class="card-btn">Learn More →</a>
    </div>
    <div class="card card-3">
      <div class="card-pin"></div>
      <div class="card-num">03</div>
      <div class="card-name">A-Squared English<br>Academy</div>
      <div class="card-desc">Comprehensive English language training — from foundational skills to advanced proficiency certification.</div>
      <a href="english.php" class="card-btn">Learn More →</a>
    </div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section class="why" id="why">
  <div class="why-header">
    <div class="why-label">Why Choose Us</div>
    <h2>The Global RX <em>Advantage</em></h2>
  </div>
  <div class="why-body">
    <div class="why-feature">
      <span class="why-feature-icon">🌐</span>
      <h3>International Recognition</h3>
      <p>Our degrees and certifications are recognized by employers and institutions globally.</p>
    </div>
    <div class="why-feature">
      <span class="why-feature-icon">🎓</span>
      <h3>Expert Faculty</h3>
      <p>Industry professionals and academicians delivering world-class, practical education.</p>
    </div>
    <div class="why-feature">
      <span class="why-feature-icon">🤝</span>
      <h3>Holistic Support</h3>
      <p>From enrollment to career placement, we support every step of your journey.</p>
    </div>
    <div class="why-feature">
      <span class="why-feature-icon">✅</span>
      <h3>Proven Track Record</h3>
      <p>Over a decade of transforming students into confident, career-ready professionals.</p>
    </div>
    <div class="why-stats">
      <div class="why-stat-item">
        <div class="why-stat-num">95%</div>
        <div class="why-stat-lbl">Graduate Employment Rate</div>
      </div>
      <div class="why-stat-divider"></div>
      <div class="why-stat-item">
        <div class="why-stat-num">40+</div>
        <div class="why-stat-lbl">Partner Institutions</div>
      </div>
    </div>
  </div>
</section>

<!-- CTA BANNER -->
<section class="cta-banner">
  <div class="cta-watermark">GLOBAL RX</div>
  <div class="cta-left">
    <h2>Ready to Begin Your Journey<br>with <em>Global RX</em>?</h2>
    <p>Applications are open. Speak with our advisors today and take the first step.</p>
  </div>
  <div class="cta-right">
    <a href="contactus.html" class="cta-apply-btn">Contact US →</a>
  </div>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col">
        <h4>PAGES</h4>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="aboutus.html">About Us</a></li>
          <li><a href="contactus.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>SUBSIDIARIES</h4>
        <ul>
          <li><a href="visa.php">A² Visa Consultation</a></li>
          <li><a href="higherEducation.html">A² Higher Education</a></li>
          <li><a href="english.php">A² English Academy</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>CONTACT</h4>
        <ul>
          <li><span>info@globalrx.com</span></li>
          <li><span>+1 (800) 000-0000</span></li>
          <li><span>Colombo, Sri Lanka</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
  // Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const t = document.querySelector(a.getAttribute('href'));
    if (t) t.scrollIntoView({ behavior: 'smooth' });
  });
});

// Nav shadow on scroll
const nav = document.querySelector('nav');
window.addEventListener('scroll', () => {
  nav.style.boxShadow = window.scrollY > 40
    ? '0 8px 32px rgba(0,0,0,0.14)'
    : '0 4px 24px rgba(0,0,0,0.06)';
});

// Divisions dropdown
function toggleDropdown() {
  document.getElementById('divDropdown').classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('divDropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});

// ── USER MENU DROPDOWN ──
const navUserToggle = document.getElementById('navUserToggle');
const navUserMenu   = document.getElementById('navUserMenu');

if (navUserToggle && navUserMenu) {
  navUserToggle.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = navUserMenu.classList.toggle('open');
    navUserToggle.setAttribute('aria-expanded', isOpen);
  });

  // Close when clicking outside
  document.addEventListener('click', e => {
    const navUser = document.getElementById('navUser');
    if (navUser && !navUser.contains(e.target)) {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });

  // Close on Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

// Count-up animation
function animateCount(el, target, duration) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if (start >= target) {
      el.textContent = target;
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(start);
    }
  }, 16);
}

// Trigger stats bar animation when it enters viewport
let animated = false;
const statsBar = document.getElementById('statsBar');
const items    = statsBar.querySelectorAll('.stats-bar-item');
const numbers  = statsBar.querySelectorAll('.stat-number');

const observer = new IntersectionObserver((entries) => {
  if (entries[0].isIntersecting && !animated) {
    animated = true;
    items.forEach((item, i) => {
      setTimeout(() => item.classList.add('visible'), i * 120);
    });
    numbers.forEach((el, i) => {
      const target = parseInt(el.dataset.target);
      setTimeout(() => animateCount(el, target, 1400), i * 120);
    });
  }
}, { threshold: 0.3 });

observer.observe(statsBar);
</script>
<script type="module" src="app.js"></script>
</body>
</html>