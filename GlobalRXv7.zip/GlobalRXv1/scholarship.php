<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');

$initial = !empty($firstName) ? strtoupper($firstName[0]) : '?';

if (empty($fullName) && !empty($firstName)) {
    $fullName = $firstName;
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Scholarships — Global RX Business</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
  :root {
    --green: #2ECC8E; --green-dark: #1AA870; --green-deep: #0D7A52;
    --green-pale: #E8F9F2; --green-mid: #C2EFD9; --green-soft: #F0FBF6;
    --dark: #0F1F16; --offwhite: #F7FAF8; --gray: #6B7A72;
    --gray-light: #DEE8E3; --text: #1C2E24; --text-light: #5A6E62;
  }
  body { font-family: 'DM Sans', sans-serif; background: #fff; color: var(--text); overflow-x: hidden; }

  /* ─── NAV ─── */
  nav { position:fixed;top:0;left:0;right:0;background:rgba(255,255,255,0.96);backdrop-filter:blur(14px);border-bottom:1px solid var(--gray-light);display:flex;align-items:center;justify-content:space-between;padding:14px 52px;z-index:999;box-shadow:0 4px 20px rgba(0,0,0,0.05);transition:box-shadow 0.3s }
  .nav-logo { font-family:'DM Sans',sans-serif;font-size:1.1rem;font-weight:800;letter-spacing:1.5px;color:var(--dark);text-decoration:none }
  .nav-logo span { color:var(--green-dark) }
  .nav-links { display:flex;gap:30px;list-style:none;align-items:center }
  .nav-links a { text-decoration:none;color:#444;font-size:0.9rem;font-weight:500;transition:color .2s }
  .nav-links a:hover { color:var(--green-dark) }
  .nav-btn { background:var(--dark);color:#fff;border:none;padding:9px 22px;border-radius:50px;font-size:0.85rem;font-weight:700;cursor:pointer;font-family:inherit;transition:background .2s }
  .nav-btn:hover { background:var(--green-dark) }
  .nav-dropdown { position:relative }
  .nav-dropdown-toggle { display:flex;align-items:center;gap:5px;text-decoration:none;color:#444;font-size:0.9rem;font-weight:500;cursor:pointer;background:none;border:none;font-family:inherit;padding:0;transition:color .2s }
  .nav-dropdown-toggle:hover,.nav-dropdown.open .nav-dropdown-toggle { color:var(--green-dark) }
  .nav-dropdown-toggle .chevron { width:14px;height:14px;display:flex;align-items:center;justify-content:center;transition:transform .25s }
  .nav-dropdown-toggle .chevron svg { width:10px;height:10px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round }
  .nav-dropdown.open .chevron { transform:rotate(180deg) }
  .dropdown-menu { position:absolute;top:calc(100% + 14px);left:50%;transform:translateX(-50%) translateY(-6px);background:#fff;border:1px solid var(--gray-light);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.1);min-width:260px;padding:8px;opacity:0;pointer-events:none;transition:opacity .2s,transform .2s }
  .nav-dropdown.open .dropdown-menu { opacity:1;pointer-events:all;transform:translateX(-50%) translateY(0) }
  .dropdown-item { display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:9px;text-decoration:none;color:#222;font-size:0.86rem;font-weight:500;transition:background .15s,color .15s }
  .dropdown-item:hover { background:var(--green-pale);color:var(--green-dark) }
  .dropdown-dot { width:8px;height:8px;border-radius:50%;background:var(--green);flex-shrink:0 }
  .dropdown-divider { height:1px;background:var(--gray-light);margin:4px 8px }

  /* ── NAV USER WIDGET ── */
  .nav-user { position:relative }
  .nav-user-toggle { display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #d0d0d0;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#111;transition:border-color .2s,background .2s;font-family:inherit }
  .nav-user-toggle:hover { border-color:var(--green-dark);background:rgba(26,168,112,0.05) }
  .nav-avatar { width:32px;height:32px;border-radius:50%;background:var(--green-dark);overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0 }
  .nav-user-name { font-size:14px;font-weight:600;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111 }
  .nav-chevron { display:flex;align-items:center }
  .nav-chevron svg { width:10px;height:6px;stroke:#555;fill:none;stroke-width:2;transition:transform .25s }
  .nav-user-toggle[aria-expanded="true"] .nav-chevron svg { transform:rotate(180deg) }
  .nav-user-menu { position:absolute;right:0;top:calc(100% + 12px);width:280px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.14);border:1px solid #ececec;padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000 }
  .nav-user-menu.open { opacity:1;transform:translateY(0) scale(1);pointer-events:all }
  .num-header { display:flex;align-items:center;gap:12px;padding:10px 8px 12px }
  .num-avatar-lg { width:48px;height:48px;border-radius:50%;background:var(--green-dark);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;color:#fff;flex-shrink:0 }
  .num-info { flex:1;min-width:0 }
  .num-name { font-size:14px;font-weight:700;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis }
  .num-email { font-size:12px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis }
  .num-badge { display:inline-block;margin-top:4px;padding:2px 8px;background:#f0f0f0;color:#555;font-size:10px;font-weight:700;letter-spacing:.5px;border-radius:50px;text-transform:capitalize }
  .num-divider { height:1px;background:#f0f0f0;margin:4px 0 }
  .num-item { display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#222;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit }
  .num-item svg { width:16px;height:16px;flex-shrink:0;color:#888;fill:currentColor }
  .num-item:hover { background:#f6f6f6 }
  .num-logout { color:var(--green-dark)!important }.num-logout svg { color:var(--green-dark)!important }.num-logout:hover { background:var(--green-pale)!important }

  /* ─── HERO ─── */
  .schol-hero { padding-top:68px;background:var(--offwhite);min-height:88vh;display:grid;grid-template-columns:1fr 1fr;align-items:center;position:relative;overflow:hidden }
  .hero-circle-1 { position:absolute;top:12%;right:46%;width:48px;height:48px;border-radius:50%;background:var(--green);opacity:0.85 }
  .hero-circle-2 { position:absolute;top:8%;right:18%;width:22px;height:22px;border-radius:50%;background:var(--green-dark);opacity:0.7 }
  .hero-circle-3 { position:absolute;bottom:18%;right:8%;width:80px;height:80px;border-radius:50%;background:var(--green-mid);opacity:0.6 }
  .hero-circle-4 { position:absolute;top:20%;left:5%;width:16px;height:16px;border-radius:50%;background:var(--green);opacity:0.35 }
  .hero-left { padding:5rem 3.5rem 5rem 6rem;position:relative;z-index:2;animation:fadeUp 0.7s ease both }
  .hero-breadcrumb { display:flex;align-items:center;gap:0.5rem;font-size:0.7rem;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:#aaa;margin-bottom:1.5rem }
  .hero-breadcrumb .sep { color:var(--green-dark) }
  .hero-breadcrumb .current { color:var(--text-light) }
  .hero-eyebrow { display:inline-flex;align-items:center;gap:0.5rem;background:var(--green-pale);border:1px solid var(--green-mid);color:var(--green-deep);font-size:0.7rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;padding:0.38rem 1rem;border-radius:2px;margin-bottom:1.5rem }
  .hero-eyebrow::before { content:'';width:16px;height:2px;background:var(--green-dark);display:inline-block }
  .schol-hero h1 { font-family:'Playfair Display',Georgia,serif;font-size:clamp(2.4rem,4.2vw,3.6rem);font-weight:700;line-height:1.1;color:var(--dark);margin-bottom:1.2rem;letter-spacing:-0.01em }
  .schol-hero h1 em { font-style:italic;color:var(--green-dark) }
  .hero-desc { color:var(--text-light);font-size:1rem;line-height:1.78;max-width:440px;margin-bottom:2.2rem;font-weight:300 }
  .hero-actions { display:flex;gap:0.9rem;flex-wrap:wrap }
  .btn-green { background:var(--green-dark);color:#fff;padding:0.82rem 1.8rem;border-radius:50px;font-weight:700;font-size:0.88rem;letter-spacing:0.04em;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:all 0.2s;display:inline-flex;align-items:center;gap:0.4rem;box-shadow:0 4px 18px rgba(26,168,112,0.3) }
  .btn-green:hover { background:var(--green-deep);transform:translateY(-1px);box-shadow:0 8px 28px rgba(26,168,112,0.4) }
  .btn-ghost { border:1.5px solid var(--gray-light);color:var(--text);padding:0.82rem 1.8rem;border-radius:50px;font-weight:600;font-size:0.88rem;letter-spacing:0.04em;text-decoration:none;transition:all 0.2s;display:inline-flex;align-items:center;gap:0.4rem }
  .btn-ghost:hover { border-color:var(--green-dark);color:var(--green-dark) }
  .hero-stats-row { display:flex;gap:2.2rem;margin-top:2.8rem;padding-top:2.2rem;border-top:1px solid var(--gray-light) }
  .hstat-num { font-family:'Playfair Display',Georgia,serif;font-size:1.9rem;font-weight:700;color:var(--dark);line-height:1;margin-bottom:0.25rem }
  .hstat-num span { color:var(--green-dark) }
  .hstat-lbl { font-size:0.68rem;color:var(--gray);letter-spacing:0.1em;text-transform:uppercase;font-weight:600 }
  .hero-right { position:relative;z-index:2;display:flex;justify-content:center;align-items:flex-end;height:100%;min-height:500px;padding:2rem 0 0 0 }
  .hero-photo-wrap { position:relative;width:100%;height:100%;display:flex;align-items:flex-end;justify-content:center }
  .hero-photo { width:100%;height:100%;object-fit:cover;object-position:center top;display:block }

  /* ─── STATS BAR ─── */
  .stats-strip { background:var(--green-dark);display:flex;align-items:stretch;overflow:hidden }
  .strip-item { flex:1;display:flex;align-items:center;justify-content:center;gap:0.75rem;padding:1.1rem 1rem;border-right:1px solid rgba(255,255,255,0.15);opacity:0;transform:translateY(8px);transition:opacity 0.5s ease,transform 0.5s ease }
  .strip-item:last-child { border-right:none }
  .strip-item.visible { opacity:1;transform:translateY(0) }
  .strip-num { font-family:'Playfair Display',Georgia,serif;font-size:1.45rem;font-weight:700;color:#fff }
  .strip-lbl { font-size:0.62rem;font-weight:700;letter-spacing:0.18em;text-transform:uppercase;color:rgba(255,255,255,0.65) }

  /* ─── INTRO ─── */
  .intro-section { background:#fff;padding:5rem 6rem;display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center;max-width:1200px;margin:0 auto }
  .eyebrow-tag { display:flex;align-items:center;gap:0.5rem;font-size:0.7rem;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;color:#999;margin-bottom:1rem }
  .eyebrow-tag::before { content:'';width:3px;height:14px;background:var(--green-dark);border-radius:2px;display:block }
  h2 { font-family:'Playfair Display',Georgia,serif;font-size:clamp(1.8rem,2.8vw,2.4rem);font-weight:700;color:var(--dark);line-height:1.25;margin-bottom:1.2rem }
  h2 em { font-style:italic;color:var(--green-dark) }
  .intro-left p { color:#666;font-size:0.93rem;line-height:1.8;margin-bottom:1rem;font-weight:300 }
  .intro-cta-link { display:inline-flex;align-items:center;gap:0.5rem;color:var(--green-dark);font-size:0.83rem;font-weight:700;letter-spacing:0.06em;text-transform:uppercase;text-decoration:none;margin-top:1.2rem;transition:gap 0.2s }
  .intro-cta-link:hover { gap:0.9rem }
  .intro-right { display:flex;flex-direction:column;gap:1rem }
  .info-card { border:1px solid var(--gray-light);border-radius:12px;padding:1.3rem 1.5rem;display:flex;align-items:flex-start;gap:1rem;transition:all 0.2s }
  .info-card:hover { border-color:var(--green);box-shadow:0 8px 28px rgba(46,204,142,0.1);transform:translateX(4px) }
  .info-icon { width:44px;height:44px;background:var(--green-pale);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;border:1px solid var(--green-mid) }
  .info-card h4 { font-size:0.9rem;font-weight:700;color:var(--dark);margin-bottom:0.3rem }
  .info-card p { font-size:0.81rem;color:#888;line-height:1.6;font-weight:300 }

  /* ─── HOW IT WORKS ─── */
  .how-section { background:var(--green-soft);padding:5rem 4rem }
  .how-header { text-align:center;margin-bottom:3.5rem }
  .how-header .eyebrow { display:inline-block;font-size:0.7rem;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;color:var(--green-dark);margin-bottom:0.8rem;position:relative;padding:0 1.2rem }
  .how-header .eyebrow::before,.how-header .eyebrow::after { content:'';position:absolute;top:50%;width:26px;height:1px;background:var(--green-dark);opacity:0.4 }
  .how-header .eyebrow::before { right:100% }.how-header .eyebrow::after { left:100% }
  .how-header h2 { color:var(--dark);margin-bottom:0.75rem }
  .how-header p { color:var(--gray);font-size:0.93rem;max-width:520px;margin:0 auto;line-height:1.75;font-weight:300 }
  .steps-row { display:grid;grid-template-columns:repeat(4,1fr);gap:2rem;max-width:960px;margin:0 auto;position:relative }
  .steps-row::before { content:'';position:absolute;top:27px;left:calc(12.5% + 27px);right:calc(12.5% + 27px);height:1px;background:repeating-linear-gradient(90deg,var(--green-dark) 0,var(--green-dark) 6px,transparent 6px,transparent 14px);opacity:0.35 }
  .step { text-align:center }
  .step-circle { width:54px;height:54px;background:var(--green-dark);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.1rem;font-family:'Playfair Display',Georgia,serif;font-size:1.1rem;font-weight:700;color:#fff;position:relative;z-index:1;border:3px solid var(--green-soft);box-shadow:0 0 0 1px var(--green-dark) }
  .step h3 { font-size:0.95rem;font-weight:700;color:var(--dark);margin-bottom:0.5rem }
  .step p { font-size:0.81rem;color:var(--gray);line-height:1.65;font-weight:300 }

  /* ─── SEARCH + SCHOLARSHIPS ─── */
  .search-section { background:#fff;padding:5rem 4rem }
  .search-header { text-align:center;margin-bottom:2rem }
  .schol-search-row { display:flex;gap:0.75rem;max-width:720px;margin:0 auto;align-items:center }
  .schol-search-input-wrap { flex:1;position:relative }
  .schol-search-input { width:100%;padding:0.85rem 1.2rem 0.85rem 3rem;border:1.5px solid var(--gray-light);border-radius:50px;font-family:inherit;font-size:0.9rem;color:var(--text);background:#fff;outline:none;transition:border-color 0.2s }
  .schol-search-input:focus { border-color:var(--green-dark) }
  .schol-search-input::placeholder { color:#bbb }
  .schol-search-icon { position:absolute;left:1.1rem;top:50%;transform:translateY(-50%);color:#bbb;pointer-events:none }
  .schol-filter-btn { display:inline-flex;align-items:center;gap:0.5rem;padding:0.85rem 1.4rem;border-radius:50px;border:1.5px solid var(--gray-light);background:#fff;font-family:inherit;font-size:0.85rem;font-weight:600;color:var(--text);cursor:pointer;transition:all 0.2s;white-space:nowrap }
  .schol-filter-btn:hover { border-color:var(--green-dark);color:var(--green-dark) }
  .schol-meta-row { display:flex;justify-content:space-between;align-items:center;max-width:820px;margin:1.8rem auto 0.5rem;padding-bottom:0.75rem;border-bottom:1.5px solid var(--gray-light);font-size:0.83rem;color:#aaa }
  .schol-meta-row strong { color:var(--dark);font-weight:700 }
  .schol-list { max-width:820px;margin:0 auto }
  .schol-list-item { display:flex;align-items:center;justify-content:space-between;padding:1.8rem 0;border-bottom:1px solid var(--gray-light);gap:2rem;transition:all 0.15s }
  .schol-list-item:hover { background:var(--green-soft);margin:0 -1.2rem;padding-left:1.2rem;padding-right:1.2rem;border-radius:10px;border-bottom-color:transparent }
  .schol-list-info { flex:1 }
  .schol-list-title { font-family:'Playfair Display',Georgia,serif;font-size:1.05rem;font-weight:700;color:var(--dark);line-height:1.4;margin-bottom:0.35rem }
  .schol-list-uni { font-size:0.85rem;color:var(--gray);font-weight:500;margin-bottom:0.75rem }
  .schol-list-tags { display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:0.9rem }
  .stag { font-size:0.68rem;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;padding:0.22rem 0.65rem;border-radius:20px }
  .stag-masters { background:var(--green-pale);color:var(--green-deep) }
  .stag-undergrad { background:rgba(244,196,48,0.12);color:#9a7300 }
  .stag-phd { background:rgba(100,60,200,0.08);color:#5a30c0 }
  .stag-open { background:rgba(46,204,142,0.08);color:var(--green-dark) }
  .stag-nz { background:rgba(0,0,0,0.04);color:#888 }
  .schol-see-details { display:inline-flex;align-items:center;gap:0.35rem;padding:0.5rem 1.1rem;border-radius:50px;border:1.5px solid var(--gray-light);font-size:0.78rem;font-weight:700;color:var(--dark);text-decoration:none;transition:all 0.2s;background:#fff }
  .schol-see-details:hover { border-color:var(--green-dark);color:var(--green-dark);background:var(--green-pale) }
  .schol-list-logo { width:110px;height:72px;flex-shrink:0;display:flex;align-items:center;justify-content:center }
  .schol-logo-img { width:90px;height:64px;object-fit:cover;border-radius:8px;border:1px solid var(--gray-light) }
  .schol-logo-fallback { width:90px;height:64px;background:var(--green-soft);border:1px solid var(--green-mid);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:0.65rem;font-weight:800;color:var(--green-deep);text-align:center;padding:0.3rem }
  .browse-more { text-align:center;padding-top:0.5rem }
  .btn-outline-dark { display:inline-flex;align-items:center;gap:0.5rem;border:1.5px solid var(--dark);color:var(--dark);padding:0.8rem 2rem;border-radius:50px;font-size:0.84rem;font-weight:700;letter-spacing:0.04em;text-transform:uppercase;text-decoration:none;transition:all 0.2s;cursor:pointer;background:transparent;font-family:inherit }
  .btn-outline-dark:hover { background:var(--dark);color:#fff }

  /* ─── ELIGIBILITY ─── */
  .eligibility-section { background:var(--dark);padding:5rem 4rem }
  .elig-inner { max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:5rem;align-items:center }
  .elig-left .eyebrow-tag { color:rgba(255,255,255,0.35) }
  .elig-left .eyebrow-tag::before { background:var(--green) }
  .elig-left h2 { color:#fff }
  .elig-left h2 em { color:var(--green) }
  .elig-left p { color:#666;font-size:0.9rem;line-height:1.8;margin-bottom:1.5rem;font-weight:300 }
  .elig-list { list-style:none;display:flex;flex-direction:column;gap:0.75rem;margin-bottom:2rem }
  .elig-list li { display:flex;align-items:flex-start;gap:0.75rem;font-size:0.86rem;color:#aaa;line-height:1.5 }
  .elig-check { width:20px;height:20px;background:rgba(46,204,142,0.12);border:1px solid rgba(46,204,142,0.3);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;font-size:0.62rem;color:var(--green) }
  .elig-right { display:flex;flex-direction:column;gap:1rem }
  .elig-card { background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:1.4rem 1.6rem;display:flex;align-items:flex-start;gap:1rem;transition:all 0.2s }
  .elig-card:hover { background:rgba(46,204,142,0.06);border-color:rgba(46,204,142,0.2) }
  .elig-card-num { font-family:'Playfair Display',Georgia,serif;font-size:1.3rem;font-weight:700;color:var(--green);line-height:1;flex-shrink:0;min-width:28px }
  .elig-card h4 { font-size:0.88rem;font-weight:700;color:#fff;margin-bottom:0.3rem }
  .elig-card p { font-size:0.79rem;color:#666;line-height:1.6;font-weight:300 }

  /* ─── CTA BANNER ─── */
  .cta-banner { background:var(--green-dark);padding:64px 60px;display:flex;align-items:center;justify-content:space-between;position:relative;overflow:hidden;gap:40px }
  .cta-watermark { position:absolute;right:-10px;top:50%;transform:translateY(-50%);font-family:'Playfair Display',Georgia,serif;font-size:clamp(5rem,12vw,9rem);font-weight:700;color:rgba(255,255,255,0.07);letter-spacing:4px;white-space:nowrap;pointer-events:none;user-select:none;line-height:1 }
  .cta-left { position:relative;z-index:1;max-width:560px }
  .cta-left h2 { font-family:'Playfair Display',Georgia,serif;font-size:clamp(1.7rem,3.5vw,2.4rem);font-weight:700;color:#fff;line-height:1.25;margin-bottom:14px }
  .cta-left h2 em { font-style:italic }
  .cta-left p { font-size:0.87rem;color:rgba(255,255,255,0.7);line-height:1.6;font-weight:300 }
  .cta-right { position:relative;z-index:1;flex-shrink:0 }
  .cta-apply-btn { display:inline-flex;align-items:center;gap:10px;background:#fff;color:var(--green-dark);padding:14px 30px;border-radius:50px;font-size:0.88rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;text-decoration:none;transition:all .2s;white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,0.15) }
  .cta-apply-btn:hover { background:var(--dark);color:#fff;transform:translateY(-2px) }

  /* ─── FOOTER ─── */
  footer { background:#0a120e;padding:60px 0 0;border-top:1px solid #1a2a20 }
  .footer-inner { max-width:1100px;margin:0 auto;padding:0 40px }
  .footer-top { display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px;padding-bottom:40px;border-bottom:1px solid #1a2a20 }
  .footer-logo { font-family:'DM Sans',sans-serif;font-size:1.3rem;font-weight:800;letter-spacing:1.5px;color:#fff;display:block;margin-bottom:14px;text-decoration:none }
  .footer-logo span { color:var(--green) }
  .footer-brand p { font-size:0.83rem;color:#555;line-height:1.7;max-width:240px;font-weight:300 }
  .footer-social { display:flex;gap:0.6rem;margin-top:1.5rem }
  .footer-social a { width:34px;height:34px;background:rgba(255,255,255,0.06);border-radius:6px;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,0.4);text-decoration:none;font-size:0.72rem;font-weight:800;transition:all 0.2s }
  .footer-social a:hover { background:var(--green-dark);color:#fff }
  .footer-col h4 { color:#fff;font-size:0.78rem;font-weight:700;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid #1a2a20 }
  .footer-col ul { list-style:none }
  .footer-col ul li { margin-bottom:10px }
  .footer-col ul li a { color:#555;text-decoration:none;font-size:0.83rem;transition:color .2s;display:inline-flex;align-items:center;gap:0.4rem }
  .footer-col ul li a::before { content:'›';color:#2a3a2e;font-size:1rem }
  .footer-col ul li a:hover { color:var(--green) }
  .footer-contact-item { display:flex;align-items:flex-start;gap:0.7rem;margin-bottom:12px }
  .footer-contact-icon { width:30px;height:30px;background:rgba(46,204,142,0.07);border:1px solid rgba(46,204,142,0.12);border-radius:7px;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:0.8rem;margin-top:1px }
  .footer-contact-text { font-size:0.82rem;color:#555;line-height:1.55 }
  .footer-contact-text a { color:#555;text-decoration:none;transition:color 0.2s }
  .footer-contact-text a:hover { color:var(--green) }
  .footer-bottom { display:flex;justify-content:space-between;align-items:center;padding:20px 0;font-size:0.78rem;color:#333;flex-wrap:wrap;gap:10px }
  .footer-bottom-links { display:flex;gap:1.5rem }
  .footer-bottom-links a { color:#3a3a3a;text-decoration:none;font-size:0.75rem;transition:color 0.2s }
  .footer-bottom-links a:hover { color:var(--green) }
  .footer-dots { display:flex;gap:6px;align-items:center }
  .dot { width:8px;height:8px;border-radius:50% }

  @keyframes fadeUp { from{opacity:0;transform:translateY(22px)} to{opacity:1;transform:translateY(0)} }
  @keyframes spin   { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }

  @media(max-width:900px) {
    nav{padding:14px 20px}.schol-hero{grid-template-columns:1fr}.hero-right{display:none}.hero-left{padding:4rem 2rem}
    .intro-section{grid-template-columns:1fr;padding:3rem 2rem;gap:2.5rem}.steps-row{grid-template-columns:repeat(2,1fr)}.steps-row::before{display:none}
    .search-section,.how-section,.eligibility-section{padding:4rem 2rem}.elig-inner{grid-template-columns:1fr;gap:2.5rem}
    .cta-banner{flex-direction:column;text-align:center;padding:48px 28px}.footer-top{grid-template-columns:1fr 1fr}.footer-inner{padding:0 20px}
  }
  @media(max-width:600px) {
    .steps-row{grid-template-columns:1fr 1fr}.footer-top{grid-template-columns:1fr}.schol-list-item{flex-direction:column;align-items:flex-start}
  }
</style>
</head>
<body>

<!-- NAV -->
<nav id="mainNav">
  <a href="index.php" class="nav-logo">GLOBAL <span>RX</span></a>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <button class="nav-btn" onclick="window.location='signup.html'">Sign Up</button>
  <?php endif; ?>
</nav>

<!-- HERO -->
<section class="schol-hero" id="home">
  <div class="hero-circle-1"></div>
  <div class="hero-circle-2"></div>
  <div class="hero-circle-3"></div>
  <div class="hero-circle-4"></div>
  <div class="hero-left">
    <div class="hero-breadcrumb">
      <span>Home</span><span class="sep">›</span>
      <span>A-Squared Higher Education</span><span class="sep">›</span>
      <span class="current">Scholarships</span>
    </div>
    <span class="hero-eyebrow">International Scholarships</span>
    <h1>Find Your <em>Perfect</em><br>Scholarship with Us</h1>
    <p class="hero-desc">Global RX Business Ltd connects ambitious students with world-leading universities across 40+ countries — opening doors to undergraduate and postgraduate scholarships you might never find alone.</p>
    <div class="hero-actions">
      <a href="#search" class="btn-green">Explore Scholarships →</a>
      <a href="#how" class="btn-ghost">How It Works</a>
    </div>
    <div class="hero-stats-row">
      <div><div class="hstat-num">150<span>+</span></div><div class="hstat-lbl">Universities</div></div>
      <div><div class="hstat-num">40<span>+</span></div><div class="hstat-lbl">Countries</div></div>
      <div><div class="hstat-num">95<span>%</span></div><div class="hstat-lbl">Success Rate</div></div>
    </div>
  </div>
  <div class="hero-right">
    <div class="hero-photo-wrap">
      <img src="images/scholarship.jpg.jpeg" alt="Students with scholarships" class="hero-photo"/>
    </div>
  </div>
</section>

<!-- STATS BAR -->
<div class="stats-strip" id="statsBar">
  <div class="strip-item"><span class="strip-num" data-target="1200">0</span><span style="font-family:'Playfair Display',serif;font-size:1.45rem;font-weight:700;color:#fff">+</span><span class="strip-lbl">Students Placed</span></div>
  <div class="strip-item"><span class="strip-num" data-target="150">0</span><span style="font-family:'Playfair Display',serif;font-size:1.45rem;font-weight:700;color:#fff">+</span><span class="strip-lbl">Partner Universities</span></div>
  <div class="strip-item"><span class="strip-num" data-target="95">0</span><span style="font-family:'Playfair Display',serif;font-size:1.45rem;font-weight:700;color:#fff">%</span><span class="strip-lbl">Placement Rate</span></div>
  <div class="strip-item"><span class="strip-num" data-target="40">0</span><span style="font-family:'Playfair Display',serif;font-size:1.45rem;font-weight:700;color:#fff">+</span><span class="strip-lbl">Partner Countries</span></div>
</div>

<!-- INTRO -->
<div class="intro-section">
  <div class="intro-left">
    <div class="eyebrow-tag">About Our Scholarships</div>
    <h2>A-Squared Higher Education plays a <em>vital role</em> in your future</h2>
    <p>The higher education sector at Global RX Business Ltd leads in organising and directing international scholarship access. We develop partnerships with universities worldwide to enable two-way information exchange and increase opportunities for both undergraduate and postgraduate students.</p>
    <p>A scholarship could empower you to study abroad without financial burden — opening a lifetime of career and academic opportunity.</p>
    <a href="#search" class="intro-cta-link">Browse all scholarships →</a>
  </div>
  <div class="intro-right">
    <div class="info-card"><div class="info-icon">🌐</div><div><h4>Global Education Providers</h4><p>Many leading global education providers offer scholarships to international students through our network.</p></div></div>
    <div class="info-card"><div class="info-icon">📋</div><div><h4>Clear Eligibility Criteria</h4><p>Every scholarship lists transparent eligibility requirements — country, field, and academic level.</p></div></div>
    <div class="info-card"><div class="info-icon">🤝</div><div><h4>Full Application Support</h4><p>Our advisors guide you through every stage of the application, improving your chances of success.</p></div></div>
  </div>
</div>

<!-- HOW IT WORKS -->
<section class="how-section" id="how">
  <div class="how-header">
    <span class="eyebrow">The Process</span>
    <h2>Finding a <em>Scholarship</em></h2>
    <p>Scholarships can be highly competitive. We account for all relevant factors and allow you to apply with time and confidence.</p>
  </div>
  <div class="steps-row">
    <div class="step"><div class="step-circle">1</div><h3>Check Eligibility</h3><p>Review criteria — country of origin, field of study, academic level, and language requirements.</p></div>
    <div class="step"><div class="step-circle">2</div><h3>Explore Options</h3><p>Browse verified scholarships filtered by destination, level, and area of study.</p></div>
    <div class="step"><div class="step-circle">3</div><h3>Get Expert Guidance</h3><p>Work one-on-one with our counsellors to prepare a compelling application package.</p></div>
    <div class="step"><div class="step-circle">4</div><h3>Apply Early</h3><p>Submit well ahead of deadlines. Early applications consistently achieve better outcomes.</p></div>
  </div>
</section>

<!-- SEARCH + SCHOLARSHIPS -->
<section class="search-section" id="search">
  <div class="search-header">
    <h2 style="font-size:clamp(1.8rem,3vw,2.6rem);margin-bottom:1.8rem;">Find a Scholarship</h2>
    <div class="schol-search-row">
      <div class="schol-search-input-wrap">
        <input type="text" placeholder="Search by name, university or country…" id="searchInput" class="schol-search-input">
        <svg class="schol-search-icon" width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      </div>
      <select id="filterLevel" class="schol-filter-btn" style="appearance:auto">
        <option value="">All Levels</option>
        <option value="Undergraduate">Undergraduate</option>
        <option value="Postgraduate">Postgraduate</option>
        <option value="PhD">PhD</option>
        <option value="All Levels">All Levels</option>
      </select>
      <select id="filterCountry" class="schol-filter-btn" style="appearance:auto">
        <option value="">All Countries</option>
      </select>
    </div>
  </div>

  <div class="schol-meta-row">
    <span>Showing <strong id="scholCount">0</strong> scholarship<span id="scholPlural">s</span></span>
    <span style="display:flex;align-items:center;gap:6px">
      Sort by
      <select id="sortBy" style="border:none;border-bottom:1.5px solid var(--gray-light);font-family:inherit;font-size:0.83rem;font-weight:700;color:var(--dark);background:transparent;cursor:pointer;padding:0 4px;outline:none;appearance:auto;">
        <option value="az">A → Z</option>
        <option value="za">Z → A</option>
        <option value="level">Academic Level</option>
        <option value="country">Country</option>
      </select>
    </span>
  </div>

  <div class="schol-list" id="scholList"></div>

  <div class="browse-more" style="margin-top:2rem;display:none" id="browseMoreRow">
    <button class="btn-outline-dark" id="showAllBtn">View All Scholarships →</button>
  </div>
</section>

<!-- ELIGIBILITY -->
<section class="eligibility-section">
  <div class="elig-inner">
    <div class="elig-left">
      <div class="eyebrow-tag">Eligibility</div>
      <h2>Do You <em>Qualify</em> for an International Scholarship?</h2>
      <p>Check the below details to improve your chances of securing an international scholarship.</p>
      <ul class="elig-list">
        <li><span class="elig-check">✓</span>Citizenship or residency in an eligible country</li>
        <li><span class="elig-check">✓</span>Minimum academic qualification in relevant field</li>
        <li><span class="elig-check">✓</span>Demonstrated English language proficiency</li>
        <li><span class="elig-check">✓</span>Meeting the age and study-level requirements</li>
        <li><span class="elig-check">✓</span>Financial need or merit-based assessment</li>
      </ul>
      <a href="#search" class="btn-green">Check My Eligibility →</a>
    </div>
    <div class="elig-right">
      <div class="elig-card"><div class="elig-card-num">01</div><div><h4>Country of Origin</h4><p>Many scholarships are targeted at students from specific nations. We'll match you to the right ones.</p></div></div>
      <div class="elig-card"><div class="elig-card-num">02</div><div><h4>Field of Study</h4><p>Scholarships are often aligned with specific academic disciplines. Explore opportunities in your area.</p></div></div>
      <div class="elig-card"><div class="elig-card-num">03</div><div><h4>Academic Level</h4><p>Whether applying for undergraduate, Masters, or PhD programmes, we have options for each level.</p></div></div>
      <div class="elig-card"><div class="elig-card-num">04</div><div><h4>Learning Potential</h4><p>Many providers assess demonstrated academic ability and motivation alongside formal qualifications.</p></div></div>
    </div>
  </div>
</section>

<!-- CTA BANNER -->
<section class="cta-banner">
  <div class="cta-watermark">SCHOLARSHIPS</div>
  <div class="cta-left">
    <h2>Ready to Begin Your<br><em>International Journey</em>?</h2>
    <p>Applications are open. Speak with our advisors today and take the first step toward your future.</p>
  </div>
  <div class="cta-right">
    <a href="contactus.html" class="cta-apply-btn">Apply Now →</a>
  </div>
</section>

<!-- FOOTER -->
<footer id="contact">
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <a href="index.php" class="footer-logo">GLOBAL <span>RX</span></a>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
        <div class="footer-social">
          <a href="#" title="Facebook">f</a><a href="#" title="LinkedIn">in</a>
          <a href="#" title="Instagram">ig</a><a href="#" title="Twitter">𝕏</a>
        </div>
      </div>
      <div class="footer-col"><h4>Pages</h4><ul><li><a href="index.php">Home</a></li><li><a href="aboutus.html">About Us</a></li><li><a href="scholarship.php">Scholarships</a></li><li><a href="contactus.php">Contact Us</a></li></ul></div>
      <div class="footer-col"><h4>Subsidiaries</h4><ul><li><a href="visa.php">A² Visa Consultation</a></li><li><a href="higherEducation.php">A² Higher Education</a></li><li><a href="english.php">A² English Academy</a></li></ul></div>
      <div class="footer-col">
        <h4>Contact</h4>
        <ul>
          <li><div class="footer-contact-item"><div class="footer-contact-icon">✉</div><div class="footer-contact-text"><a href="mailto:info@globalrx.com">info@globalrx.com</a></div></div></li>
          <li><div class="footer-contact-item"><div class="footer-contact-icon">📞</div><div class="footer-contact-text"><a href="tel:+18000000000">+1 (800) 000-0000</a></div></div></li>
          <li><div class="footer-contact-item"><div class="footer-contact-icon">📍</div><div class="footer-contact-text">Colombo, Sri Lanka</div></div></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span style="color:#333;">© 2026 Global RX Business Ltd. All rights reserved.</span>
      <div class="footer-bottom-links">
        <a href="#">Privacy Policy</a><a href="#">Terms of Use</a><a href="#">Sitemap</a>
      </div>
      <div class="footer-dots">
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--green-dark)"></div>
        <div class="dot" style="background:var(--green-deep)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
const PAGE_SIZE = 6;
let _allData    = [];
let _showingAll = false;

function setLoading() {
  document.getElementById('scholList').innerHTML = `
    <div style="text-align:center;padding:3rem 1rem;color:#aaa">
      <div style="font-size:2rem;margin-bottom:0.75rem;display:inline-block;animation:spin 1s linear infinite">⏳</div>
      <p style="font-size:0.9rem;color:var(--text-light)">Loading scholarships…</p>
    </div>`;
}

function levelTag(level) {
  const m = { 'Undergraduate':'stag-undergrad','Postgraduate':'stag-masters','PhD':'stag-phd','All Levels':'stag-open' };
  return level ? `<span class="stag ${m[level]||'stag-nz'}">${level}</span>` : '';
}
function countryTag(country) { return country ? `<span class="stag stag-nz">${country}</span>` : ''; }
function initials(name) { return (name||'S').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase(); }

function renderItem(r) {
  const name       = r.sName      || 'Unnamed Scholarship';
  const level      = r.academicLevel || '';
  const university = r.university || '';
  const country    = r.country    || '';
  const imageUrl   = r.imageUrl   || '';
  const logoHtml   = imageUrl
    ? `<img src="${imageUrl}" alt="${name}" class="schol-logo-img" onerror="this.outerHTML='<div class=\'schol-logo-fallback\'>${initials(name)}</div>'">`
    : `<div class="schol-logo-fallback">${initials(name)}</div>`;
  return `
    <div class="schol-list-item">
      <div class="schol-list-info">
        <h3 class="schol-list-title">${name}</h3>
        <p class="schol-list-uni">${university}${university&&country?' · ':''}${country}</p>
        <div class="schol-list-tags">${levelTag(level)}${countryTag(country)}</div>
        <a href="contactus.html" class="schol-see-details">Apply / Enquire <svg width="11" height="11" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path d="M7 17L17 7M7 7h10v10"/></svg></a>
      </div>
      <div class="schol-list-logo">${logoHtml}</div>
    </div>`;
}

function populateCountryFilter(data) {
  const countries = [...new Set(data.map(r=>r.country).filter(Boolean))].sort();
  const sel = document.getElementById('filterCountry');
  const cur = sel.value;
  sel.innerHTML = '<option value="">All Countries</option>' + countries.map(c=>`<option value="${c}"${cur===c?' selected':''}>${c}</option>`).join('');
}

function renderList() {
  const q        = (document.getElementById('searchInput').value||'').toLowerCase().trim();
  const fLevel   = document.getElementById('filterLevel').value;
  const fCountry = document.getElementById('filterCountry').value;
  const sortMode = document.getElementById('sortBy').value;

  let filtered = _allData.filter(r => {
    const matchQ = !q||(r.sName||'').toLowerCase().includes(q)||(r.university||'').toLowerCase().includes(q)||(r.country||'').toLowerCase().includes(q)||(r.academicLevel||'').toLowerCase().includes(q);
    const matchL = !fLevel  ||r.academicLevel===fLevel;
    const matchC = !fCountry||r.country===fCountry;
    return matchQ&&matchL&&matchC;
  });

  filtered.sort((a,b)=>{
    switch(sortMode){
      case 'za':      return(b.sName||'').localeCompare(a.sName||'');
      case 'level':   return(a.academicLevel||'').localeCompare(b.academicLevel||'');
      case 'country': return(a.country||'').localeCompare(b.country||'');
      default:        return(a.sName||'').localeCompare(b.sName||'');
    }
  });

  const count = filtered.length;
  document.getElementById('scholCount').textContent  = count;
  document.getElementById('scholPlural').textContent = count===1?'':'s';

  const toShow = _showingAll ? filtered : filtered.slice(0, PAGE_SIZE);
  const list   = document.getElementById('scholList');
  if (!filtered.length) {
    list.innerHTML = `<div style="text-align:center;padding:3rem 1rem;color:#aaa"><div style="font-size:2.5rem;margin-bottom:1rem">🔍</div><p style="font-size:1rem;font-weight:600;color:var(--text-light)">No scholarships found</p><p style="font-size:0.85rem;margin-top:0.5rem">Try adjusting your search or filters.</p></div>`;
  } else {
    list.innerHTML = toShow.map(renderItem).join('');
  }

  const moreRow = document.getElementById('browseMoreRow');
  const btn     = document.getElementById('showAllBtn');
  if (filtered.length > PAGE_SIZE) {
    moreRow.style.display = '';
    btn.textContent = _showingAll ? 'Show Fewer ↑' : `View All ${filtered.length} Scholarships →`;
  } else { moreRow.style.display = 'none'; }

  list.querySelectorAll('.schol-list-item').forEach(el => { el.style.opacity='0'; revealObs.observe(el); });
}

document.getElementById('searchInput') .addEventListener('input',  ()=>{_showingAll=false;renderList()});
document.getElementById('filterLevel') .addEventListener('change', ()=>{_showingAll=false;renderList()});
document.getElementById('filterCountry').addEventListener('change',()=>{_showingAll=false;renderList()});
document.getElementById('sortBy')      .addEventListener('change', ()=>{_showingAll=false;renderList()});
document.getElementById('showAllBtn')  .addEventListener('click',  ()=>{_showingAll=!_showingAll;renderList()});

const revealObs = new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.style.animation='fadeUp 0.55s ease forwards';revealObs.unobserve(e.target)}});
},{threshold:0.08});

function animateCount(el,target,duration){
  let start=0;const step=target/(duration/16);
  const timer=setInterval(()=>{start+=step;if(start>=target){el.textContent=target;clearInterval(timer)}else el.textContent=Math.floor(start)},16);
}
let statsAnimated=false;
const statsBar  =document.getElementById('statsBar');
const stripItems=statsBar.querySelectorAll('.strip-item');
const stripNums =statsBar.querySelectorAll('.strip-num');
const statsObs  =new IntersectionObserver(entries=>{
  if(entries[0].isIntersecting&&!statsAnimated){
    statsAnimated=true;
    stripItems.forEach((item,i)=>setTimeout(()=>item.classList.add('visible'),i*120));
    stripNums.forEach((el,i)=>{const t=parseInt(el.dataset.target);setTimeout(()=>animateCount(el,t,1400),i*120)});
  }
},{threshold:0.3});
statsObs.observe(statsBar);

document.querySelectorAll('.info-card,.step,.elig-card').forEach(el=>{el.style.opacity='0';revealObs.observe(el)});

const navEl=document.getElementById('mainNav');
window.addEventListener('scroll',()=>{navEl.style.boxShadow=window.scrollY>40?'0 8px 32px rgba(0,0,0,0.1)':'0 4px 20px rgba(0,0,0,0.05)'});

window.toggleDropdown=function(){document.getElementById('divDropdown').classList.toggle('open')};
document.addEventListener('click',e=>{const dd=document.getElementById('divDropdown');if(!dd.contains(e.target))dd.classList.remove('open')});

/* ── User menu ── */
const navUserToggle=document.getElementById('navUserToggle');
const navUserMenu  =document.getElementById('navUserMenu');
if(navUserToggle&&navUserMenu){
  navUserToggle.addEventListener('click',e=>{e.stopPropagation();const isOpen=navUserMenu.classList.toggle('open');navUserToggle.setAttribute('aria-expanded',isOpen)});
  document.addEventListener('click',e=>{const navUser=document.getElementById('navUser');if(navUser&&!navUser.contains(e.target)){navUserMenu.classList.remove('open');navUserToggle.setAttribute('aria-expanded','false')}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){navUserMenu.classList.remove('open');navUserToggle.setAttribute('aria-expanded','false')}});
}

document.querySelectorAll('a[href^="#"]').forEach(a=>{a.addEventListener('click',e=>{e.preventDefault();const t=document.querySelector(a.getAttribute('href'));if(t)t.scrollIntoView({behavior:'smooth'})})});

/* ── Load scholarships ── */
setLoading();
fetch('get_scholarships.php')
  .then(res=>res.json())
  .then(data=>{
    if(!data.success) throw new Error(data.message||'Failed to load.');
    _allData=data.scholarships||[];
    if(!_allData.length){
      document.getElementById('scholList').innerHTML=`<div style="text-align:center;padding:3rem 1rem;color:#aaa"><div style="font-size:2.5rem;margin-bottom:1rem">📭</div><p style="font-size:1rem;font-weight:600;color:var(--text-light)">No scholarships available yet.</p></div>`;
      document.getElementById('scholCount').textContent='0';return;
    }
    populateCountryFilter(_allData);renderList();
  })
  .catch(err=>{
    console.error('Failed to load scholarships:',err);
    document.getElementById('scholList').innerHTML=`<div style="text-align:center;padding:3rem 1rem"><div style="font-size:2.5rem;margin-bottom:1rem">⚠️</div><p style="font-size:1rem;font-weight:600;color:#e05c5c">Failed to load scholarships.</p></div>`;
    document.getElementById('scholCount').textContent='0';
  });
</script>
</body>
</html>