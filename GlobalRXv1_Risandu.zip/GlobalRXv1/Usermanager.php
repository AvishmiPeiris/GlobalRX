<?php
/**
 * UserManager.php  —  GlobalRX
 *
 * Handles user sign-up, sign-in, password reset, and user listing
 * using Firebase Authentication (identitytoolkit REST API) and
 * Cloud Firestore (REST API) → collection: "users"
 */
require_once __DIR__ . '/config.php';

class UserManager
{
    private string $projectId;
    private string $apiKey;
    private string $firestoreBase;
    private string $authSignUpUrl;
    private string $authSignInUrl;
    private string $authResetUrl;

    private array $certPaths = [
        'C:/xampp/php/extras/ssl/cacert.pem',
        'C:/xampp/apache/conf/ssl.crt/cacert.pem',
        'C:/xampp/php/cacert.pem',
        'C:/wamp64/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/wamp/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/curl/cacert.pem',
    ];

    public function __construct()
    {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;

        $this->firestoreBase = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                             . "/databases/(default)/documents/users";

        $this->authSignUpUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={$this->apiKey}";
        $this->authSignInUrl = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={$this->apiKey}";
        $this->authResetUrl  = "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={$this->apiKey}";
    }

    /* ── CA certificate path (SSL fix for WAMP/XAMPP) ── */
    private function getCertPath(): string
    {
        $ini = ini_get('curl.cainfo');
        if ($ini && file_exists($ini)) return $ini;
        foreach ($this->certPaths as $p) {
            if (file_exists($p)) return $p;
        }
        $local = __DIR__ . '/cacert.pem';
        return file_exists($local) ? $local : '';
    }

    /* ── Generic cURL helper ── */
    private function request(string $method, string $url, ?array $body = null): array
    {
        $certPath = $this->getCertPath();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 20,
        ]);
        if ($certPath !== '') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_CAINFO, $certPath);
        } else {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr)   return ['success' => false, 'message' => "cURL error: $curlErr"];
        if (!$response) return ['success' => false, 'message' => "Empty response (HTTP $httpCode)"];

        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP $httpCode";
            return ['success' => false, 'message' => $msg];
        }
        return ['success' => true, 'data' => $data];
    }

    /* ── Extract value from Firestore typed-value map ── */
    private function extractValue(array $tv): mixed
    {
        if (isset($tv['stringValue']))          return (string) $tv['stringValue'];
        if (isset($tv['integerValue']))         return (int)    $tv['integerValue'];
        if (isset($tv['doubleValue']))          return (float)  $tv['doubleValue'];
        if (isset($tv['booleanValue']))         return (bool)   $tv['booleanValue'];
        if (array_key_exists('nullValue', $tv)) return null;
        if (isset($tv['timestampValue'])) {
            try {
                $dt = new DateTime($tv['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                return $dt->format('d M Y, H:i');
            } catch (Exception) { return $tv['timestampValue']; }
        }
        return '';
    }

    /* ── Parse a Firestore user document into a clean PHP array ── */
    private function parseUserDoc(array $doc): array
    {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');

        /* Sort key from createdAt */
        $sortKey   = 0;
        $createdAt = '';
        if (isset($fields['createdAt']['timestampValue'])) {
            try {
                $dt        = new DateTime($fields['createdAt']['timestampValue']);
                $sortKey   = $dt->getTimestamp();
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                $createdAt = $dt->format('d M Y, H:i');
            } catch (Exception) { $createdAt = $fields['createdAt']['timestampValue']; }
        } elseif (isset($fields['createdAt']['stringValue'])) {
            $createdAt = $fields['createdAt']['stringValue'];
        }

        $lastLogin = '';
        if (isset($fields['lastLogin']['timestampValue'])) {
            try {
                $dt        = new DateTime($fields['lastLogin']['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                $lastLogin = $dt->format('d M Y, H:i');
            } catch (Exception) { $lastLogin = $fields['lastLogin']['timestampValue']; }
        } elseif (isset($fields['lastLogin']['stringValue'])) {
            $lastLogin = $fields['lastLogin']['stringValue'];
        }

        $age = '';
        if (isset($fields['age'])) {
            $raw = $this->extractValue($fields['age']);
            $age = ($raw !== null && $raw !== '') ? (string)(int)$raw : '';
        }

        return [
            'id'        => $id,
            'firstName' => isset($fields['firstName'])  ? (string)$this->extractValue($fields['firstName'])  : '',
            'lastName'  => isset($fields['lastName'])   ? (string)$this->extractValue($fields['lastName'])   : '',
            'fullName'  => isset($fields['fullName'])   ? (string)$this->extractValue($fields['fullName'])   : '',
            'email'     => isset($fields['email'])      ? (string)$this->extractValue($fields['email'])      : '',
            'dob'       => isset($fields['dob'])        ? (string)$this->extractValue($fields['dob'])        : '',
            'age'       => $age,
            'telephone' => isset($fields['telephone'])  ? (string)$this->extractValue($fields['telephone'])  : '',
            'country'   => isset($fields['country'])    ? (string)$this->extractValue($fields['country'])    : '',
            'role'      => isset($fields['role'])       ? (string)$this->extractValue($fields['role'])       : 'user',
            'status'    => isset($fields['status'])     ? (string)$this->extractValue($fields['status'])     : 'active',
            'createdAt' => $createdAt,
            'lastLogin' => $lastLogin,
            '_sortKey'  => $sortKey,
        ];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: GET ALL USERS from Firestore
       ══════════════════════════════════════════════ */
    public function getAllUsers(): array
    {
        $url    = $this->firestoreBase . "?key=" . urlencode($this->apiKey);
        $result = $this->request('GET', $url);

        if (!$result['success']) return $result;

        $users = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $parsed = $this->parseUserDoc($doc);
            if (!empty($parsed['id'])) $users[] = $parsed;
        }

        /* Sort newest first */
        usort($users, fn($a, $b) => $b['_sortKey'] <=> $a['_sortKey']);

        return ['success' => true, 'users' => $users];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: UPDATE USER role / status
       ══════════════════════════════════════════════ */
    public function updateUser(string $uid, string $role, string $status): array
    {
        if (empty(trim($uid))) return ['success' => false, 'message' => 'User ID is required.'];

        $mask = 'updateMask.fieldPaths=role&updateMask.fieldPaths=status';
        $url  = $this->firestoreBase . "/{$uid}?{$mask}&key=" . urlencode($this->apiKey);

        $res = $this->request('PATCH', $url, [
            'fields' => [
                'role'   => ['stringValue' => $role],
                'status' => ['stringValue' => $status],
            ]
        ]);
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => "User updated successfully."];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: DELETE USER from Firestore
       (Note: does not delete from Firebase Auth)
       ══════════════════════════════════════════════ */
    public function deleteUser(string $uid): array
    {
        if (empty(trim($uid))) return ['success' => false, 'message' => 'User ID is required.'];

        $url    = $this->firestoreBase . "/{$uid}?key=" . urlencode($this->apiKey);
        $result = $this->request('DELETE', $url);
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'User deleted successfully.'];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: SIGN UP
       ══════════════════════════════════════════════ */
    public function signUp(string $firstName, string $lastName, string $dob,
        string $telephone, string $country, string $email, string $password): array
    {
        if (!$firstName || !$lastName) return ['success' => false, 'message' => 'Name fields are required.'];
        if (!$email)                   return ['success' => false, 'message' => 'Email is required.'];
        if (!$password)                return ['success' => false, 'message' => 'Password is required.'];

        $authResult = $this->request('POST', $this->authSignUpUrl, [
            'email'             => $email,
            'password'          => $password,
            'displayName'       => "$firstName $lastName",
            'returnSecureToken' => true,
        ]);
        if (!$authResult['success']) return $authResult;

        $uid = $authResult['data']['localId'] ?? null;
        if (!$uid) return ['success' => false, 'message' => 'Firebase did not return a user ID.'];

        $firestoreUrl = $this->firestoreBase
                      . "?documentId=" . urlencode($uid)
                      . "&key=" . urlencode($this->apiKey);

        $age = 0;
        try {
            $birth = new DateTime($dob);
            $age   = (int)(new DateTime())->diff($birth)->y;
        } catch (Exception) {}

        $dbResult = $this->request('POST', $firestoreUrl, [
            'fields' => [
                'firstName' => ['stringValue'    => $firstName],
                'lastName'  => ['stringValue'    => $lastName],
                'fullName'  => ['stringValue'    => trim("$firstName $lastName")],
                'email'     => ['stringValue'    => $email],
                'dob'       => ['stringValue'    => $dob],
                'age'       => ['integerValue'   => $age],
                'telephone' => ['stringValue'    => $telephone],
                'country'   => ['stringValue'    => $country],
                'role'      => ['stringValue'    => 'user'],
                'status'    => ['stringValue'    => 'active'],
                'createdAt' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
                'lastLogin' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
            ]
        ]);

        if (!$dbResult['success']) {
            return ['success' => false, 'message' => 'Account created in Auth but profile save failed: ' . $dbResult['message']];
        }

        return ['success' => true, 'message' => 'Account created successfully!', 'uid' => $uid];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: SIGN IN
       ══════════════════════════════════════════════ */
    public function signIn(string $email, string $password): array
    {
        $authResult = $this->request('POST', $this->authSignInUrl, [
            'email'             => $email,
            'password'          => $password,
            'returnSecureToken' => true,
        ]);
        if (!$authResult['success']) return $authResult;

        $uid = $authResult['data']['localId'] ?? null;
        if (!$uid) return ['success' => false, 'message' => 'Could not retrieve user ID after sign-in.'];

        $profileUrl = $this->firestoreBase . "/{$uid}?key=" . urlencode($this->apiKey);
        $userResult = $this->request('GET', $profileUrl);

        if (!$userResult['success']) {
            return ['success' => true, 'message' => 'Login successful', 'user' => [
                'uid' => $uid, 'name' => $authResult['data']['displayName'] ?? '', 'email' => $email,
            ]];
        }

        $fields = $userResult['data']['fields'] ?? [];

        /* Update lastLogin */
        $patchUrl = $this->firestoreBase
                  . "/{$uid}?updateMask.fieldPaths=lastLogin&key=" . urlencode($this->apiKey);
        $this->request('PATCH', $patchUrl, [
            'fields' => ['lastLogin' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')]]
        ]);

        return ['success' => true, 'message' => 'Login successful', 'user' => [
            'uid'       => $uid,
            'name'      => $fields['fullName']['stringValue']  ?? '',
            'firstName' => $fields['firstName']['stringValue'] ?? '',
            'email'     => $fields['email']['stringValue']     ?? $email,
            'country'   => $fields['country']['stringValue']   ?? '',
            'role'      => $fields['role']['stringValue']      ?? 'user',
        ]];
    }

    /* ══════════════════════════════════════════════
       PUBLIC: PASSWORD RESET
       ══════════════════════════════════════════════ */
    public function resetPassword(string $email): array
    {
        if (!$email) return ['success' => false, 'message' => 'Email address is required.'];
        $result = $this->request('POST', $this->authResetUrl, [
            'requestType' => 'PASSWORD_RESET',
            'email'       => $email,
        ]);
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Password reset email sent. Please check your inbox.'];
    }
}
