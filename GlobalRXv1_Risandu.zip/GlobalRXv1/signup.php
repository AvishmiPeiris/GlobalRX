<?php
// ================================================================
//  signup.php  —  GlobalRX Sign Up Controller
//
//  Flow:
//   1. Validates all POST fields
//   2. Calls UserManager->signUp()  which does TWO things:
//      a) Creates a Firebase Auth user  (identitytoolkit API)
//      b) Saves profile in Firestore    (users/{uid})
//   3. Returns JSON  →  signup.html JS handles the redirect
// ================================================================

// ── Output buffering: catches any stray whitespace from included
//    files so JSON headers are never broken ──────────────────────
ob_start();

// ── Show ALL errors during development ─────────────────────────
ini_set('display_errors', 0);       // keep errors out of JSON body
error_reporting(E_ALL);
ini_set('log_errors', 1);           // log them to PHP error log instead

header('Content-Type: application/json');

// ── Only accept POST ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_end_clean();
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

// ── Load UserManager (which loads config.php) ───────────────────
require_once __DIR__ . '/UserManager.php';

// ── Collect & trim every field ──────────────────────────────────
$firstName = trim($_POST['first_name'] ?? '');
$lastName  = trim($_POST['last_name']  ?? '');
$dob       = trim($_POST['dob']        ?? '');
$telephone = trim($_POST['telephone']  ?? '');
$country   = trim($_POST['country']    ?? '');
$email     = trim($_POST['email']      ?? '');
$password  = $_POST['password']        ?? '';   // ← do NOT trim passwords

// ── Server-side validation (mirrors the JS checks) ──────────────
if (!$firstName || !$lastName) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'First and last name are required.']);
    exit;
}

if (!$dob) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Date of birth is required.']);
    exit;
}

// Age check — must be 18+
$birthDate = new DateTime($dob);
$today     = new DateTime();
$age       = (int) $today->diff($birthDate)->y;
if ($age < 18) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'You must be at least 18 years old to register.']);
    exit;
}

if (!$telephone) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Telephone number is required.']);
    exit;
}

if (!$country) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please select your country.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit;
}

if (strlen($password) < 8) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters.']);
    exit;
}

if (!preg_match('/[A-Z]/', $password)) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must contain at least one uppercase letter.']);
    exit;
}

if (!preg_match('/[0-9]/', $password)) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must contain at least one number.']);
    exit;
}

// ── Call UserManager ─────────────────────────────────────────────
$manager = new UserManager();
$result  = $manager->signUp($firstName, $lastName, $dob, $telephone, $country, $email, $password);

// ── Map Firebase Auth error codes to friendly messages ──────────
if (!$result['success']) {
    $raw = $result['message'] ?? '';

    $friendly = match(true) {
        str_contains($raw, 'EMAIL_EXISTS')          => 'An account with this email already exists. Try signing in instead.',
        str_contains($raw, 'INVALID_EMAIL')         => 'The email address is not valid.',
        str_contains($raw, 'WEAK_PASSWORD')         => 'Password is too weak. Use at least 8 characters with uppercase and numbers.',
        str_contains($raw, 'TOO_MANY_ATTEMPTS')     => 'Too many attempts. Please wait a moment and try again.',
        str_contains($raw, 'OPERATION_NOT_ALLOWED') => 'Email/password sign-up is not enabled. Contact the administrator.',
        str_contains($raw, 'cURL error')            => 'Could not connect to the authentication service. Check your internet connection.',
        default                                     => $raw ?: 'Sign-up failed. Please try again.',
    };

    ob_end_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $friendly]);
    exit;
}

// ── Success ──────────────────────────────────────────────────────
ob_end_clean();
http_response_code(201);
echo json_encode([
    'success' => true,
    'message' => 'Account created successfully! Redirecting…'
]);
exit;
