/* ══════════════════════════════════════════════════════
   right.js  —  University Admin Dashboard
   ══════════════════════════════════════════════════════ */

const C   = ['#1e3a2f','#4a7fb5','#c9a84c','#3a9b8c','#e05c5c','#8a5fc9','#d4842a'];
const ini = n => n.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
const col = n => C[n.charCodeAt(0) % C.length];

/* ════════════ SAFE RENDER ════════════
   Prevents crashes when a tbody doesn't exist on the
   current page (e.g. courses-tbody while on Dashboard).
   This was the ROOT CAUSE of all buttons being broken:
   the old code called renderCourses() on page load which
   tried to set innerHTML on null → threw a TypeError →
   silently killed ALL subsequent JavaScript on the page.
   ══════════════════════════════════════════════════════ */
function safeRender(id, html) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = html;
}

/* ════════════ DATA ════════════ */

const coursesData = [
  {id:'CRS001',name:'Introduction to Programming',dept:'Computing',level:'Undergraduate',duration:'1 Semester',credits:15,instructor:'Dr. Priya Nair',students:342,status:'Active'},
  {id:'CRS002',name:'Machine Learning Fundamentals',dept:'Computing',level:'Postgraduate',duration:'1 Semester',credits:20,instructor:'Prof. James Otieno',students:89,status:'Active'},
  {id:'CRS003',name:'Financial Accounting',dept:'Business',level:'Undergraduate',duration:'1 Semester',credits:15,instructor:'Dr. Sophia Chen',students:278,status:'Active'},
  {id:'CRS004',name:'Human Anatomy I',dept:'Medical',level:'Undergraduate',duration:'2 Semesters',credits:30,instructor:'Prof. Ravi Kumar',students:120,status:'Active'},
  {id:'CRS005',name:'Contract Law',dept:'Legal',level:'Undergraduate',duration:'1 Semester',credits:15,instructor:'Dr. Amara Diallo',students:95,status:'Inactive'},
  {id:'CRS006',name:'Data Visualisation',dept:'Computing',level:'Postgraduate',duration:'1 Semester',credits:15,instructor:'Dr. Tom Walsh',students:64,status:'Active'},
  {id:'CRS007',name:'Web Development Bootcamp',dept:'Computing',level:'Certificate',duration:'6 Weeks',credits:10,instructor:'Ms. Nina Patel',students:180,status:'Active'},
  {id:'CRS008',name:'Structural Engineering',dept:'Engineering',level:'Undergraduate',duration:'1 Semester',credits:20,instructor:'Prof. Carlos Ruiz',students:72,status:'Active'},
];

const degreesData = [
  {id:'DEG001',name:'BSc Computer Science',level:"Bachelor's",dept:'Computing',duration:'4 Years',credits:480,courses:32,head:'Prof. James Otieno',students:342,status:'Active'},
  {id:'DEG002',name:'MSc Artificial Intelligence',level:"Master's",dept:'Computing',duration:'2 Years',credits:240,courses:16,head:'Prof. James Otieno',students:89,status:'Active'},
  {id:'DEG003',name:'BBA Business Administration',level:"Bachelor's",dept:'Business',duration:'3 Years',credits:360,courses:28,head:'Dr. Sophia Chen',students:278,status:'Active'},
  {id:'DEG004',name:'MBA Strategic Management',level:"Master's",dept:'Business',duration:'2 Years',credits:240,courses:18,head:'Dr. Sophia Chen',students:134,status:'Active'},
  {id:'DEG005',name:'MBBS Medicine',level:"Bachelor's",dept:'Medical',duration:'6 Years',credits:720,courses:48,head:'Prof. Ravi Kumar',students:120,status:'Active'},
  {id:'DEG006',name:'LLB Law',level:"Bachelor's",dept:'Legal',duration:'5 Years',credits:600,courses:40,head:'Dr. Amara Diallo',students:95,status:'Inactive'},
  {id:'DEG007',name:'PhD Engineering',level:'PhD',dept:'Engineering',duration:'3–5 Years',credits:0,courses:6,head:'Prof. Carlos Ruiz',students:32,status:'Active'},
  {id:'DEG008',name:'BSc Data Science',level:"Bachelor's",dept:'Computing',duration:'3 Years',credits:360,courses:26,head:'Dr. Tom Walsh',students:185,status:'Draft'},
];

const diplomasData = [
  {id:'DIP001',name:'Diploma in Data Analytics',category:'Technical',dept:'Computing',duration:'6 Months',delivery:'Online',fee:'$2,400',coordinator:'Dr. Tom Walsh',students:94,status:'Active'},
  {id:'DIP002',name:'Diploma in Digital Marketing',category:'Business',dept:'Business',duration:'4 Months',delivery:'Online',fee:'$1,800',coordinator:'Ms. Aisha Kamara',students:67,status:'Active'},
  {id:'DIP003',name:'Diploma in Project Management',category:'Professional',dept:'Business',duration:'3 Months',delivery:'In-Person',fee:'$1,500',coordinator:'Dr. Sophia Chen',students:55,status:'Active'},
  {id:'DIP004',name:'Diploma in Cyber Security',category:'Technical',dept:'Computing',duration:'8 Months',delivery:'Hybrid',fee:'$3,200',coordinator:'Dr. Priya Nair',students:41,status:'Active'},
  {id:'DIP005',name:'Diploma in Healthcare Admin',category:'Professional',dept:'Medical',duration:'6 Months',delivery:'In-Person',fee:'$2,100',coordinator:'Prof. Ravi Kumar',students:38,status:'Active'},
  {id:'DIP006',name:'Diploma in Graphic Design',category:'Technical',dept:'Arts',duration:'5 Months',delivery:'Online',fee:'$1,600',coordinator:'Ms. Nina Patel',students:73,status:'Active'},
  {id:'DIP007',name:'Diploma in Legal Practice',category:'Professional',dept:'Legal',duration:'12 Months',delivery:'In-Person',fee:'$4,500',coordinator:'Dr. Amara Diallo',students:29,status:'Inactive'},
  {id:'DIP008',name:'Diploma in Cloud Computing',category:'Technical',dept:'Computing',duration:'6 Months',delivery:'Online',fee:'$2,800',coordinator:'Prof. James Otieno',students:81,status:'Draft'},
];

const scholarshipsData = [
  {id:'S001',name:"Dean's Excellence Award",type:'Merit-Based',amount:'$8,000',gpa:'3.8',recipients:15,deadline:'2025-03-31',status:'Active'},
  {id:'S002',name:'Financial Aid Grant',type:'Need-Based',amount:'$5,500',gpa:'2.5',recipients:40,deadline:'2025-04-15',status:'Active'},
  {id:'S003',name:'Sports Achievement Award',type:'Athletic',amount:'$3,000',gpa:'2.0',recipients:12,deadline:'2025-02-28',status:'Closed'},
  {id:'S004',name:'International Student Bursary',type:'Need-Based',amount:'$6,200',gpa:'3.0',recipients:25,deadline:'2025-05-01',status:'Active'},
  {id:'S005',name:'STEM Excellence Scholarship',type:'Merit-Based',amount:'$10,000',gpa:'3.9',recipients:8,deadline:'2025-03-15',status:'Active'},
  {id:'S006',name:'Community Leadership Award',type:'Merit-Based',amount:'$4,500',gpa:'3.2',recipients:10,deadline:'2025-06-01',status:'Draft'},
  {id:'S007',name:'Research Innovation Grant',type:'Merit-Based',amount:'$12,000',gpa:'3.7',recipients:5,deadline:'2025-04-30',status:'Active'},
  {id:'S008',name:'First-Generation Student Fund',type:'Need-Based',amount:'$7,000',gpa:'2.8',recipients:20,deadline:'2025-05-15',status:'Active'},
];

const feedbackData = [
  {id:'F001',name:'Maria Santos',category:'Course Quality',subject:'Excellent teaching in AI module',rating:5,date:'2025-01-20',priority:'Low',status:'Resolved'},
  {id:'F002',name:'Anonymous',category:'Facilities',subject:'Library hours too restricted',rating:2,date:'2025-01-22',priority:'High',status:'Open'},
  {id:'F003',name:'James Okonkwo',category:'Administration',subject:'Registration process confusing',rating:3,date:'2025-01-23',priority:'Medium',status:'Open'},
  {id:'F004',name:'Priya Sharma',category:'Course Quality',subject:'Need more practical sessions',rating:4,date:'2025-01-24',priority:'Low',status:'Resolved'},
  {id:'F005',name:'Anonymous',category:'Support Services',subject:'Counseling wait times too long',rating:1,date:'2025-01-25',priority:'Urgent',status:'Open'},
  {id:'F006',name:'Tom Eriksen',category:'Technology',subject:'Online portal crashes frequently',rating:2,date:'2025-01-26',priority:'High',status:'Open'},
  {id:'F007',name:'Aisha Kamara',category:'Course Quality',subject:'Professor is incredibly helpful',rating:5,date:'2025-01-27',priority:'Low',status:'Resolved'},
  {id:'F008',name:'Carlos Vega',category:'Facilities',subject:'Parking facilities inadequate',rating:3,date:'2025-01-28',priority:'Medium',status:'Resolved'},
];

const visaData = [
  {id:'V001',name:'Chen Wei',nat:'Chinese',type:'Student Visa',dest:'United Kingdom',applied:'2025-01-10',expiry:'2026-09-30',status:'Approved'},
  {id:'V002',name:'Fatima Al-Hassan',nat:'Saudi',type:'Student Visa',dest:'United States',applied:'2025-01-12',expiry:'—',status:'Under Review'},
  {id:'V003',name:'Emmanuel Osei',nat:'Ghanaian',type:'Student Visa',dest:'Canada',applied:'2025-01-14',expiry:'—',status:'Rejected'},
  {id:'V004',name:'Yuki Tanaka',nat:'Japanese',type:'Exchange Program',dest:'Germany',applied:'2025-01-15',expiry:'2025-07-31',status:'Approved'},
  {id:'V005',name:'Anastasia Volkova',nat:'Russian',type:'Student Visa',dest:'Australia',applied:'2025-01-16',expiry:'—',status:'Pending Docs'},
  {id:'V006',name:'Raj Mehta',nat:'Indian',type:'Work Permit',dest:'United Kingdom',applied:'2025-01-17',expiry:'2026-01-17',status:'Approved'},
  {id:'V007',name:'Sofia Andrade',nat:'Brazilian',type:'Student Visa',dest:'France',applied:'2025-01-18',expiry:'—',status:'Under Review'},
  {id:'V008',name:'Ahmed Ibrahim',nat:'Egyptian',type:'Student Visa',dest:'United States',applied:'2025-01-19',expiry:'2026-05-30',status:'Approved'},
];

const employeesData = [
  {id:'EMP001',name:'Dr. Priya Nair',dept:'Computing',role:'Associate Professor',joined:'2019-08-01',salary:'$78,000',status:'Active'},
  {id:'EMP002',name:'Prof. James Otieno',dept:'Computing',role:'Professor',joined:'2015-06-15',salary:'$95,000',status:'Active'},
  {id:'EMP003',name:'Dr. Sophia Chen',dept:'Business',role:'Senior Lecturer',joined:'2020-09-01',salary:'$72,000',status:'Active'},
  {id:'EMP004',name:'Prof. Ravi Kumar',dept:'Medical',role:'Professor & HOD',joined:'2012-01-10',salary:'$110,000',status:'Active'},
  {id:'EMP005',name:'Dr. Amara Diallo',dept:'Legal',role:'Lecturer',joined:'2022-03-20',salary:'$65,000',status:'Active'},
  {id:'EMP006',name:'Ms. Nina Patel',dept:'Computing',role:'Lab Instructor',joined:'2023-07-01',salary:'$52,000',status:'Active'},
  {id:'EMP007',name:'Mr. David Kim',dept:'Administration',role:'Registrar',joined:'2018-04-15',salary:'$60,000',status:'On Leave'},
  {id:'EMP008',name:'Dr. Tom Walsh',dept:'Computing',role:'Lecturer',joined:'2021-09-01',salary:'$68,000',status:'Active'},
];

/* ════════════ BADGE HELPERS ════════════ */
function sb(s) {
  const m = {
    'Active':'badge-green','Approved':'badge-green','Resolved':'badge-green','Graduated':'badge-teal',
    'Inactive':'badge-gray','Closed':'badge-gray','Withdrawn':'badge-gray',
    'On Leave':'badge-gold','Draft':'badge-blue','Under Review':'badge-blue',
    'Open':'badge-gold','Pending Docs':'badge-gold',
    'Rejected':'badge-red','Urgent':'badge-red','Hybrid':'badge-purple'
  };
  return `<span class="badge ${m[s]||'badge-gray'}">${s}</span>`;
}
function pb(p) {
  const m = {Low:'badge-green',Medium:'badge-gold',High:'badge-red',Urgent:'badge-red'};
  return `<span class="badge ${m[p]||'badge-gray'}">${p}</span>`;
}
function delivBadge(d) {
  const m = {Online:'badge-teal','In-Person':'badge-blue',Hybrid:'badge-purple'};
  return `<span class="badge ${m[d]||'badge-gray'}">${d}</span>`;
}
function levelBadge(l) {
  const m = {
    "Bachelor's":'badge-green',"Master's":'badge-blue','PhD':'badge-purple',
    'Undergraduate':'badge-green','Postgraduate':'badge-blue','Certificate':'badge-gold'
  };
  return `<span class="badge ${m[l]||'badge-gray'}">${l}</span>`;
}
function stars(n) {
  return '<span style="color:var(--gold);letter-spacing:1px">'
    + '★'.repeat(n) + '<span style="opacity:.3">' + '★'.repeat(5-n) + '</span></span>';
}

/* ════════════ RENDERERS ════════════ */
function renderCourses() {
  safeRender('courses-tbody', coursesData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">${ini(r.name)}</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td>${r.dept}</td><td>${levelBadge(r.level)}</td><td>${r.duration}</td>
    <td><span style="font-family:'DM Mono',monospace;font-size:11px">${r.credits}</span></td>
    <td>${r.instructor}</td><td><strong>${r.students}</strong></td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="viewRecord('course','${r.id}')">👁 View</button>
      <button class="btn btn-outline btn-sm" onclick="openEdit('course','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name}')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

/* ════════════════════════════════════════════════════════════
   renderDegrees — SMART: defers to PHP/Firestore data if it
   already exists in the DOM (identified by tr[data-search]).
   Only renders the static fallback degreesData when the tbody
   is empty (i.e. Firestore returned 0 results).
   ════════════════════════════════════════════════════════════ */
function renderDegrees() {
  const tbody = document.getElementById('degrees-tbody');
  if (!tbody) return;

  // PHP already rendered live Firestore rows — each has data-search attribute.
  // If any exist, do NOT overwrite them with static data.
  if (tbody.querySelector('tr[data-search]')) return;

  // tbody is empty (Firestore returned nothing) — render static fallback
  tbody.innerHTML = degreesData.map(r => `<tr data-search="${r.name.toLowerCase()} ${r.dept.toLowerCase()} ${r.level.toLowerCase()}">
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">🎓</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td>${levelBadge(r.level)}</td><td>${r.dept}</td><td>${r.duration}</td>
    <td><span style="font-family:'DM Mono',monospace;font-size:11px">${r.credits||'N/A'}</span></td>
    <td><span class="badge badge-teal">${r.courses} modules</span></td>
    <td><div style="font-size:11.5px">${r.head}</div></td>
    <td><strong>${r.students}</strong></td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="viewRecord('degree','${r.id}')">👁 View</button>
      <button class="btn btn-outline btn-sm" onclick="openEdit('degree','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name}')">🗑</button>
    </div></td>
  </tr>`).join('');

  // Update the count footer to reflect fallback data
  const countEl = document.getElementById('degrees-count');
  if (countEl) countEl.textContent = `Showing ${degreesData.length} records (static)`;
}

function renderDiplomas() {
  safeRender('diplomas-tbody', diplomasData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">📜</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td><span class="badge badge-blue">${r.category}</span></td>
    <td>${r.dept}</td><td>${r.duration}</td><td>${delivBadge(r.delivery)}</td>
    <td><strong>${r.fee}</strong></td>
    <td><div style="font-size:11.5px">${r.coordinator}</div></td>
    <td><strong>${r.students}</strong></td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="viewRecord('diploma','${r.id}')">👁 View</button>
      <button class="btn btn-outline btn-sm" onclick="openEdit('diploma','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name}')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

function renderScholarships() {
  safeRender('scholarships-tbody', scholarshipsData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff;font-size:14px">🏅</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td><span class="badge badge-blue">${r.type}</span></td>
    <td><strong>${r.amount}</strong></td><td>${r.gpa}+</td>
    <td>${r.recipients}</td><td>${r.deadline}</td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="openEdit('scholarship','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name}')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

function renderFeedback() {
  safeRender('feedback-tbody', feedbackData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">${r.name==='Anonymous'?'?':ini(r.name)}</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td>${r.category}</td>
    <td style="max-width:140px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${r.subject}</td>
    <td>${stars(r.rating)}</td><td>${r.date}</td>
    <td>${pb(r.priority)}</td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="openEdit('feedback','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('Feedback #${r.id}')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

function renderVisa() {
  safeRender('visa-tbody', visaData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">${ini(r.name)}</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.id}</div></div>
    </div></td>
    <td>${r.nat}</td><td><span class="badge badge-blue">${r.type}</span></td>
    <td>${r.dest}</td><td>${r.applied}</td><td>${r.expiry}</td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="openEdit('visa','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name} visa')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

function renderEmployees() {
  safeRender('employees-tbody', employeesData.map(r => `<tr>
    <td><div class="cell-with-avatar">
      <div class="avatar-sm" style="background:${col(r.name)};color:#fff">${ini(r.name)}</div>
      <div><div style="font-weight:600">${r.name}</div><div class="cell-sub">${r.dept}</div></div>
    </div></td>
    <td><span style="font-family:'DM Mono',monospace;font-size:10.5px">${r.id}</span></td>
    <td>${r.dept}</td><td>${r.role}</td><td>${r.joined}</td>
    <td><strong>${r.salary}</strong></td><td>${sb(r.status)}</td>
    <td><div class="action-group">
      <button class="btn btn-outline btn-sm" onclick="openEdit('employee','${r.id}')">✏️ Edit</button>
      <button class="btn btn-danger btn-sm"  onclick="confirmDelete('${r.name}')">🗑</button>
    </div></td>
  </tr>`).join(''));
}

/* ════════════ VIEW RECORD (detail modal) ════════════ */
function viewRecord(type, id) {
  let record, fields, title;
  if (type === 'course') {
    record = coursesData.find(r=>r.id===id);
    title  = `📚 ${record.name}`;
    fields = [
      {l:'Course ID',v:record.id},{l:'Department',v:record.dept},
      {l:'Level',v:record.level},{l:'Duration',v:record.duration},
      {l:'Credit Hours',v:record.credits},{l:'Lead Instructor',v:record.instructor},
      {l:'Students Enrolled',v:record.students},{l:'Status',v:record.status},
    ];
  } else if (type === 'degree') {
    record = degreesData.find(r=>r.id===id);
    title  = `🎓 ${record.name}`;
    fields = [
      {l:'Degree ID',v:record.id},{l:'Level',v:record.level},
      {l:'Department',v:record.dept},{l:'Duration',v:record.duration},
      {l:'Total Credits',v:record.credits||'N/A'},{l:'Number of Modules',v:record.courses},
      {l:'Head of Program',v:record.head},{l:'Students Enrolled',v:record.students},
      {l:'Status',v:record.status},
    ];
  } else if (type === 'diploma') {
    record = diplomasData.find(r=>r.id===id);
    title  = `📜 ${record.name}`;
    fields = [
      {l:'Diploma ID',v:record.id},{l:'Category',v:record.category},
      {l:'Department',v:record.dept},{l:'Duration',v:record.duration},
      {l:'Delivery Mode',v:record.delivery},{l:'Programme Fee',v:record.fee},
      {l:'Coordinator',v:record.coordinator},{l:'Students Enrolled',v:record.students},
      {l:'Status',v:record.status},
    ];
  }
  if (!record) return;
  const grid = fields.filter(f=>f.l).map(f=>`
    <div class="detail-item">
      <div class="detail-label">${f.l}</div>
      <div class="detail-val">${f.v}</div>
    </div>`).join('');
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = `
    <div class="detail-grid">${grid}</div>
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal()">Close</button>
      <button class="btn btn-primary" onclick="openEdit('${type}','${id}');closeModal()">✏️ Edit Record</button>
    </div>`;
  document.getElementById('modal-overlay').classList.add('open');
}

/* ════════════ NAVIGATION ════════════
   IMPORTANT: 'enrollment' is NOT in renderers.
   The Firebase script in admin_dashboard.html wraps
   this navigate() and calls startEnrollmentListener()
   when id === 'enrollment'. Do not add it back here.
   ════════════════════════════════════════════════════ */
const pages = {
  dashboard:    {t:'Dashboard Overview',     b:'Admin → Dashboard'},
  academics:    {t:'Academic Programs',       b:'Admin → Academics → Programs'},
  scholarships: {t:'Scholarship Management',  b:'Admin → Finance → Scholarships'},
  feedback:     {t:'Feedback Management',     b:'Admin → Quality → Feedback'},
  visa:         {t:'Visa Management',         b:'Admin → International → Visa'},
  enrollment:   {t:'Enrollment Management',   b:'Admin → Students → Enrollment'},
  employees:    {t:'Employee Management',     b:'Admin → HR → Employees'},
};

/* enrollment intentionally omitted — Firebase handles it */
const renderers = {
  academics:    () => { renderCourses(); renderDegrees(); renderDiplomas(); },
  scholarships: renderScholarships,
  feedback:     renderFeedback,
  visa:         renderVisa,
  employees:    renderEmployees,
};

function navigate(id, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const page = document.getElementById('page-'+id);
  if (!page) return;
  page.classList.add('active');
  el.classList.add('active');

  const meta = pages[id];
  if (meta) {
    document.getElementById('pageTitle').textContent  = meta.t;
    document.getElementById('breadcrumb').textContent = meta.b;
  }
  const scroll = document.querySelector('.page-scroll');
  if (scroll) scroll.scrollTop = 0;

  if (renderers[id]) renderers[id]();
}

function switchTab(tab, el) {
  el.closest('.sub-tabs').querySelectorAll('.sub-tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  document.querySelectorAll('.sub-panel').forEach(p=>p.classList.remove('active'));
  const panel = document.getElementById('subtab-'+tab);
  if (panel) panel.classList.add('active');
}

function chipActive(el) {
  el.closest('.table-toolbar').querySelectorAll('.filter-chip')
    .forEach(c=>c.classList.remove('active'));
  el.classList.add('active');
}

/* ════════════ MODAL FORMS ════════════ */
const forms = {
  'course-add': {t:'Add New Course', f:`<div class="form-grid">
    <div class="form-group full"><label>Course / Module Name</label><input placeholder="e.g. Introduction to Programming"></div>
    <div class="form-group"><label>Department</label><select><option>Computing</option><option>Business</option><option>Medical</option><option>Engineering</option><option>Legal</option><option>Arts</option></select></div>
    <div class="form-group"><label>Level</label><select><option>Undergraduate</option><option>Postgraduate</option><option>Certificate</option></select></div>
    <div class="form-group"><label>Duration</label><input placeholder="e.g. 1 Semester"></div>
    <div class="form-group"><label>Credit Hours</label><input type="number" placeholder="15"></div>
    <div class="form-group full"><label>Lead Instructor</label><input placeholder="Dr. Firstname Lastname"></div>
    <div class="form-group"><label>Max Capacity</label><input type="number" placeholder="300"></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>Inactive</option><option>Draft</option></select></div>
    <div class="form-group full"><label>Course Description</label><textarea placeholder="Brief course overview…"></textarea></div>
    <div class="form-group full"><label>Prerequisites</label><input placeholder="e.g. CRS001, CRS002 or None"></div>
  </div>`},
  'degree-add': {t:'Add New Degree Program', f:`<div class="form-grid">
    <div class="form-group full"><label>Degree Program Name</label><input placeholder="e.g. BSc Computer Science"></div>
    <div class="form-group"><label>Degree Level</label><select><option>Bachelor's</option><option>Master's</option><option>PhD</option><option>Associate</option></select></div>
    <div class="form-group"><label>Department</label><select><option>Computing</option><option>Business</option><option>Medical</option><option>Engineering</option><option>Legal</option><option>Arts</option></select></div>
    <div class="form-group"><label>Duration</label><input placeholder="e.g. 4 Years"></div>
    <div class="form-group"><label>Total Credits Required</label><input type="number" placeholder="480"></div>
    <div class="form-group"><label>Head of Program</label><input placeholder="Prof. Firstname Lastname"></div>
    <div class="form-group"><label>Accreditation Body</label><input placeholder="e.g. QAA, ABET"></div>
    <div class="form-group"><label>Max Annual Intake</label><input type="number" placeholder="100"></div>
    <div class="form-group"><label>Tuition Fee / Year</label><input placeholder="e.g. $12,000"></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>Draft</option><option>Inactive</option></select></div>
    <div class="form-group full"><label>Program Description & Learning Outcomes</label><textarea placeholder="Describe the degree program…"></textarea></div>
    <div class="form-group full"><label>Entry Requirements</label><textarea placeholder="Minimum grades, qualifications…"></textarea></div>
  </div>`},
  'diploma-add': {t:'Add New Diploma Program', f:`<div class="form-grid">
    <div class="form-group full"><label>Diploma Program Name</label><input placeholder="e.g. Diploma in Data Analytics"></div>
    <div class="form-group"><label>Category</label><select><option>Technical</option><option>Professional</option><option>Business</option><option>Creative</option><option>Healthcare</option></select></div>
    <div class="form-group"><label>Department</label><select><option>Computing</option><option>Business</option><option>Medical</option><option>Engineering</option><option>Legal</option><option>Arts</option></select></div>
    <div class="form-group"><label>Duration</label><input placeholder="e.g. 6 Months"></div>
    <div class="form-group"><label>Delivery Mode</label><select><option>Online</option><option>In-Person</option><option>Hybrid</option></select></div>
    <div class="form-group"><label>Programme Fee</label><input placeholder="e.g. $2,400"></div>
    <div class="form-group"><label>Program Coordinator</label><input placeholder="Dr. Firstname Lastname"></div>
    <div class="form-group"><label>Max Intake</label><input type="number" placeholder="60"></div>
    <div class="form-group"><label>Start Date</label><input type="date"></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>Draft</option><option>Inactive</option></select></div>
    <div class="form-group full"><label>Program Overview & Objectives</label><textarea placeholder="Describe the diploma program…"></textarea></div>
    <div class="form-group full"><label>Modules / Topics Covered</label><textarea placeholder="List the main modules…"></textarea></div>
  </div>`},
  'scholarship-add': {t:'Add New Scholarship', f:`<div class="form-grid">
    <div class="form-group full"><label>Scholarship Name</label><input placeholder="e.g. Dean's Excellence Award"></div>
    <div class="form-group"><label>Type</label><select><option>Merit-Based</option><option>Need-Based</option><option>Athletic</option><option>Research</option></select></div>
    <div class="form-group"><label>Amount (USD)</label><input type="number" placeholder="5000"></div>
    <div class="form-group"><label>Min GPA Required</label><input type="number" step="0.1" placeholder="3.5"></div>
    <div class="form-group"><label>Max Recipients</label><input type="number" placeholder="20"></div>
    <div class="form-group"><label>Application Deadline</label><input type="date"></div>
    <div class="form-group"><label>Eligible Programs</label><select><option>All Programs</option><option>Undergraduate Only</option><option>Postgraduate Only</option></select></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>Draft</option><option>Closed</option></select></div>
    <div class="form-group full"><label>Requirements & Description</label><textarea placeholder="Describe eligibility criteria…"></textarea></div>
  </div>`},
  'feedback-add': {t:'Add Feedback Record', f:`<div class="form-grid">
    <div class="form-group"><label>Submitted By</label><input placeholder="Name or Anonymous"></div>
    <div class="form-group"><label>Student/Staff ID</label><input placeholder="STU2025001"></div>
    <div class="form-group"><label>Category</label><select><option>Course Quality</option><option>Facilities</option><option>Administration</option><option>Support Services</option><option>Technology</option></select></div>
    <div class="form-group"><label>Rating</label><select><option>5 — Excellent</option><option>4 — Good</option><option>3 — Average</option><option>2 — Poor</option><option>1 — Very Poor</option></select></div>
    <div class="form-group full"><label>Subject</label><input placeholder="Brief subject line"></div>
    <div class="form-group"><label>Priority</label><select><option>Low</option><option>Medium</option><option>High</option><option>Urgent</option></select></div>
    <div class="form-group"><label>Status</label><select><option>Open</option><option>In Progress</option><option>Resolved</option></select></div>
    <div class="form-group full"><label>Detailed Feedback</label><textarea placeholder="Full feedback message…"></textarea></div>
  </div>`},
  'visa-add': {t:'New Visa Application', f:`<div class="form-grid">
    <div class="form-group"><label>Applicant Full Name</label><input placeholder="Full legal name"></div>
    <div class="form-group"><label>Student/Staff ID</label><input placeholder="STU2025001"></div>
    <div class="form-group"><label>Nationality</label><input placeholder="e.g. Indian"></div>
    <div class="form-group"><label>Passport Number</label><input placeholder="A1234567"></div>
    <div class="form-group"><label>Visa Type</label><select><option>Student Visa</option><option>Work Permit</option><option>Exchange Program</option></select></div>
    <div class="form-group"><label>Destination Country</label><input placeholder="e.g. United Kingdom"></div>
    <div class="form-group"><label>Application Date</label><input type="date"></div>
    <div class="form-group"><label>Intended Expiry</label><input type="date"></div>
    <div class="form-group"><label>Status</label><select><option>Pending Docs</option><option>Under Review</option><option>Approved</option><option>Rejected</option></select></div>
    <div class="form-group"><label>Embassy Reference</label><input placeholder="EMB-2025-0001"></div>
  </div>`},
  'enrollment-add': {t:'Enroll New Student', f:`<div class="form-grid">
    <div class="form-group"><label>Full Name</label><input placeholder="Student full name"></div>
    <div class="form-group"><label>Date of Birth</label><input type="date"></div>
    <div class="form-group"><label>Email Address</label><input type="email" placeholder="student@university.edu"></div>
    <div class="form-group"><label>Phone Number</label><input placeholder="+1 555 000 0000"></div>
    <div class="form-group"><label>Program</label><select><option>BSc Computer Science</option><option>MBBS Medicine</option><option>MSc AI</option><option>LLB Law</option><option>BBA Business</option></select></div>
    <div class="form-group"><label>Entry Year</label><select><option>Year 1</option><option>Year 2</option><option>Year 3</option><option>Year 4</option></select></div>
    <div class="form-group"><label>Entry Date</label><input type="date"></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>On Leave</option><option>Deferred</option></select></div>
    <div class="form-group full"><label>Previous Institution</label><input placeholder="Previous school/university"></div>
  </div>`},
  'employee-add': {t:'Add New Employee', f:`<div class="form-grid">
    <div class="form-group"><label>Full Name</label><input placeholder="Dr./Mr./Ms. Full Name"></div>
    <div class="form-group"><label>Email</label><input type="email" placeholder="staff@university.edu"></div>
    <div class="form-group"><label>Department</label><select><option>Computing</option><option>Business</option><option>Medical</option><option>Engineering</option><option>Legal</option><option>Administration</option></select></div>
    <div class="form-group"><label>Role / Position</label><input placeholder="e.g. Associate Professor"></div>
    <div class="form-group"><label>Employment Type</label><select><option>Full-Time</option><option>Part-Time</option><option>Contract</option><option>Visiting</option></select></div>
    <div class="form-group"><label>Annual Salary (USD)</label><input type="number" placeholder="70000"></div>
    <div class="form-group"><label>Join Date</label><input type="date"></div>
    <div class="form-group"><label>Status</label><select><option>Active</option><option>On Leave</option><option>Probation</option></select></div>
    <div class="form-group full"><label>Qualifications</label><textarea placeholder="Degrees, certifications…"></textarea></div>
  </div>`},
};

function openModal(key) {
  const f = forms[key]; if (!f) return;
  document.getElementById('modal-title').textContent = f.t;
  document.getElementById('modal-body').innerHTML = f.f + `
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="saveRecord()">Save Record</button>
    </div>`;
  document.getElementById('modal-overlay').classList.add('open');
}

function openEdit(type, id) {
  const km = {
    course:'course-add', degree:'degree-add', diploma:'diploma-add',
    scholarship:'scholarship-add', feedback:'feedback-add', visa:'visa-add',
    enrollment:'enrollment-add', employee:'employee-add'
  };
  const f = forms[km[type]]; if (!f) return;
  document.getElementById('modal-title').textContent =
    'Edit ' + type.charAt(0).toUpperCase() + type.slice(1) + ' #' + id;
  document.getElementById('modal-body').innerHTML = f.f + `
    <div class="modal-footer">
      <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
      <button class="btn btn-gold" onclick="saveRecord()">Update Record</button>
    </div>`;
  document.getElementById('modal-overlay').classList.add('open');
}

function closeModal()        { document.getElementById('modal-overlay').classList.remove('open'); }
function closeModalOutside(e){ if(e.target===document.getElementById('modal-overlay')) closeModal(); }

function confirmDelete(name) {
  document.getElementById('confirm-msg').textContent =
    `Permanently delete "${name}"? This action cannot be undone.`;
  document.getElementById('confirm-overlay').classList.add('open');
  document.getElementById('confirm-yes-btn').onclick = () => {
    closeConfirm(); showToast(`"${name}" has been deleted.`, 'red');
  };
}
function closeConfirm()        { document.getElementById('confirm-overlay').classList.remove('open'); }
function closeConfirmOutside(e){ if(e.target===document.getElementById('confirm-overlay')) closeConfirm(); }

function saveRecord() { closeModal(); showToast('Record saved successfully!'); }

function showToast(msg, type='green') {
  const t = document.getElementById('toast');
  t.style.background = type==='red' ? 'var(--red)' : 'var(--green-dark)';
  document.getElementById('toast-msg').textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}

/* ════════════ INIT ════════════════════════════════════
   DO NOT call renderCourses() here at the top level.
   courses-tbody does not exist on the dashboard page,
   so calling it here throws a TypeError on null and
   kills ALL subsequent JavaScript — breaking every
   button, link and modal in the entire dashboard.

   Renderers are called lazily via navigate() only when
   the relevant page is actually shown and its DOM exists.
   ═════════════════════════════════════════════════════= */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if (document.getElementById('modal-overlay').classList.contains('open'))   closeModal();
    if (document.getElementById('confirm-overlay').classList.contains('open')) closeConfirm();
  }
});
