import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA8wy_aEO2Pc3uMaNPyEEN2UsoGE9nQzeU",
  authDomain: "globalrx-9085e.firebaseapp.com",
  projectId: "globalrx-9085e",
  storageBucket: "globalrx-9085e.appspot.com",
  messagingSenderId: "632389557622",
  appId: "1:632389557622:web:1f5da5ef9ecb13b018ae57"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);


