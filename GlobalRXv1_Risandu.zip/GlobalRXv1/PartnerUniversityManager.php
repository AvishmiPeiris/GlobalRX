<?php
require_once 'config.php';

class PartnerUniversityManager {
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    public function __construct() {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/partnerUniversities";
    }

    /* ─── HTTP Helper ─── */
    private function request(string $method, string $url, ?array $body = null): array {
        $url .= (str_contains($url, '?') ? '&' : '?') . "key={$this->apiKey}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT        => 15,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? 'Unknown Firestore error';
            return ['success' => false, 'message' => "Firestore error ($httpCode): $msg"];
        }
        return ['success' => true, 'data' => $data];
    }

    /* ─── Parse Firestore document ─── */
    private function parseDoc(array $doc): array {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');
        return [
            'id'          => $id,
            'name'        => $fields['name']['stringValue']        ?? '',
            'country'     => $fields['country']['stringValue']      ?? '',
            'flag'        => $fields['flag']['stringValue']         ?? '🌍',
            'ranking'     => $fields['ranking']['stringValue']      ?? '',
            'website'     => $fields['website']['stringValue']      ?? '',
            'contactEmail'=> $fields['contactEmail']['stringValue'] ?? '',
            'programs'    => $fields['programs']['stringValue']     ?? '',
            'status'      => $fields['status']['stringValue']       ?? 'Active',
            'partnerSince'=> $fields['partnerSince']['stringValue'] ?? '',
            'notes'       => $fields['notes']['stringValue']        ?? '',
            'createdAt'   => $fields['createdAt']['stringValue']    ?? '',
        ];
    }

    /* ─── Build Firestore document body ─── */
    private function buildDoc(
        string $name, string $country, string $flag, string $ranking,
        string $website, string $contactEmail, string $programs,
        string $status, string $partnerSince, string $notes, string $createdAt = ''
    ): array {
        $now = date('Y-m-d H:i:s');
        return [
            'fields' => [
                'name'         => ['stringValue' => $name],
                'country'      => ['stringValue' => $country],
                'flag'         => ['stringValue' => $flag],
                'ranking'      => ['stringValue' => $ranking],
                'website'      => ['stringValue' => $website],
                'contactEmail' => ['stringValue' => $contactEmail],
                'programs'     => ['stringValue' => $programs],
                'status'       => ['stringValue' => $status],
                'partnerSince' => ['stringValue' => $partnerSince],
                'notes'        => ['stringValue' => $notes],
                'createdAt'    => ['stringValue' => $createdAt ?: $now],
            ]
        ];
    }

    /* ─── READ ALL ─── */
    public function getAllUniversities(): array {
        $result = $this->request('GET', $this->baseUrl . '?pageSize=200');
        if (!$result['success']) return $result;
        $unis = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $unis[] = $this->parseDoc($doc);
        }
        usort($unis, fn($a, $b) => strcmp($a['country'], $b['country']));
        return ['success' => true, 'universities' => $unis];
    }

    /* ─── CREATE ─── */
    public function addUniversity(
        string $name, string $country, string $flag, string $ranking,
        string $website, string $contactEmail, string $programs,
        string $status = 'Active', string $partnerSince = '', string $notes = ''
    ): array {
        if (empty($name) || empty($country)) {
            return ['success' => false, 'message' => 'University name and country are required.'];
        }
        $docId  = 'UNI-' . strtoupper(substr(md5(uniqid($name, true)), 0, 8));
        $url    = $this->baseUrl . '?documentId=' . urlencode($docId);
        $result = $this->request('POST', $url, $this->buildDoc(
            $name, $country, $flag, $ranking, $website, $contactEmail, $programs, $status, $partnerSince, $notes
        ));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "'{$name}' added as a partner institution."];
    }

    /* ─── UPDATE ─── */
    public function updateUniversity(
        string $id, string $name, string $country, string $flag, string $ranking,
        string $website, string $contactEmail, string $programs,
        string $status, string $partnerSince, string $notes, string $createdAt = ''
    ): array {
        if (empty($id) || empty($name)) {
            return ['success' => false, 'message' => 'ID and university name are required.'];
        }
        $fieldList = 'name,country,flag,ranking,website,contactEmail,programs,status,partnerSince,notes';
        $mask = implode('&', array_map(fn($f) => 'updateMask.fieldPaths=' . $f, explode(',', $fieldList)));
        $url  = "{$this->baseUrl}/{$id}?{$mask}";
        $result = $this->request('PATCH', $url, $this->buildDoc(
            $name, $country, $flag, $ranking, $website, $contactEmail, $programs, $status, $partnerSince, $notes, $createdAt
        ));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "'{$name}' updated successfully."];
    }

    /* ─── DELETE ─── */
    public function deleteUniversity(string $id): array {
        if (empty($id)) {
            return ['success' => false, 'message' => 'University ID is required.'];
        }
        $result = $this->request('DELETE', "{$this->baseUrl}/{$id}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Partner institution removed successfully.'];
    }
}