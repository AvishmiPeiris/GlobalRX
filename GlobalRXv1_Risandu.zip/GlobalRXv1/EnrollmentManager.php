<?php
/**
 * EnrollmentManager.php
 *
 * CRUD for the "enrollments" collection in Firebase Firestore via REST API.
 *
 * SSL FIX (Windows/XAMPP):
 *   Download  https://curl.se/ca/cacert.pem
 *   Save to   C:\xampp\php\extras\ssl\cacert.pem
 *   Add to php.ini:
 *     curl.cainfo  = "C:\xampp\php\extras\ssl\cacert.pem"
 *     openssl.cafile = "C:\xampp\php\extras\ssl\cacert.pem"
 *   Restart Apache.
 */
require_once __DIR__ . '/config.php';

class EnrollmentManager
{
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    private array $certPaths = [
        'C:/xampp/php/extras/ssl/cacert.pem',
        'C:/xampp/apache/conf/ssl.crt/cacert.pem',
        'C:/xampp/php/cacert.pem',
        'C:/curl/cacert.pem',
    ];

    public function __construct()
    {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                         . "/databases/(default)/documents/enrollments";
    }

    /* ── Find CA bundle ── */
    private function getCertPath(): string
    {
        $ini = ini_get('curl.cainfo');
        if ($ini && file_exists($ini)) return $ini;
        foreach ($this->certPaths as $p) { if (file_exists($p)) return $p; }
        $local = __DIR__ . '/cacert.pem';
        return file_exists($local) ? $local : '';
    }

    /* ── Generic HTTP helper ── */
    private function request(string $method, string $url, ?array $body = null): array
    {
        $sep  = str_contains($url, '?') ? '&' : '?';
        $url .= "{$sep}key={$this->apiKey}";

        $certPath = $this->getCertPath();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 20,
        ]);
        if ($certPath !== '') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_CAINFO, $certPath);
        } else {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr)   return ['success' => false, 'message' => "cURL error: $curlErr"];
        if (!$response) return ['success' => false, 'message' => "Empty response (HTTP $httpCode)"];

        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP $httpCode";
            return ['success' => false, 'message' => "Firestore error ($httpCode): $msg"];
        }
        return ['success' => true, 'data' => $data];
    }

    /* ── Extract plain value from Firestore typed-value map ── */
    private function extractValue(array $tv): mixed
    {
        if (isset($tv['stringValue']))              return (string) $tv['stringValue'];
        if (isset($tv['integerValue']))             return (int)    $tv['integerValue'];
        if (isset($tv['doubleValue']))              return (float)  $tv['doubleValue'];
        if (isset($tv['booleanValue']))             return (bool)   $tv['booleanValue'];
        if (array_key_exists('nullValue', $tv))     return null;
        if (isset($tv['timestampValue'])) {
            try {
                $dt = new DateTime($tv['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                return $dt->format('d M Y, H:i');
            } catch (Exception) { return $tv['timestampValue']; }
        }
        return '';
    }

    /* ── Parse a Firestore document into a PHP array ── */
    private function parseDoc(array $doc): array
    {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');

        $sortKey = 0; $createdAt = '';
        if (isset($fields['createdAt']['timestampValue'])) {
            try {
                $dt      = new DateTime($fields['createdAt']['timestampValue']);
                $sortKey = $dt->getTimestamp();
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                $createdAt = $dt->format('d M Y, H:i');
            } catch (Exception) {
                $createdAt = $fields['createdAt']['timestampValue'];
            }
        }

        $age = '';
        if (isset($fields['age'])) {
            $raw = $this->extractValue($fields['age']);
            $age = ($raw !== null && $raw !== '') ? (string)(int)$raw : '';
        }

        return [
            'id'        => $id,
            'fullName'  => isset($fields['fullName'])  ? (string)$this->extractValue($fields['fullName'])  : '',
            'email'     => isset($fields['email'])     ? (string)$this->extractValue($fields['email'])     : '',
            'age'       => $age,
            'location'  => isset($fields['location'])  ? (string)$this->extractValue($fields['location'])  : '',
            'phone'     => isset($fields['phone'])     ? (string)$this->extractValue($fields['phone'])     : '',
            'course'    => isset($fields['course'])    ? (string)$this->extractValue($fields['course'])    : '',
            'status'    => isset($fields['status'])    ? (string)$this->extractValue($fields['status'])    : 'Pending',
            'result'    => isset($fields['result'])    ? (string)$this->extractValue($fields['result'])    : '',
            'createdAt' => $createdAt,
            '_sortKey'  => $sortKey,
        ];
    }

    /* ── Build Firestore PATCH body ── */
    private function buildFields(
        string $fullName, string $email, string $age,
        string $location, string $phone, string $course,
        string $status,   string $result
    ): array {
        return [
            'fields' => [
                'fullName' => ['stringValue'  => $fullName],
                'email'    => ['stringValue'  => $email],
                'age'      => ['integerValue' => (int)$age],
                'location' => ['stringValue'  => $location],
                'phone'    => ['stringValue'  => $phone],
                'course'   => ['stringValue'  => $course],
                'status'   => ['stringValue'  => $status],
                'result'   => ['stringValue'  => $result],
            ]
        ];
    }

    /* ══════════════════════════════════════════════
       PUBLIC API
       ══════════════════════════════════════════════ */

    /** Fetch all enrollments sorted newest-first. */
    public function getAllEnrollments(): array
    {
        $result = $this->request('GET', $this->baseUrl);
        if (!$result['success']) return $result;

        $enrollments = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $parsed = $this->parseDoc($doc);
            if (!empty($parsed['id'])) $enrollments[] = $parsed;
        }
        usort($enrollments, fn($a, $b) => $b['_sortKey'] <=> $a['_sortKey']);
        return ['success' => true, 'enrollments' => $enrollments];
    }

    /**
     * Add a new enrollment manually (admin-created).
     * Firestore auto-generates the document ID via a POST to the collection.
     * Status is set to "Pending" and createdAt to server timestamp.
     */
    public function addEnrollment(
        string $fullName, string $email, string $age,
        string $location, string $phone, string $course
    ): array {
        if (empty(trim($fullName))) return ['success' => false, 'message' => 'Full name is required.'];
        if (empty(trim($email)))    return ['success' => false, 'message' => 'Email is required.'];
        if (empty(trim($course)))   return ['success' => false, 'message' => 'Course is required.'];

        $body = [
            'fields' => [
                'fullName'  => ['stringValue'  => $fullName],
                'email'     => ['stringValue'  => $email],
                'age'       => ['integerValue' => (int)$age],
                'location'  => ['stringValue'  => $location],
                'phone'     => ['stringValue'  => $phone],
                'course'    => ['stringValue'  => $course],
                'status'    => ['stringValue'  => 'Pending'],
                'result'    => ['stringValue'  => ''],
                /* serverTimestamp is set via a write transform.
                   Using a plain timestamp string here as a fallback
                   since the REST API write transform needs a different call.
                   We'll use the current UTC time as a string timestamp. */
                'createdAt' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
            ]
        ];

        /* POST to collection → Firestore auto-generates the document ID */
        $res = $this->request('POST', $this->baseUrl, $body);
        if (!$res['success']) return $res;

        return ['success' => true, 'message' => "Enrollment for '{$fullName}' added successfully."];
    }

    /** Update an existing enrollment (field-mask PATCH). */
    public function updateEnrollment(
        string $id,       string $fullName, string $email,
        string $age,      string $location, string $phone,
        string $course,   string $status,   string $result
    ): array {
        if (empty(trim($id))) return ['success' => false, 'message' => 'Enrollment ID is required.'];

        $fields = ['fullName','email','age','location','phone','course','status','result'];
        $mask   = implode('&', array_map(fn($f) => "updateMask.fieldPaths={$f}", $fields));
        $res    = $this->request('PATCH', "{$this->baseUrl}/{$id}?{$mask}",
                    $this->buildFields($fullName,$email,$age,$location,$phone,$course,$status,$result));
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => "Enrollment for '{$fullName}' updated successfully."];
    }

    /** Permanently delete an enrollment document. */
    public function deleteEnrollment(string $id): array
    {
        if (empty(trim($id))) return ['success' => false, 'message' => 'Enrollment ID is required.'];
        $result = $this->request('DELETE', "{$this->baseUrl}/{$id}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Enrollment deleted successfully.'];
    }
}
