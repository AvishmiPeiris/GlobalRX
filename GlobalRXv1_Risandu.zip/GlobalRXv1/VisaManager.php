<?php
/**
 * VisaManager.php — GlobalRX
 *
 * CRUD for the "Visa" collection in Firebase Firestore via REST API.
 *
 * Document structure:
 *   countryName        (string)
 *   countryCode        (string)   e.g. "uk"
 *   flagEmoji          (string)   e.g. "🇬🇧"
 *   systemType         (string)   e.g. "Points-Based System"
 *   status             (string)   "Active" | "Inactive"
 *   description        (string)
 *   badges             (array of strings)
 *   visaPathway        (array of strings)
 *   groundRealityPoints(array of strings)
 *   visaTypes          (array of maps: { type, icon, details[] })
 *   createdAt          (timestamp)
 *   updatedAt          (timestamp)
 */
require_once __DIR__ . '/config.php';

class VisaManager
{
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    private array $certPaths = [
        'C:/xampp/php/extras/ssl/cacert.pem',
        'C:/xampp/apache/conf/ssl.crt/cacert.pem',
        'C:/xampp/php/cacert.pem',
        'C:/wamp64/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/wamp/bin/php/php8.2.0/extras/ssl/cacert.pem',
        'C:/curl/cacert.pem',
    ];

    public function __construct()
    {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}"
                         . "/databases/(default)/documents/Visa";
    }

    /* ── Find CA bundle ── */
    private function getCertPath(): string
    {
        $ini = ini_get('curl.cainfo');
        if ($ini && file_exists($ini)) return $ini;
        foreach ($this->certPaths as $p) { if (file_exists($p)) return $p; }
        $local = __DIR__ . '/cacert.pem';
        return file_exists($local) ? $local : '';
    }

    /* ── Generic HTTP helper ── */
    private function request(string $method, string $url, ?array $body = null): array
    {
        $sep  = str_contains($url, '?') ? '&' : '?';
        $url .= "{$sep}key={$this->apiKey}";

        $certPath = $this->getCertPath();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        if ($certPath !== '') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_CAINFO, $certPath);
        } else {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr)   return ['success' => false, 'message' => "cURL error: $curlErr"];
        if (!$response) return ['success' => false, 'message' => "Empty response (HTTP $httpCode)"];

        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP $httpCode";
            return ['success' => false, 'message' => "Firestore error ($httpCode): $msg"];
        }
        return ['success' => true, 'data' => $data];
    }

    /* ── Extract plain value from Firestore typed-value map ── */
    private function extractValue(array $tv): mixed
    {
        if (isset($tv['stringValue']))          return (string) $tv['stringValue'];
        if (isset($tv['integerValue']))         return (int)    $tv['integerValue'];
        if (isset($tv['booleanValue']))         return (bool)   $tv['booleanValue'];
        if (array_key_exists('nullValue', $tv)) return null;
        if (isset($tv['timestampValue'])) {
            try {
                $dt = new DateTime($tv['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                return $dt->format('d M Y, H:i');
            } catch (Exception) { return $tv['timestampValue']; }
        }
        /* Array value — return as PHP array of extracted values */
        if (isset($tv['arrayValue']['values'])) {
            return array_map(fn($v) => $this->extractValue($v), $tv['arrayValue']['values']);
        }
        if (isset($tv['arrayValue'])) return [];
        /* Map value */
        if (isset($tv['mapValue']['fields'])) {
            $out = [];
            foreach ($tv['mapValue']['fields'] as $k => $v) {
                $out[$k] = $this->extractValue($v);
            }
            return $out;
        }
        return '';
    }

    /* ── Build Firestore arrayValue from a PHP string array ── */
    private function strArrayField(array $items): array
    {
        return [
            'arrayValue' => [
                'values' => array_map(fn($s) => ['stringValue' => (string)$s], $items)
            ]
        ];
    }

    /* ── Build Firestore arrayValue for visaTypes (array of maps) ── */
    private function visaTypesField(array $types): array
    {
        $values = [];
        foreach ($types as $vt) {
            $detailValues = array_map(
                fn($d) => ['stringValue' => (string)$d],
                $vt['details'] ?? []
            );
            $values[] = [
                'mapValue' => [
                    'fields' => [
                        'type'    => ['stringValue' => $vt['type']    ?? ''],
                        'icon'    => ['stringValue' => $vt['icon']    ?? ''],
                        'details' => ['arrayValue'  => ['values' => $detailValues]],
                    ]
                ]
            ];
        }
        return ['arrayValue' => ['values' => $values]];
    }

    /* ── Parse a Firestore Visa document into a PHP array ── */
    private function parseDoc(array $doc): array
    {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');

        $sortKey = 0;
        $createdAt = '';
        if (isset($fields['createdAt']['timestampValue'])) {
            try {
                $dt = new DateTime($fields['createdAt']['timestampValue']);
                $sortKey = $dt->getTimestamp();
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                $createdAt = $dt->format('d M Y, H:i');
            } catch (Exception) { $createdAt = $fields['createdAt']['timestampValue'] ?? ''; }
        }

        /* Parse visaTypes — array of maps */
        $visaTypes = [];
        if (isset($fields['visaTypes']['arrayValue']['values'])) {
            foreach ($fields['visaTypes']['arrayValue']['values'] as $vtVal) {
                $vtFields = $vtVal['mapValue']['fields'] ?? [];
                $details  = [];
                if (isset($vtFields['details']['arrayValue']['values'])) {
                    foreach ($vtFields['details']['arrayValue']['values'] as $dv) {
                        $details[] = $dv['stringValue'] ?? '';
                    }
                }
                $visaTypes[] = [
                    'type'    => $vtFields['type']['stringValue']  ?? '',
                    'icon'    => $vtFields['icon']['stringValue']  ?? '',
                    'details' => $details,
                ];
            }
        }

        /* Parse simple string arrays */
        $badges = [];
        if (isset($fields['badges']['arrayValue']['values'])) {
            foreach ($fields['badges']['arrayValue']['values'] as $v) {
                $badges[] = $v['stringValue'] ?? '';
            }
        }

        $visaPathway = [];
        if (isset($fields['visaPathway']['arrayValue']['values'])) {
            foreach ($fields['visaPathway']['arrayValue']['values'] as $v) {
                $visaPathway[] = $v['stringValue'] ?? '';
            }
        }

        $groundRealityPoints = [];
        if (isset($fields['groundRealityPoints']['arrayValue']['values'])) {
            foreach ($fields['groundRealityPoints']['arrayValue']['values'] as $v) {
                $groundRealityPoints[] = $v['stringValue'] ?? '';
            }
        }

        return [
            'id'                  => $id,
            'countryName'         => $fields['countryName']['stringValue']  ?? '',
            'countryCode'         => $fields['countryCode']['stringValue']  ?? '',
            'flagEmoji'           => $fields['flagEmoji']['stringValue']    ?? '',
            'systemType'          => $fields['systemType']['stringValue']   ?? '',
            'status'              => $fields['status']['stringValue']       ?? 'Active',
            'description'         => $fields['description']['stringValue']  ?? '',
            'badges'              => $badges,
            'visaPathway'         => $visaPathway,
            'groundRealityPoints' => $groundRealityPoints,
            'visaTypes'           => $visaTypes,
            'createdAt'           => $createdAt,
            '_sortKey'            => $sortKey,
        ];
    }

    /* ── Build Firestore document body ── */
    private function buildBody(
        string $countryName, string $countryCode, string $flagEmoji,
        string $systemType,  string $status,      string $description,
        array  $badges,      array  $visaPathway,  array  $groundRealityPoints,
        array  $visaTypes,   bool   $withTimestamps = false, bool $isNew = false
    ): array {
        $fields = [
            'countryName'         => ['stringValue' => $countryName],
            'countryCode'         => ['stringValue' => strtolower(trim($countryCode))],
            'flagEmoji'           => ['stringValue' => $flagEmoji],
            'systemType'          => ['stringValue' => $systemType],
            'status'              => ['stringValue' => $status],
            'description'         => ['stringValue' => $description],
            'badges'              => $this->strArrayField($badges),
            'visaPathway'         => $this->strArrayField($visaPathway),
            'groundRealityPoints' => $this->strArrayField($groundRealityPoints),
            'visaTypes'           => $this->visaTypesField($visaTypes),
            'updatedAt'           => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
        ];
        if ($isNew) {
            $fields['createdAt'] = ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')];
        }
        return ['fields' => $fields];
    }

    /* ══════════════════════════════════════════════
       PUBLIC API
       ══════════════════════════════════════════════ */

    /** Fetch all visa countries, sorted newest-first. */
    public function getAllVisa(): array
    {
        $result = $this->request('GET', $this->baseUrl);
        if (!$result['success']) return $result;

        $visas = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $parsed = $this->parseDoc($doc);
            if (!empty($parsed['id'])) $visas[] = $parsed;
        }
        usort($visas, fn($a, $b) => $b['_sortKey'] <=> $a['_sortKey']);
        return ['success' => true, 'visas' => $visas];
    }

    /** Get a single visa document by ID. */
    public function getVisa(string $id): array
    {
        if (empty(trim($id))) return ['success' => false, 'message' => 'ID is required.'];
        $result = $this->request('GET', "{$this->baseUrl}/{$id}");
        if (!$result['success']) return $result;
        return ['success' => true, 'visa' => $this->parseDoc($result['data'])];
    }

    /**
     * Add a new visa country.
     * $visaTypes = [ ['type'=>'...', 'icon'=>'...', 'details'=>['line1','line2']], ... ]
     */
    public function addVisa(
        string $countryName, string $countryCode, string $flagEmoji,
        string $systemType,  string $status,      string $description,
        array  $badges,      array  $visaPathway,  array  $groundRealityPoints,
        array  $visaTypes
    ): array {
        if (empty(trim($countryName))) return ['success' => false, 'message' => 'Country name is required.'];
        if (empty(trim($countryCode))) return ['success' => false, 'message' => 'Country code is required.'];

        /* Use countryCode as the document ID (lowercase, trimmed) */
        $docId = strtolower(trim($countryCode));
        $url   = "{$this->baseUrl}?documentId=" . urlencode($docId);

        $body   = $this->buildBody(
            $countryName, $countryCode, $flagEmoji, $systemType, $status,
            $description, $badges, $visaPathway, $groundRealityPoints, $visaTypes,
            true, true
        );
        $result = $this->request('POST', $url, $body);
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Visa entry for '{$countryName}' added successfully.", 'id' => $docId];
    }

    /** Update an existing visa document. */
    public function updateVisa(
        string $id,          string $countryName, string $countryCode,
        string $flagEmoji,   string $systemType,  string $status,
        string $description, array  $badges,      array  $visaPathway,
        array  $groundRealityPoints, array $visaTypes
    ): array {
        if (empty(trim($id))) return ['success' => false, 'message' => 'Visa ID is required.'];

        $fieldNames = [
            'countryName','countryCode','flagEmoji','systemType','status',
            'description','badges','visaPathway','groundRealityPoints','visaTypes','updatedAt'
        ];
        $mask = implode('&', array_map(fn($f) => "updateMask.fieldPaths={$f}", $fieldNames));

        $body   = $this->buildBody(
            $countryName, $countryCode, $flagEmoji, $systemType, $status,
            $description, $badges, $visaPathway, $groundRealityPoints, $visaTypes
        );
        $result = $this->request('PATCH', "{$this->baseUrl}/{$id}?{$mask}", $body);
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Visa entry for '{$countryName}' updated successfully."];
    }

    /** Delete a visa document. */
    public function deleteVisa(string $id): array
    {
        if (empty(trim($id))) return ['success' => false, 'message' => 'Visa ID is required.'];
        $result = $this->request('DELETE', "{$this->baseUrl}/{$id}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Visa entry deleted successfully.'];
    }
}
