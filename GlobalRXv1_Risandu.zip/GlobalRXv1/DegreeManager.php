<?php
require_once 'config.php';

class DegreeManager {
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    public function __construct() {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/Degree";
    }

    private function request(string $method, string $url, ?array $body = null): array {
        $url .= (str_contains($url, '?') ? '&' : '?') . "key={$this->apiKey}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            /* ── fixes that resolve most silent cURL failures ── */
            CURLOPT_SSL_VERIFYPEER => false,   // bypass SSL cert issues on some hosts
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT        => 15,       // fail fast rather than hang forever
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        /* ── cURL-level failure (no HTTP response at all) ── */
        if ($response === false) {
            return ['success' => false, 'message' => "cURL error: {$curlError}"];
        }

        $data = json_decode($response, true);

        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP {$httpCode} — " . substr($response, 0, 200);
            return ['success' => false, 'message' => "Firestore error: $msg"];
        }

        return ['success' => true, 'data' => $data];
    }

    private function parseDoc(array $doc): array {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');
        return [
            'id'         => $id,
            'degreeName' => $fields['degreeName']['stringValue'] ?? '',
            'field'      => $fields['Field']['stringValue']      ?? '',
            'university' => $fields['University']['stringValue'] ?? '',
            'duration'   => $fields['duration']['stringValue']   ?? '',
            'imageUrl'   => $fields['imageUrl']['stringValue']   ?? '',
            'program'    => $fields['program']['stringValue']    ?? '',
        ];
    }

    private function buildDoc(string $degreeName, string $field, string $university, string $duration, string $imageUrl, string $program): array {
        return [
            'fields' => [
                'degreeName' => ['stringValue' => $degreeName],
                'Field'      => ['stringValue' => $field],
                'University' => ['stringValue' => $university],
                'duration'   => ['stringValue' => $duration],
                'imageUrl'   => ['stringValue' => $imageUrl],
                'program'    => ['stringValue' => $program],
            ]
        ];
    }

    public function getAllDegrees(): array {
        $result = $this->request('GET', $this->baseUrl);
        if (!$result['success']) return $result;

        $degrees = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $degrees[] = $this->parseDoc($doc);
        }
        return ['success' => true, 'degrees' => $degrees];
    }

    public function getDegree(string $degreeId): array {
        $result = $this->request('GET', "{$this->baseUrl}/{$degreeId}");
        if (!$result['success']) return $result;
        return ['success' => true, 'degree' => $this->parseDoc($result['data'])];
    }

    public function addDegree(string $degreeId, string $degreeName, string $field, string $university, string $duration, string $imageUrl, string $program): array {
        if (empty($degreeId) || empty($degreeName)) {
            return ['success' => false, 'message' => 'Degree ID and name are required.'];
        }
        $url    = $this->baseUrl . '?documentId=' . urlencode($degreeId);
        $result = $this->request('POST', $url, $this->buildDoc($degreeName, $field, $university, $duration, $imageUrl, $program));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Degree '{$degreeName}' added successfully."];
    }

    public function updateDegree(string $degreeId, string $degreeName, string $field, string $university, string $duration, string $imageUrl, string $program): array {
        if (empty($degreeId) || empty($degreeName)) {
            return ['success' => false, 'message' => 'Degree ID and name are required.'];
        }
        $mask   = 'updateMask.fieldPaths=degreeName&updateMask.fieldPaths=Field&updateMask.fieldPaths=University&updateMask.fieldPaths=duration&updateMask.fieldPaths=imageUrl&updateMask.fieldPaths=program';
        $url    = "{$this->baseUrl}/{$degreeId}?{$mask}";
        $result = $this->request('PATCH', $url, $this->buildDoc($degreeName, $field, $university, $duration, $imageUrl, $program));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Degree '{$degreeName}' updated successfully."];
    }

    public function deleteDegree(string $degreeId): array {
        if (empty($degreeId)) {
            return ['success' => false, 'message' => 'Degree ID is required.'];
        }
        $result = $this->request('DELETE', "{$this->baseUrl}/{$degreeId}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Degree deleted successfully.'];
    }
}
