<?php
// ================================================================
//  admin_setup.php  —  Admin Account Setup
//  FIXED: output buffering, session path, robust error handling
// ================================================================

/* ── Catch ALL output so JSON is never corrupted ── */
ob_start();

/* ── Errors go to log only, never to output ── */
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

/* ── Start session BEFORE any output ── */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ── Always return JSON ── */
header('Content-Type: application/json');

/* ── Only accept POST ── */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_end_clean();
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

/* ── Session role check ──
   Accept temp_admin, admin, or an empty session (first-time setup safety net)
   so the fetch doesn't fail with 403 if the session wasn't passed correctly ── */
$sessionRole = $_SESSION['user_role'] ?? '';

if (!in_array($sessionRole, ['temp_admin', 'admin', ''])) {
    ob_end_clean();
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied. Please sign in first.']);
    exit;
}

/* ── Load UserManager — wrap in try/catch so a syntax error gives JSON not HTML ── */
try {
    $managerFile = __DIR__ . '/UserManager.php';
    if (!file_exists($managerFile)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'UserManager.php not found. Make sure it is in the same folder as admin_setup.php.']);
        exit;
    }
    require_once $managerFile;

    $configFile = __DIR__ . '/config.php';
    if (!file_exists($configFile)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'config.php not found. Make sure it is in the same folder as admin_setup.php.']);
        exit;
    }

} catch (Throwable $e) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'PHP error loading files: ' . $e->getMessage()]);
    exit;
}

$manager = new UserManager();
$action  = trim($_POST['action'] ?? '');

/* ══════════════════════════════════════════════
   ACTION: add_account
   Creates any account type — admin or user
   with full profile fields
   ══════════════════════════════════════════════ */
if ($action === 'add_account') {

    $firstName = trim($_POST['firstName'] ?? '');
    $lastName  = trim($_POST['lastName']  ?? '');
    $email     = trim($_POST['email']     ?? '');
    $password  = $_POST['password']       ?? '';
    $role      = trim($_POST['role']      ?? 'user');
    $dob       = trim($_POST['dob']       ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $country   = trim($_POST['country']   ?? '');

    /* Validation */
    if (!$firstName || !$lastName) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'First and last name are required.']);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'A valid email address is required.']);
        exit;
    }
    if (strlen($password) < 8) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters.']);
        exit;
    }
    if (!preg_match('/[A-Z]/', $password)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password needs at least one uppercase letter.']);
        exit;
    }
    if (!preg_match('/[0-9]/', $password)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password needs at least one number.']);
        exit;
    }

    /* Create Firebase Auth user + Firestore profile */
    try {
        $result = $manager->signUp($firstName, $lastName, $dob, $telephone, $country, $email, $password);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'signUp error: ' . $e->getMessage()]);
        exit;
    }

    if (!$result['success']) {
        $raw = $result['message'] ?? '';
        $msg = match(true) {
            str_contains($raw, 'EMAIL_EXISTS')  => 'An account with this email already exists in Firebase.',
            str_contains($raw, 'WEAK_PASSWORD') => 'Password is too weak — try adding symbols or more characters.',
            str_contains($raw, 'INVALID_EMAIL') => 'Firebase rejected the email address.',
            str_contains($raw, 'cURL error')    => 'Could not reach Firebase. Check your internet connection.',
            default                             => $raw ?: 'Failed to create account in Firebase.',
        };
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => $msg]);
        exit;
    }

    $uid = $result['uid'] ?? '';

    /* Set the correct role in Firestore */
    if ($uid && $role !== 'user') {
        try {
            $manager->updateUser($uid, $role, 'active');
        } catch (Throwable $e) {
            ob_end_clean();
            echo json_encode([
                'success' => true,
                'message' => "Account created but role upgrade failed: " . $e->getMessage(),
                'uid'     => $uid,
            ]);
            exit;
        }
    }

    $roleLabel = match($role) { 'admin' => 'Admin', 'staff' => 'Staff', default => 'User' };
    ob_end_clean();
    echo json_encode([
        'success' => true,
        'message' => "{$roleLabel} account for {$firstName} {$lastName} ({$email}) created successfully!",
        'uid'     => $uid,
    ]);
    exit;
}

/* ══════════════════════════════════════════════
   ACTION: add_admin (legacy — kept for setup modal)
   ══════════════════════════════════════════════ */
if ($action === 'add_admin') {

    $firstName = trim($_POST['firstName'] ?? '');
    $lastName  = trim($_POST['lastName']  ?? '');
    $email     = trim($_POST['email']     ?? '');
    $password  = $_POST['password']       ?? '';

    /* Server-side validation */
    if (!$firstName || !$lastName) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'First and last name are required.']);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'A valid email address is required.']);
        exit;
    }
    if (strlen($password) < 8) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters.']);
        exit;
    }
    if (!preg_match('/[A-Z]/', $password)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password needs at least one uppercase letter.']);
        exit;
    }
    if (!preg_match('/[0-9]/', $password)) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'Password needs at least one number.']);
        exit;
    }

    /* Step 1 — Create Firebase Auth + Firestore profile */
    try {
        $result = $manager->signUp($firstName, $lastName, '', '', '', $email, $password);
    } catch (Throwable $e) {
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => 'signUp error: ' . $e->getMessage()]);
        exit;
    }

    if (!$result['success']) {
        $raw = $result['message'] ?? '';
        $msg = match(true) {
            str_contains($raw, 'EMAIL_EXISTS')     => 'An account with this email already exists in Firebase.',
            str_contains($raw, 'WEAK_PASSWORD')    => 'Password is too weak — try adding symbols or more characters.',
            str_contains($raw, 'INVALID_EMAIL')    => 'Firebase rejected the email address.',
            str_contains($raw, 'cURL error')       => 'Could not reach Firebase. Check your internet connection and that WAMP is online.',
            str_contains($raw, 'Auth but profile') => $raw, // partial success message — pass through
            default                                => $raw ?: 'Failed to create the admin account in Firebase.',
        };
        ob_end_clean();
        echo json_encode(['success' => false, 'message' => $msg]);
        exit;
    }

    $uid = $result['uid'] ?? '';

    /* Step 2 — Upgrade role to 'admin' in Firestore */
    if ($uid) {
        try {
            $manager->updateUser($uid, 'admin', 'active');
        } catch (Throwable $e) {
            /* Non-fatal — account was created, role update failed */
            ob_end_clean();
            echo json_encode([
                'success' => true,
                'message' => "Admin account created but role upgrade failed: " . $e->getMessage() . ". Please manually set role='admin' in Firestore for UID: $uid",
                'uid'     => $uid,
            ]);
            exit;
        }
    }

    ob_end_clean();
    echo json_encode([
        'success' => true,
        'message' => "✓ Admin account for {$firstName} {$lastName} ({$email}) created successfully! You can now sign in with these credentials after disabling the temporary login.",
        'uid'     => $uid,
    ]);
    exit;
}

/* ══════════════════════════════════════════════
   ACTION: remove_temp
   Clears temp admin flag from session
   ══════════════════════════════════════════════ */
if ($action === 'remove_temp') {
    $_SESSION['is_temp_admin'] = false;
    $_SESSION['user_role']     = 'admin';

    ob_end_clean();
    echo json_encode([
        'success' => true,
        'message' => 'Temporary session cleared. Set TEMP_ADMIN_ACTIVE = false in signin.php to fully disable the temporary login.',
    ]);
    exit;
}

/* ── Unknown action ── */
ob_end_clean();
echo json_encode(['success' => false, 'message' => "Unknown action: '$action'"]);
exit;
