<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

/* ══════════════════════════════════════════════
   SESSION GUARD — block non-admin access
   ══════════════════════════════════════════════ */
$_role = strtolower($_SESSION['user_role'] ?? '');
if (!in_array($_role, ['admin', 'temp_admin'])) {
    header('Location: signin.html');
    exit;
}

/* ── Detect temp admin session ── */
$isTempAdmin = ($_SESSION['is_temp_admin'] ?? false) === true
            || ($_SESSION['user_role']     ?? '')    === 'temp_admin';

require_once 'CourseManager.php';
require_once 'DegreeManager.php';
require_once 'EnrollmentManager.php';
require_once 'UserManager.php';

$courseManager     = new CourseManager();
$degreeManager     = new DegreeManager();
$enrollmentManager = new EnrollmentManager();
$userManager       = new UserManager();

$message     = '';
$messageType = '';

/* ══════════════════════════════════════════════
   HANDLE FORM SUBMISSIONS
   ══════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {

        case 'add_course':
            $r = $courseManager->addCourse(
                trim($_POST['course_id']   ?? ''),
                trim($_POST['cname']       ?? ''),
                trim($_POST['type']        ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['iconUrl']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_course':
            $r = $courseManager->updateCourse(
                trim($_POST['course_id']   ?? ''),
                trim($_POST['cname']       ?? ''),
                trim($_POST['type']        ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['iconUrl']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_course':
            $r = $courseManager->deleteCourse(trim($_POST['course_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'add_degree':
            $r = $degreeManager->addDegree(
                trim($_POST['degree_id']   ?? ''),
                trim($_POST['degreeName']  ?? ''),
                trim($_POST['field']       ?? ''),
                trim($_POST['university']  ?? ''),
                trim($_POST['duration']    ?? ''),
                trim($_POST['imageUrl']    ?? ''),
                trim($_POST['program']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_degree':
            $r = $degreeManager->updateDegree(
                trim($_POST['degree_id']   ?? ''),
                trim($_POST['degreeName']  ?? ''),
                trim($_POST['field']       ?? ''),
                trim($_POST['university']  ?? ''),
                trim($_POST['duration']    ?? ''),
                trim($_POST['imageUrl']    ?? ''),
                trim($_POST['program']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_degree':
            $r = $degreeManager->deleteDegree(trim($_POST['degree_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'add_enrollment':
            $r = $enrollmentManager->addEnrollment(
                trim($_POST['fullName'] ?? ''),
                trim($_POST['email']   ?? ''),
                trim($_POST['age']     ?? ''),
                trim($_POST['location']?? ''),
                trim($_POST['phone']   ?? ''),
                trim($_POST['course']  ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_enrollment':
            $r = $enrollmentManager->updateEnrollment(
                trim($_POST['enrollment_id'] ?? ''),
                trim($_POST['fullName']      ?? ''),
                trim($_POST['email']         ?? ''),
                trim($_POST['age']           ?? ''),
                trim($_POST['location']      ?? ''),
                trim($_POST['phone']         ?? ''),
                trim($_POST['course']        ?? ''),
                trim($_POST['status']        ?? ''),
                trim($_POST['result']        ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_enrollment':
            $r = $enrollmentManager->deleteEnrollment(trim($_POST['enrollment_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_user':
            $r = $userManager->updateUser(
                trim($_POST['user_id'] ?? ''),
                trim($_POST['role']    ?? ''),
                trim($_POST['status']  ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_user':
            $r = $userManager->deleteUser(trim($_POST['user_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;
    }
}

/* ══════════════════════════════════════════════
   FETCH LIVE DATA FROM FIRESTORE
   ══════════════════════════════════════════════ */
$coursesResult    = $courseManager->getAllCourses();
$courses          = $coursesResult['success'] ? $coursesResult['courses'] : [];
$coursesError     = $coursesResult['success'] ? '' : ($coursesResult['message'] ?? 'Could not load courses.');

$degreesResult    = $degreeManager->getAllDegrees();
$degrees          = $degreesResult['success'] ? $degreesResult['degrees'] : [];
$degreesError     = $degreesResult['success'] ? '' : ($degreesResult['message'] ?? 'Could not load degrees.');

$enrollmentsResult = $enrollmentManager->getAllEnrollments();
$enrollments       = $enrollmentsResult['success'] ? $enrollmentsResult['enrollments'] : [];
$enrollmentsError  = $enrollmentsResult['success'] ? '' : ($enrollmentsResult['message'] ?? 'Could not load enrollments.');

$usersResult   = $userManager->getAllUsers();
$firebaseUsers = $usersResult['success'] ? $usersResult['users'] : [];
$usersError    = $usersResult['success'] ? '' : ($usersResult['message'] ?? 'Could not load users.');

$firebaseAdmins   = array_values(array_filter($firebaseUsers, fn($u) => strtolower($u['role'] ?? '') === 'admin'));
$firebaseRegUsers = array_values(array_filter($firebaseUsers, fn($u) => strtolower($u['role'] ?? '') !== 'admin'));

$statusCounts = ['Pending' => 0, 'Under Review' => 0, 'Approved' => 0, 'Rejected' => 0];
foreach ($enrollments as $e) {
    $s = $e['status'] ?? 'Pending';
    isset($statusCounts[$s]) ? $statusCounts[$s]++ : ($statusCounts[$s] = 1);
}

$statusBadge  = ['Pending'=>'badge-gold','Under Review'=>'badge-blue','Approved'=>'badge-green','Rejected'=>'badge-red'];
$statusColors = ['Pending'=>'var(--gold)','Under Review'=>'var(--blue)','Approved'=>'var(--green-dark)','Rejected'=>'var(--red)'];

function userStatusClass(string $status): string {
    return match(strtolower($status)) {
        'active' => 'badge-green', 'inactive' => 'badge-gray', 'suspended' => 'badge-red', default => 'badge-gray',
    };
}
function userRoleClass(string $role): string {
    return match(strtolower($role)) {
        'admin' => 'badge-red', 'staff' => 'badge-blue', default => 'badge-teal',
    };
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --green-dark:#1e3a2f;--green-mid:#2d5040;--green-light:#3a6652;
  --gold:#c9a84c;--gold-light:#e8c96a;--cream:#f4f2ed;--white:#ffffff;
  --text-dark:#1a2e25;--text-mid:#4a6358;--text-light:#8aa898;
  --red:#e05c5c;--blue:#4a7fb5;--teal:#3a9b8c;--purple:#8a5fc9;
  --sidebar-w:240px;--radius:12px;
  --shadow:0 2px 16px rgba(30,58,47,0.09);--shadow-md:0 4px 24px rgba(30,58,47,0.13);
}
html,body{width:100%;height:100%;min-height:100vh;overflow:hidden;font-family:'DM Sans',sans-serif;background:var(--cream);color:var(--text-dark)}
.app-shell{display:flex;width:100vw;height:100vh;overflow:hidden}
#sidebar{width:var(--sidebar-w);min-width:var(--sidebar-w);height:100vh;background:linear-gradient(180deg,var(--green-dark) 0%,var(--green-mid) 55%,var(--green-light) 100%);display:flex;flex-direction:column;flex-shrink:0;box-shadow:3px 0 24px rgba(30,58,47,0.18);overflow-y:auto;overflow-x:hidden}
#sidebar::-webkit-scrollbar{width:3px}#sidebar::-webkit-scrollbar-thumb{background:rgba(201,168,76,.3);border-radius:2px}
.sidebar-profile{padding:24px 18px 16px;border-bottom:1px solid rgba(201,168,76,0.18);display:flex;flex-direction:column;align-items:center;gap:7px;flex-shrink:0}
.avatar-wrap{width:56px;height:56px;border-radius:50%;background:var(--gold);display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:700;color:var(--green-dark);box-shadow:0 0 0 4px rgba(201,168,76,0.25);position:relative}
.avatar-dot{position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:#5bc98a;border:2px solid var(--green-dark)}
.profile-name{color:var(--white);font-size:12.5px;font-weight:600;text-align:center}.profile-role{color:var(--gold-light);font-size:10px;opacity:.85;text-align:center}
.sidebar-label{padding:12px 18px 4px;color:var(--gold);font-size:8.5px;font-weight:600;letter-spacing:2px;text-transform:uppercase;opacity:.7}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 18px;margin:1px 7px;border-radius:8px;cursor:pointer;transition:all .18s;color:rgba(255,255,255,0.70);font-size:12px;font-weight:500;white-space:nowrap}
.nav-item:hover{background:rgba(201,168,76,0.12);color:var(--white)}.nav-item.active{background:linear-gradient(135deg,rgba(201,168,76,0.22),rgba(201,168,76,0.06));color:var(--gold-light);box-shadow:inset 2px 0 0 var(--gold)}
.nav-icon{width:16px;height:16px;flex-shrink:0;opacity:.85}.nav-badge{margin-left:auto;background:var(--gold);color:var(--green-dark);font-size:8.5px;font-weight:700;padding:1px 5px;border-radius:9px}
.sidebar-bottom{margin-top:auto;padding:12px 18px;border-top:1px solid rgba(201,168,76,0.12)}
.logout-btn{display:flex;align-items:center;gap:9px;color:rgba(255,255,255,0.45);font-size:11.5px;cursor:pointer;transition:.18s;padding:7px 9px;border-radius:7px}
.logout-btn:hover{color:var(--red);background:rgba(224,92,92,.08)}
#main{flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden;background:var(--cream);min-width:0}
.topbar{flex-shrink:0;height:58px;background:var(--white);display:flex;align-items:center;justify-content:space-between;padding:0 24px;box-shadow:0 1px 0 rgba(30,58,47,0.07)}
.topbar-left{display:flex;flex-direction:column}.page-title{font-family:'Playfair Display',serif;font-size:18px;color:var(--text-dark);font-weight:700}.breadcrumb{font-size:10px;color:var(--text-light);margin-top:1px}
.topbar-right{display:flex;align-items:center;gap:8px}
.search-bar{display:flex;align-items:center;gap:7px;background:var(--cream);border:1.5px solid transparent;border-radius:8px;padding:6px 11px;width:190px}
.search-bar:focus-within{border-color:var(--gold);background:var(--white)}.search-bar input{border:none;background:transparent;font-size:12px;outline:none;width:100%;font-family:'DM Sans',sans-serif}
.icon-btn{width:34px;height:34px;border-radius:8px;background:var(--cream);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative}
.notif-dot{position:absolute;top:6px;right:6px;width:7px;height:7px;border-radius:50%;background:var(--red);border:1.5px solid var(--white)}
.page-scroll{flex:1;overflow-y:auto;overflow-x:hidden}.page-scroll::-webkit-scrollbar{width:5px}.page-scroll::-webkit-scrollbar-thumb{background:#c8d8d0;border-radius:3px}
.page{display:none;padding:22px 24px 32px;animation:fadeIn .2s ease}.page.active{display:block}
@keyframes fadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:none}}
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.stat-card{background:var(--white);border-radius:var(--radius);padding:16px;box-shadow:var(--shadow);border:1.5px solid transparent;transition:.18s}
.stat-card:hover{border-color:var(--gold);transform:translateY(-2px);box-shadow:var(--shadow-md)}
.stat-top{display:flex;justify-content:space-between;align-items:flex-start}.stat-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:17px}
.stat-val{font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--text-dark)}.stat-label{font-size:11px;color:var(--text-light);font-weight:500}
.stat-trend{font-size:10px}.trend-up{color:var(--teal)}.trend-down{color:var(--red)}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:13px}
.section-title{font-family:'Playfair Display',serif;font-size:15.5px;color:var(--text-dark)}.section-sub{font-size:10.5px;color:var(--text-light);margin-top:2px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 15px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none;transition:.16s;font-family:'DM Sans',sans-serif}
.btn-primary{background:var(--green-dark);color:var(--white)}.btn-primary:hover{background:var(--green-mid);transform:translateY(-1px);box-shadow:0 4px 12px rgba(30,58,47,.2)}
.btn-gold{background:var(--gold);color:var(--green-dark)}.btn-outline{background:transparent;color:var(--text-mid);border:1.5px solid #dce8e3}.btn-outline:hover{border-color:var(--gold);color:var(--gold)}
.btn-sm{padding:5px 10px;font-size:11px;border-radius:6px}.btn-danger{background:rgba(224,92,92,.1);color:var(--red);border:1px solid rgba(224,92,92,.2)}.btn-danger:hover{background:var(--red);color:#fff}
.table-wrap{background:var(--white);border-radius:var(--radius);box-shadow:var(--shadow);overflow:hidden}
.table-toolbar{display:flex;align-items:center;gap:7px;padding:13px 17px;border-bottom:1px solid #eef2ef;flex-wrap:wrap}
.filter-chip{padding:4px 10px;border-radius:16px;font-size:10.5px;font-weight:500;background:var(--cream);color:var(--text-mid);cursor:pointer;border:1.5px solid transparent}
.filter-chip.active,.filter-chip:hover{background:var(--green-dark);color:var(--white)}
table{width:100%;border-collapse:collapse}thead tr{background:#eff5f2}
th{padding:10px 14px;text-align:left;font-size:10px;font-weight:600;color:var(--text-light);text-transform:uppercase;white-space:nowrap}
td{padding:11px 14px;font-size:12px;color:var(--text-dark);border-bottom:1px solid #f0f4f1}tbody tr:hover{background:#f8fbf9}tbody tr:last-child td{border-bottom:none}
.avatar-sm{width:30px;height:30px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;flex-shrink:0}
.cell-with-avatar{display:flex;align-items:center;gap:8px}.cell-sub{font-size:10px;color:var(--text-light);margin-top:1px}.action-group{display:flex;gap:5px}
.badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:16px;font-size:10px;font-weight:600}
.badge-green{background:#e8f5ee;color:#2d7a4f}.badge-gold{background:#fdf3dc;color:#956c10}.badge-red{background:#fce8e8;color:#c0392b}
.badge-blue{background:#e8f0fb;color:#2155a3}.badge-teal{background:#e2f4f1;color:#1a7a6a}.badge-gray{background:#efefef;color:#666}.badge-purple{background:#f0e8fb;color:#6b2fa0}
.pagination{padding:10px 16px;border-top:1px solid #eef2ef;display:flex;align-items:center}.page-info{font-size:11px;color:var(--text-light)}
.sub-tabs{display:flex;gap:4px;margin-bottom:0;border-bottom:1.5px solid #e2ede8}
.sub-tab{padding:8px 16px;font-size:12px;font-weight:600;cursor:pointer;border-radius:8px 8px 0 0;border:1.5px solid transparent;background:var(--cream);color:var(--text-mid);transition:.15s;white-space:nowrap}
.sub-tab.active{background:var(--white);color:var(--text-dark);border-color:#e2ede8 #e2ede8 var(--white)}
.tab-count{font-size:10px;padding:1px 6px;border-radius:10px;margin-left:4px}.sub-panel{display:none;padding-top:16px}.sub-panel.active{display:block}
.dash-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.dash-card{background:var(--white);border-radius:var(--radius);padding:16px;box-shadow:var(--shadow)}.dash-card-title{font-size:11px;font-weight:600;color:var(--text-mid);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px}
.activity-item{padding:8px 0;border-bottom:1px solid #f0f4f1;display:flex;align-items:flex-start;gap:8px}.activity-item:last-child{border-bottom:none}
.activity-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;margin-top:4px}.activity-text{font-size:12px;color:var(--text-dark)}.activity-time{font-size:10px;color:var(--text-light);margin-top:1px}
.progress-item{margin-bottom:10px}.progress-label{display:flex;justify-content:space-between;font-size:11px;color:var(--text-mid);margin-bottom:5px;font-weight:500}
.progress-bar{height:6px;background:#eef2ef;border-radius:4px;overflow:hidden}.progress-fill{height:100%;border-radius:4px;transition:width .6s ease}
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(20,40,30,.45);z-index:1000;align-items:center;justify-content:center;backdrop-filter:blur(4px)}.modal-overlay.open{display:flex}
.modal{background:var(--white);border-radius:14px;padding:0;width:500px;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(30,58,47,.22)}
.modal::-webkit-scrollbar{width:3px}.modal::-webkit-scrollbar-thumb{background:#c8d8d0}
.modal-header{display:flex;justify-content:space-between;align-items:center;padding:20px 24px 16px;border-bottom:1px solid #eef2ef}
.modal-title{font-family:'Playfair Display',serif;font-size:16px;color:var(--text-dark)}
.close-btn{width:28px;height:28px;border-radius:7px;background:var(--cream);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:14px;color:var(--text-mid);transition:.15s}.close-btn:hover{background:#fce8e8;color:var(--red)}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.form-group{display:flex;flex-direction:column;gap:4px}.form-group.full{grid-column:1/-1}
label{font-size:10.5px;font-weight:600;color:var(--text-mid);text-transform:uppercase;letter-spacing:.4px}
input,select,textarea{padding:8px 10px;border-radius:7px;font-size:12px;border:1.5px solid #dce8e3;outline:none;width:100%;font-family:'DM Sans',sans-serif;color:var(--text-dark);background:var(--white);transition:.15s}
input:focus,select:focus,textarea:focus{border-color:var(--gold);background:#fffdf7}input[readonly]{background:#f5f5f5;color:var(--text-light)}textarea{resize:vertical;min-height:70px}
.modal-footer{display:flex;gap:8px;justify-content:flex-end;padding:16px 24px;border-top:1px solid #eef2ef}
#toast{position:fixed;bottom:22px;right:22px;z-index:9999;background:var(--green-dark);color:white;padding:9px 16px;border-radius:8px;font-size:12px;font-weight:500;transform:translateY(16px);opacity:0;transition:all .26s;display:flex;gap:8px;align-items:center;box-shadow:var(--shadow-md)}
#toast.show{transform:none;opacity:1}
.enroll-search{border:1.5px solid #dce8e3;border-radius:8px;padding:5px 11px;font-size:11.5px;font-family:'DM Sans',sans-serif;outline:none;color:var(--text-dark);background:var(--white);transition:.15s}.enroll-search:focus{border-color:var(--gold)}
tr.row-hidden{display:none!important}.error-banner{background:#fff3cd;border:1.5px solid #ffc107;border-radius:8px;padding:11px 15px;font-size:12px;color:#856404;margin-bottom:14px}
.ae-field-error{font-size:11px;color:#e05c5c;margin-top:3px;display:block;min-height:14px}.ae-invalid{border-color:#e05c5c!important;box-shadow:0 0 0 3px rgba(224,92,92,.10)!important}
.emp-sub-tab{padding:9px 18px;font-size:12px;font-weight:600;cursor:pointer;border-radius:8px 8px 0 0;border:1.5px solid transparent;background:var(--cream);color:var(--text-mid);transition:.15s;white-space:nowrap}
.emp-sub-tab.active{background:var(--white);color:var(--text-dark);border-color:#e2ede8 #e2ede8 var(--white)}.emp-sub-tab:hover:not(.active){background:#e8f0ed;color:var(--text-dark)}
#php-toast{position:fixed;top:24px;right:24px;z-index:99999;padding:14px 22px;border-radius:10px;font-size:13px;font-weight:500;box-shadow:0 4px 20px rgba(0,0,0,.15)}
#temp-admin-banner{position:fixed;top:0;left:0;right:0;z-index:99000;background:linear-gradient(135deg,#c0392b,#e74c3c);color:#fff;padding:10px 24px;display:flex;align-items:center;gap:12px;font-size:12.5px;font-weight:500;font-family:'DM Sans',sans-serif;box-shadow:0 2px 16px rgba(192,57,43,.35)}
#temp-admin-banner .tb-icon{font-size:18px;flex-shrink:0}#temp-admin-banner .tb-msg{flex:1;line-height:1.4}#temp-admin-banner .tb-msg strong{font-weight:700}
#temp-admin-banner .tb-btn{padding:6px 14px;border-radius:7px;font-size:11.5px;font-weight:600;cursor:pointer;border:none;font-family:'DM Sans',sans-serif;white-space:nowrap;transition:.15s}
#temp-admin-banner .tb-setup{background:#fff;color:#c0392b}#temp-admin-banner .tb-setup:hover{background:#fdf0f0}
#temp-admin-banner .tb-dismiss{background:rgba(255,255,255,.18);color:#fff;margin-left:6px}#temp-admin-banner .tb-dismiss:hover{background:rgba(255,255,255,.3)}
body.has-temp-banner #main{padding-top:44px}body.has-temp-banner #sidebar{padding-top:44px}
#deg-del-overlay{display:none;position:fixed;inset:0;background:rgba(20,40,30,.45);z-index:2000;align-items:center;justify-content:center;backdrop-filter:blur(4px)}
#deg-del-overlay.open{display:flex}
@keyframes smSpin{to{transform:rotate(360deg)}}
</style>
</head>
<body>

<?php if ($isTempAdmin): ?>
<div id="temp-admin-banner">
  <span class="tb-icon">⚠️</span>
  <span class="tb-msg"><strong>You are logged in with the temporary admin account.</strong> Create a permanent admin account and disable the temporary login.</span>
  <button class="tb-btn tb-setup" onclick="openSetupModal()">＋ Create Admin Account</button>
  <button class="tb-btn tb-dismiss" onclick="dismissTempBanner()">Remind me later</button>
</div>
<script>document.body.classList.add('has-temp-banner');</script>
<?php endif; ?>

<?php if ($message): ?>
<div id="php-toast" style="background:<?= $messageType==='success'?'#d4edda':'#f8d7da' ?>;color:<?= $messageType==='success'?'#155724':'#721c24' ?>;">
  <?= htmlspecialchars($message) ?>
</div>
<script>setTimeout(()=>{const t=document.getElementById('php-toast');if(t)t.remove();},4000);</script>
<?php endif; ?>

<div class="app-shell">

<!-- SIDEBAR -->
<div id="sidebar">
  <div class="sidebar-profile">
    <?php
      $sessionName  = $_SESSION['user_name']  ?? $_SESSION['user_firstName'] ?? 'Admin';
      $sessionEmail = $_SESSION['user_email'] ?? '';
      $sessionRole  = $_SESSION['user_role']  ?? 'admin';
      $avatarLetter = strtoupper(mb_substr($sessionName, 0, 1));
      $roleLabel = match(strtolower($sessionRole)) {
          'temp_admin' => 'Temporary Admin', 'admin' => 'Administrator',
          'staff' => 'Staff', default => ucfirst($sessionRole),
      };
    ?>
    <div class="avatar-wrap"><?= htmlspecialchars($avatarLetter) ?><div class="avatar-dot"></div></div>
    <div class="profile-name"><?= htmlspecialchars($sessionName) ?></div>
    <div class="profile-role"><?= htmlspecialchars($roleLabel) ?></div>
    <?php if ($sessionEmail): ?>
    <div style="font-size:9.5px;color:rgba(255,255,255,0.35);margin-top:-3px;text-align:center;word-break:break-all;max-width:180px"><?= htmlspecialchars($sessionEmail) ?></div>
    <?php endif; ?>
  </div>
  <div class="sidebar-label">Main Menu</div>
  <div class="nav-item active" onclick="navigate('dashboard',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>Dashboard
  </div>
  <div class="nav-item" onclick="navigate('academics',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>Academic Programs<span class="nav-badge">3</span>
  </div>
  <div class="nav-item" onclick="navigate('scholarships',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>Scholarships<span class="nav-badge">5</span>
  </div>
  <div class="nav-item" onclick="navigate('feedback',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>Feedback<span class="nav-badge">8</span>
  </div>
  <div class="nav-item" onclick="navigate('visa',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M7 15h2M12 15h5"/></svg>Visa Management
  </div>
  <div class="nav-item" onclick="navigate('enrollment',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>Enrollment<span class="nav-badge"><?= count($enrollments) ?></span>
  </div>
  <div class="nav-item" onclick="navigate('employees',this)">
    <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>Employee Mgmt<span class="nav-badge"><?= count($firebaseUsers) ?></span>
  </div>
  <div class="sidebar-bottom">
    <div class="logout-btn" onclick="signOut()">
      <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>Sign Out
    </div>
  </div>
</div>

<!-- MAIN -->
<div id="main">
  <div class="topbar">
    <div class="topbar-left">
      <div class="page-title" id="pageTitle">Dashboard Overview</div>
      <div class="breadcrumb" id="breadcrumb">Admin → Dashboard</div>
    </div>
    <div class="topbar-right">
      <div class="search-bar">
        <svg width="12" height="12" fill="none" stroke="#8aa898" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input placeholder="Search anything…">
      </div>
      <div class="icon-btn"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/></svg><div class="notif-dot"></div></div>
      <div class="icon-btn"><svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg></div>
    </div>
  </div>

  <div class="page-scroll">

    <!-- DASHBOARD -->
    <div id="page-dashboard" class="page active">
      <div class="stats-row">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">🎓</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($enrollments) ?></div><div class="stat-label">Total Enrollments</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">📚</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($courses) ?></div><div class="stat-label">Active Courses</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">🎓</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($degrees) ?></div><div class="stat-label">Degree Programs</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div><div class="stat-val"><?= $statusCounts['Pending'] ?></div><div class="stat-label">Pending</div></div>
      </div>
      <div class="dash-grid">
        <div class="dash-card">
          <div class="dash-card-title">📋 Recent Enrollments</div>
          <?php if ($enrollmentsError): ?><div class="error-banner">⚠️ <?= htmlspecialchars($enrollmentsError) ?></div>
          <?php elseif (!empty($enrollments)): ?>
            <?php foreach (array_slice($enrollments,0,5) as $e): ?>
            <div class="activity-item"><div class="activity-dot" style="background:#5bc98a"></div><div><div class="activity-text"><strong><?= htmlspecialchars($e['fullName']) ?></strong> → <?= htmlspecialchars($e['course']) ?></div><div class="activity-time"><?= htmlspecialchars($e['createdAt']) ?></div></div></div>
            <?php endforeach; ?>
          <?php else: ?><div style="color:#999;font-size:12px;padding:10px 0">No enrollments yet.</div><?php endif; ?>
        </div>
        <div class="dash-card">
          <div class="dash-card-title">📊 Enrollment Status</div>
          <?php $total=max(count($enrollments),1); foreach ($statusCounts as $status=>$count): ?>
          <div class="progress-item"><div class="progress-label"><span><?= $status ?></span><span style="font-weight:600"><?= $count ?></span></div><div class="progress-bar"><div class="progress-fill" style="width:<?= round($count/$total*100) ?>%;background:<?= $statusColors[$status]??'#ccc' ?>"></div></div></div>
          <?php endforeach; ?>
        </div>
        <div class="dash-card">
          <div class="dash-card-title">🌍 Visa Applications</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="background:#e8f5ee;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2d7a4f">42</div><div style="font-size:10px;color:#2d7a4f;margin-top:2px">Approved</div></div>
            <div style="background:#fdf3dc;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#956c10">18</div><div style="font-size:10px;color:#956c10;margin-top:2px">Pending</div></div>
            <div style="background:#fce8e8;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#c0392b">7</div><div style="font-size:10px;color:#c0392b;margin-top:2px">Rejected</div></div>
            <div style="background:#e8f0fb;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2155a3">23</div><div style="font-size:10px;color:#2155a3;margin-top:2px">Under Review</div></div>
          </div>
        </div>
        <div class="dash-card">
          <div class="dash-card-title">🎓 Programs Summary</div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
            <div style="background:#e8f5ee;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2d7a4f"><?= count($courses) ?></div><div style="font-size:10px;color:#2d7a4f;margin-top:2px">Courses</div></div>
            <div style="background:#fdf3dc;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#956c10"><?= count($degrees) ?></div><div style="font-size:10px;color:#956c10;margin-top:2px">Degrees</div></div>
            <div style="background:#e8f0fb;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2155a3">31</div><div style="font-size:10px;color:#2155a3;margin-top:2px">Diplomas</div></div>
          </div>
          <div style="margin-top:12px;padding:10px;background:var(--cream);border-radius:8px;font-size:11px;color:var(--text-mid)">
            <strong><?= count($courses) ?></strong> courses · <strong><?= count($degrees) ?></strong> degrees · <strong><?= count($enrollments) ?></strong> enrollments — live
          </div>
        </div>
      </div>
    </div>

    <!-- ACADEMIC PROGRAMS -->
    <div id="page-academics" class="page">
      <div class="stats-row" style="grid-template-columns:repeat(3,1fr)">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">📚</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($courses) ?></div><div class="stat-label">Total Courses</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">🎓</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($degrees) ?></div><div class="stat-label">Degree Programs</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">📜</div></div><div class="stat-val">31</div><div class="stat-label">Diploma Programs</div></div>
      </div>
      <div class="sub-tabs">
        <div class="sub-tab active" onclick="switchTab('courses',this)">📚 Course Management <span class="tab-count"><?= count($courses) ?></span></div>
        <div class="sub-tab" onclick="switchTab('degrees',this)">🎓 Degree Management <span class="tab-count" id="degree-tab-count"><?= count($degrees) ?></span></div>
        <div class="sub-tab" onclick="switchTab('diplomas',this)">📜 Diploma Management <span class="tab-count">31</span></div>
      </div>

      <!-- COURSES -->
      <div id="subtab-courses" class="sub-panel active">
        <div class="section-header">
          <div><div class="section-title">Course Management</div><div class="section-sub">Live from Firestore</div></div>
          <div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm">⬇ Export</button><button class="btn btn-primary" onclick="openCourseAdd()">＋ Add Course</button></div>
        </div>
        <?php if ($coursesError): ?><div class="error-banner">⚠️ <?= htmlspecialchars($coursesError) ?></div><?php endif; ?>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="chipActive(this)">All</span><div style="margin-left:auto"><button class="btn btn-outline btn-sm">🔍 Filter</button></div></div>
          <div style="overflow-x:auto">
            <table>
              <thead><tr><th>Course Name</th><th>Type</th><th>Description</th><th>Icon</th><th>Actions</th></tr></thead>
              <tbody>
                <?php if (!empty($courses)): ?>
                  <?php foreach ($courses as $c): ?>
                  <tr>
                    <td><div class="cell-with-avatar"><div class="avatar-sm" style="background:#4a7fb5;color:#fff"><?= strtoupper(substr($c['cname'],0,2)) ?></div><div><div style="font-weight:600"><?= htmlspecialchars($c['cname']) ?></div><div class="cell-sub"><?= htmlspecialchars($c['id']) ?></div></div></div></td>
                    <td><span class="badge badge-blue"><?= htmlspecialchars($c['type']) ?></span></td>
                    <td style="max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($c['description']) ?></td>
                    <td><?php if (!empty($c['iconUrl'])): ?><img src="<?= htmlspecialchars($c['iconUrl']) ?>" style="width:32px;height:32px;object-fit:contain;border-radius:4px"><?php else: ?><span class="badge badge-gray">No icon</span><?php endif; ?></td>
                    <td><div class="action-group">
                      <button class="btn btn-outline btn-sm" onclick="openCourseEdit('<?= htmlspecialchars($c['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['cname'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['type'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['description'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['iconUrl'],ENT_QUOTES) ?>')">✏️ Edit</button>
                      <form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete_course"><input type="hidden" name="course_id" value="<?= htmlspecialchars($c['id']) ?>"><button type="submit" class="btn btn-danger btn-sm">🗑</button></form>
                    </div></td>
                  </tr>
                  <?php endforeach; ?>
                <?php else: ?><tr><td colspan="5" style="text-align:center;padding:40px;color:#888">No courses yet.</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
          <div class="pagination"><div class="page-info">Showing <?= count($courses) ?> record<?= count($courses)!==1?'s':'' ?></div></div>
        </div>
      </div>

      <!-- DEGREES -->
      <div id="subtab-degrees" class="sub-panel">
        <div class="section-header">
          <div><div class="section-title">Degree Management</div><div class="section-sub">Live from Firestore — Degree collection</div></div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-outline btn-sm" onclick="window.location.reload()">🔄 Refresh</button>
            <button class="btn btn-primary" onclick="openDegreeAdd()">＋ Add Degree</button>
          </div>
        </div>
        <?php if ($degreesError): ?><div class="error-banner">⚠️ <?= htmlspecialchars($degreesError) ?></div><?php endif; ?>
        <div class="table-wrap">
          <div class="table-toolbar">
            <span class="filter-chip active" onclick="chipActive(this)">All</span>
            <div style="margin-left:auto"><input type="text" class="enroll-search" id="degree-search" placeholder="🔍 Search degrees…" oninput="filterDegrees()" style="width:220px"></div>
          </div>
          <div style="overflow-x:auto">
            <table>
              <thead><tr><th>Degree Name</th><th>Field</th><th>University</th><th>Duration</th><th>Program</th><th>Image</th><th>Actions</th></tr></thead>
              <tbody id="degrees-tbody">
                <?php if (!empty($degrees)): ?>
                  <?php foreach ($degrees as $d): ?>
                  <tr data-search="<?= htmlspecialchars(strtolower(($d['degreeName']??'').' '.($d['field']??'').' '.($d['university']??'').' '.($d['program']??''))) ?>">
                    <td><div class="cell-with-avatar"><div class="avatar-sm" style="background:#8a5fc9;color:#fff"><?= strtoupper(substr($d['degreeName'],0,2)) ?></div><div><div style="font-weight:600"><?= htmlspecialchars($d['degreeName']) ?></div><div class="cell-sub"><?= htmlspecialchars($d['id']) ?></div></div></div></td>
                    <td><?php if (!empty($d['field'])): ?><span class="badge badge-purple"><?= htmlspecialchars($d['field']) ?></span><?php else: ?><span class="badge badge-gray">—</span><?php endif; ?></td>
                    <td><?= htmlspecialchars($d['university'] ?: '—') ?></td>
                    <td><?= htmlspecialchars($d['duration'] ?: '—') ?></td>
                    <td><?php if (!empty($d['program'])): ?><span class="badge badge-teal"><?= htmlspecialchars($d['program']) ?></span><?php else: ?><span class="badge badge-gray">—</span><?php endif; ?></td>
                    <td><?php if (!empty($d['imageUrl'])): ?><img src="<?= htmlspecialchars($d['imageUrl']) ?>" style="width:42px;height:34px;object-fit:cover;border-radius:5px;border:1px solid #eef2ef" onerror="this.outerHTML='<span class=\'badge badge-gray\'>No img</span>'"><?php else: ?><span class="badge badge-gray">No image</span><?php endif; ?></td>
                    <td><div class="action-group">
                      <button class="btn btn-outline btn-sm" onclick="openDegreeEdit('<?= htmlspecialchars($d['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['degreeName'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['field'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['university'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['duration'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['imageUrl'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['program'],ENT_QUOTES) ?>')">✏️ Edit</button>
                      <button class="btn btn-danger btn-sm" onclick="openDegreeDelete('<?= htmlspecialchars($d['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($d['degreeName'],ENT_QUOTES) ?>')">🗑 Delete</button>
                    </div></td>
                  </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <div class="pagination"><div class="page-info" id="degrees-count">Showing <?= count($degrees) ?> record<?= count($degrees)!==1?'s':'' ?></div></div>
        </div>
      </div>

      <!-- DIPLOMAS -->
      <div id="subtab-diplomas" class="sub-panel">
        <div class="section-header"><div><div class="section-title">Diploma Management</div></div><button class="btn btn-primary">＋ Add Diploma</button></div>
        <div style="overflow-x:auto"><table><thead><tr><th>Diploma Program</th><th>Category</th><th>Duration</th><th>Delivery</th><th>Fee</th><th>Coordinator</th><th>Enrolled</th><th>Status</th><th>Actions</th></tr></thead><tbody id="diplomas-tbody"></tbody></table></div>
      </div>
    </div>

    <!-- SCHOLARSHIPS -->
    <div id="page-scholarships" class="page">
      <div class="stats-row" style="grid-template-columns:repeat(3,1fr)">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">🏅</div></div><div class="stat-val">63</div><div class="stat-label">Active Scholarships</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">💰</div></div><div class="stat-val">$2.4M</div><div class="stat-label">Total Awarded</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">⏳</div></div><div class="stat-val">18</div><div class="stat-label">Pending Review</div></div>
      </div>
      <div class="section-header"><div><div class="section-title">Scholarship Management</div></div><button class="btn btn-primary" onclick="openModal('scholarship-add')">＋ Add Scholarship</button></div>
      <div class="table-wrap"><div style="overflow-x:auto"><table><thead><tr><th>Scholarship Name</th><th>Type</th><th>Amount</th><th>Min GPA</th><th>Recipients</th><th>Deadline</th><th>Status</th><th>Actions</th></tr></thead><tbody id="scholarships-tbody"></tbody></table></div></div>
    </div>

    <!-- FEEDBACK -->
    <div id="page-feedback" class="page">
      <div class="stats-row"><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val">94</div><div class="stat-label">Resolved</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div><div class="stat-val">8</div><div class="stat-label">Open</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">🚨</div></div><div class="stat-val">3</div><div class="stat-label">Urgent</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">⭐</div></div><div class="stat-val">4.4</div><div class="stat-label">Avg Rating</div></div></div>
      <div class="section-header"><div><div class="section-title">Feedback Management</div></div><button class="btn btn-primary" onclick="openModal('feedback-add')">＋ Add Feedback</button></div>
      <div class="table-wrap"><div style="overflow-x:auto"><table><thead><tr><th>Submitted By</th><th>Category</th><th>Subject</th><th>Rating</th><th>Date</th><th>Priority</th><th>Status</th><th>Actions</th></tr></thead><tbody id="feedback-tbody"></tbody></table></div></div>
    </div>

    <!-- VISA -->
    <div id="page-visa" class="page">
      <div class="stats-row"><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val">42</div><div class="stat-label">Approved</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">🔄</div></div><div class="stat-val">23</div><div class="stat-label">Under Review</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">❌</div></div><div class="stat-val">7</div><div class="stat-label">Rejected</div></div><div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">📋</div></div><div class="stat-val">18</div><div class="stat-label">Pending Docs</div></div></div>
      <div class="section-header"><div><div class="section-title">Visa Management</div></div><button class="btn btn-primary" onclick="openModal('visa-add')">＋ New Application</button></div>
      <div class="table-wrap"><div style="overflow-x:auto"><table><thead><tr><th>Applicant</th><th>Nationality</th><th>Visa Type</th><th>Destination</th><th>Applied</th><th>Expiry</th><th>Status</th><th>Actions</th></tr></thead><tbody id="visa-tbody"></tbody></table></div></div>
    </div>

    <!-- ENROLLMENT -->
    <div id="page-enrollment" class="page">
      <div class="stats-row" style="grid-template-columns:repeat(4,1fr)">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">👩‍🎓</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($enrollments) ?></div><div class="stat-label">Total Enrolled</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div><div class="stat-val"><?= $statusCounts['Pending'] ?></div><div class="stat-label">Pending</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val"><?= $statusCounts['Approved'] ?></div><div class="stat-label">Approved</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">❌</div></div><div class="stat-val"><?= $statusCounts['Rejected'] ?></div><div class="stat-label">Rejected</div></div>
      </div>
      <div class="section-header">
        <div><div class="section-title">Enrollment Management</div><div class="section-sub">Live from Firestore</div></div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-outline btn-sm" onclick="exportEnrollCSV()">⬇ Export CSV</button>
          <button class="btn btn-outline btn-sm" onclick="window.location.reload()">🔄 Refresh</button>
          <button class="btn btn-primary" onclick="openAddEnrollment()">＋ Add Enrollment</button>
        </div>
      </div>
      <?php if ($enrollmentsError): ?><div class="error-banner">⚠️ <?= htmlspecialchars($enrollmentsError) ?></div><?php endif; ?>
      <div class="table-wrap">
        <div class="table-toolbar">
          <span class="filter-chip active" onclick="enrollFilter('all',this)">All</span>
          <span class="filter-chip" onclick="enrollFilter('Pending',this)">Pending</span>
          <span class="filter-chip" onclick="enrollFilter('Under Review',this)">Under Review</span>
          <span class="filter-chip" onclick="enrollFilter('Approved',this)">Approved</span>
          <span class="filter-chip" onclick="enrollFilter('Rejected',this)">Rejected</span>
          <div style="margin-left:auto"><input id="enroll-search" type="text" class="enroll-search" placeholder="🔍 Search…" oninput="applyEnrollFilters()"></div>
        </div>
        <div style="overflow-x:auto">
          <table><thead><tr><th>Full Name</th><th>Email</th><th>Age</th><th>Location</th><th>Phone</th><th>Course</th><th>Result</th><th>Submitted</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody id="enrollment-tbody">
            <?php if (!empty($enrollments)): ?>
              <?php foreach ($enrollments as $enr): ?>
              <?php $cls=($statusBadge[$enr['status']]??'badge-gray');$ini=strtoupper(mb_substr($enr['fullName'],0,2));$sd=strtolower($enr['fullName'].' '.$enr['email'].' '.$enr['course'].' '.$enr['location'].' '.$enr['phone']); ?>
              <tr data-status="<?= htmlspecialchars($enr['status']) ?>" data-search="<?= htmlspecialchars($sd) ?>">
                <td><div class="cell-with-avatar"><div class="avatar-sm" style="background:#3a9b8c;color:#fff"><?= $ini ?></div><div><div style="font-weight:600"><?= htmlspecialchars($enr['fullName']) ?></div><div class="cell-sub"><?= htmlspecialchars(substr($enr['id'],0,12)) ?>…</div></div></div></td>
                <td style="font-size:12px"><?= htmlspecialchars($enr['email']) ?></td>
                <td><?= htmlspecialchars($enr['age']) ?></td>
                <td><?= htmlspecialchars($enr['location']) ?></td>
                <td style="font-size:12px;white-space:nowrap"><?= htmlspecialchars($enr['phone']) ?></td>
                <td style="max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($enr['course']) ?></td>
                <td><?php if (!empty($enr['result'])): ?><a href="<?= htmlspecialchars($enr['result']) ?>" target="_blank" class="btn btn-outline btn-sm">📄 View</a><?php else: ?><span class="badge badge-gray">None</span><?php endif; ?></td>
                <td style="font-size:11px;color:#888;white-space:nowrap"><?= htmlspecialchars($enr['createdAt']) ?></td>
                <td><span class="badge <?= $cls ?>"><?= htmlspecialchars($enr['status']) ?></span></td>
                <td><div class="action-group">
                  <button class="btn btn-outline btn-sm" onclick="openEnrollmentEdit('<?= htmlspecialchars($enr['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['fullName'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['email'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['age'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['location'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['phone'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['course'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['status'],ENT_QUOTES) ?>','<?= htmlspecialchars($enr['result']??'',ENT_QUOTES) ?>')">✏️ Edit</button>
                  <form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete_enrollment"><input type="hidden" name="enrollment_id" value="<?= htmlspecialchars($enr['id']) ?>"><button type="submit" class="btn btn-danger btn-sm">🗑</button></form>
                </div></td>
              </tr>
              <?php endforeach; ?>
            <?php else: ?><tr><td colspan="10" style="text-align:center;padding:52px;color:#aaa">📭 No enrollments yet.</td></tr><?php endif; ?>
          </tbody></table>
        </div>
        <div class="pagination"><div class="page-info" id="enroll-count"><?= count($enrollments) ?> record<?= count($enrollments)!==1?'s':'' ?> total</div></div>
      </div>
    </div>

    <!-- EMPLOYEES -->
    <div id="page-employees" class="page">
      <div class="stats-row">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">👥</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($firebaseUsers) ?></div><div class="stat-label">Total Users</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">🔑</div></div><div class="stat-val"><?= count($firebaseAdmins) ?></div><div class="stat-label">Admin Accounts</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">👤</div></div><div class="stat-val"><?= count($firebaseRegUsers) ?></div><div class="stat-label">User Accounts</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">✅</div></div><div class="stat-val"><?= count(array_filter($firebaseUsers,fn($u)=>strtolower($u['status']??'')==='active')) ?></div><div class="stat-label">Active</div></div>
      </div>
      <div class="sub-tabs" style="margin-bottom:0">
        <div class="emp-sub-tab active" id="emp-tab-admins" onclick="empTab('admins')">🔑 Admin Accounts <span class="tab-count" style="background:#fdf3dc;color:#956c10"><?= count($firebaseAdmins) ?></span></div>
        <div class="emp-sub-tab" id="emp-tab-users" onclick="empTab('users')">👤 User Accounts <span class="tab-count" style="background:#e8f0fb;color:#2155a3"><?= count($firebaseRegUsers) ?></span></div>
      </div>
      <?php if ($usersError): ?><div class="error-banner" style="margin-top:16px">⚠️ <?= htmlspecialchars($usersError) ?></div><?php endif; ?>
      <div id="emp-panel-admins" style="padding-top:16px">
        <div class="section-header"><div><div class="section-title">Admin Accounts</div><div class="section-sub">Users with admin role</div></div><div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm" onclick="window.location.reload()">🔄 Refresh</button><button class="btn btn-primary" onclick="openAddAccountModal('admin')">＋ Add Admin</button></div></div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="fbEmpChip(this,'admins',null)">All</span><span class="filter-chip" onclick="fbEmpChip(this,'admins','active')">Active</span><span class="filter-chip" onclick="fbEmpChip(this,'admins','inactive')">Inactive</span><div style="margin-left:auto"><input class="enroll-search" id="admin-search" placeholder="🔍 Search…" oninput="fbEmpSearch('admins')" style="width:200px"></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>Name</th><th>Email</th><th>Country</th><th>Telephone</th><th>Age</th><th>Role</th><th>Status</th><th>Joined</th><th>Last Login</th><th>Actions</th></tr></thead>
          <tbody id="tb-firebase-admins">
            <?php foreach ($firebaseAdmins as $u): ?>
            <?php $name=$u['fullName']?:trim($u['firstName'].' '.$u['lastName']);$ini=strtoupper(mb_substr($name,0,2)); ?>
            <tr data-fbstatus="<?= strtolower(htmlspecialchars($u['status'])) ?>" data-fbsearch="<?= strtolower(htmlspecialchars($name.' '.$u['email'].' '.$u['country'])) ?>">
              <td><div class="cell-with-avatar"><div class="avatar-sm" style="background:#c9a84c;color:#1e3a2f"><?= $ini ?></div><div><div style="font-weight:600"><?= htmlspecialchars($name) ?></div><div class="cell-sub"><?= htmlspecialchars(substr($u['id'],0,12)) ?>…</div></div></div></td>
              <td style="font-size:12px"><?= htmlspecialchars($u['email']) ?></td><td><?= htmlspecialchars($u['country']) ?></td>
              <td style="font-size:12px"><?= htmlspecialchars($u['telephone']) ?></td><td><?= htmlspecialchars($u['age']) ?></td>
              <td><span class="badge <?= userRoleClass($u['role']) ?>"><?= htmlspecialchars(ucfirst($u['role'])) ?></span></td>
              <td><span class="badge <?= userStatusClass($u['status']) ?>"><?= htmlspecialchars(ucfirst($u['status'])) ?></span></td>
              <td style="font-size:11px;color:#888"><?= htmlspecialchars($u['createdAt']) ?></td>
              <td style="font-size:11px;color:#888"><?= htmlspecialchars($u['lastLogin']) ?></td>
              <td><div class="action-group"><button class="btn btn-outline btn-sm" onclick="openUserEdit('<?= htmlspecialchars($u['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($name,ENT_QUOTES) ?>','<?= htmlspecialchars($u['role'],ENT_QUOTES) ?>','<?= htmlspecialchars($u['status'],ENT_QUOTES) ?>')">✏️ Edit</button><form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= htmlspecialchars($u['id']) ?>"><button type="submit" class="btn btn-danger btn-sm">🗑</button></form></div></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($firebaseAdmins)): ?><tr><td colspan="10" style="text-align:center;padding:36px;color:#aaa">No admin accounts found.</td></tr><?php endif; ?>
          </tbody></table></div>
          <div class="pagination"><div class="page-info" id="pi-firebase-admins"><?= count($firebaseAdmins) ?> record<?= count($firebaseAdmins)!==1?'s':'' ?></div></div>
        </div>
      </div>
      <div id="emp-panel-users" style="display:none;padding-top:16px">
        <div class="section-header"><div><div class="section-title">User Accounts</div><div class="section-sub">Registered via portal</div></div><div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm" onclick="window.location.reload()">🔄 Refresh</button><button class="btn btn-primary" onclick="openAddAccountModal('user')">＋ Add User</button></div></div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="fbEmpChip(this,'users',null)">All</span><span class="filter-chip" onclick="fbEmpChip(this,'users','active')">Active</span><span class="filter-chip" onclick="fbEmpChip(this,'users','inactive')">Inactive</span><span class="filter-chip" onclick="fbEmpChip(this,'users','suspended')">Suspended</span><div style="margin-left:auto"><input class="enroll-search" id="user-search" placeholder="🔍 Search…" oninput="fbEmpSearch('users')" style="width:220px"></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>User</th><th>First Name</th><th>Last Name</th><th>DOB</th><th>Email</th><th>Telephone</th><th>Country</th><th>Age</th><th>Role</th><th>Status</th><th>Joined</th><th>Last Login</th><th>Actions</th></tr></thead>
          <tbody id="tb-firebase-users">
            <?php foreach ($firebaseRegUsers as $u): ?>
            <?php $name=$u['fullName']?:trim($u['firstName'].' '.$u['lastName']);$ini=strtoupper(mb_substr($name,0,2)); ?>
            <tr data-fbstatus="<?= strtolower(htmlspecialchars($u['status'])) ?>" data-fbsearch="<?= strtolower(htmlspecialchars($name.' '.$u['email'].' '.$u['country'].' '.$u['telephone'])) ?>">
              <td><div class="cell-with-avatar"><div class="avatar-sm" style="background:#3a9b8c;color:#fff"><?= $ini ?></div><div class="cell-sub"><?= htmlspecialchars(substr($u['id'],0,10)) ?>…</div></div></td>
              <td style="font-weight:600"><?= htmlspecialchars($u['firstName']) ?></td><td style="font-weight:600"><?= htmlspecialchars($u['lastName']) ?></td>
              <td style="font-size:11px;color:#888"><?= htmlspecialchars($u['dob']) ?></td><td style="font-size:12px"><?= htmlspecialchars($u['email']) ?></td>
              <td style="font-size:12px;white-space:nowrap"><?= htmlspecialchars($u['telephone']) ?></td><td><?= htmlspecialchars($u['country']) ?></td><td><?= htmlspecialchars($u['age']) ?></td>
              <td><span class="badge <?= userRoleClass($u['role']) ?>"><?= htmlspecialchars(ucfirst($u['role'])) ?></span></td>
              <td><span class="badge <?= userStatusClass($u['status']) ?>"><?= htmlspecialchars(ucfirst($u['status'])) ?></span></td>
              <td style="font-size:11px;color:#888"><?= htmlspecialchars($u['createdAt']) ?></td><td style="font-size:11px;color:#888"><?= htmlspecialchars($u['lastLogin']) ?></td>
              <td><div class="action-group"><button class="btn btn-outline btn-sm" onclick="openUserEdit('<?= htmlspecialchars($u['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($name,ENT_QUOTES) ?>','<?= htmlspecialchars($u['role'],ENT_QUOTES) ?>','<?= htmlspecialchars($u['status'],ENT_QUOTES) ?>')">✏️ Edit</button><form method="POST" style="display:inline" onsubmit="return confirm('Delete?')"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= htmlspecialchars($u['id']) ?>"><button type="submit" class="btn btn-danger btn-sm">🗑</button></form></div></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($firebaseRegUsers)): ?><tr><td colspan="13" style="text-align:center;padding:36px;color:#aaa">No registered users yet.</td></tr><?php endif; ?>
          </tbody></table></div>
          <div class="pagination"><div class="page-info" id="pi-firebase-users"><?= count($firebaseRegUsers) ?> user<?= count($firebaseRegUsers)!==1?'s':'' ?></div></div>
        </div>
      </div>
    </div>

  </div>
</div>
</div>

<!-- ══ DEGREE ADD / EDIT MODAL ══ -->
<div class="modal-overlay" id="degree-form-overlay" onclick="if(event.target===this)closeDegreeForm()">
  <div class="modal" style="width:540px">
    <div class="modal-header"><div class="modal-title" id="degree-form-title">Add New Degree</div><button class="close-btn" onclick="closeDegreeForm()">✕</button></div>
    <form method="POST" id="degree-php-form">
      <div style="padding:24px">
        <input type="hidden" name="action" id="df-action" value="add_degree">
        <input type="hidden" name="degree_id" id="df-degree-id" value="">
        <div class="form-grid">
          <div class="form-group full"><label>Degree ID <span style="color:var(--red)">*</span></label><input type="text" id="df-id-display" placeholder="e.g. DEG010" required><small style="color:#999;font-size:11px;margin-top:3px;display:block">Unique Firestore document ID — cannot be changed after creation.</small></div>
          <div class="form-group full"><label>Degree Name <span style="color:var(--red)">*</span></label><input type="text" name="degreeName" id="df-degreeName" placeholder="e.g. BSc Computer Science" required></div>
          <div class="form-group"><label>Field</label><input type="text" name="field" id="df-field" placeholder="e.g. Technology, Business"></div>
          <div class="form-group"><label>University</label><input type="text" name="university" id="df-university" placeholder="e.g. University of London"></div>
          <div class="form-group"><label>Duration</label><input type="text" name="duration" id="df-duration" placeholder="e.g. 3 Years"></div>
          <div class="form-group"><label>Program</label><input type="text" name="program" id="df-program" placeholder="e.g. Bachelor's, Master's, PhD"></div>
          <div class="form-group full"><label>Image URL</label><input type="url" name="imageUrl" id="df-imageUrl" placeholder="https://example.com/image.jpg"><small style="color:#999;font-size:11px;margin-top:3px;display:block">Optional — shown on the student-facing degree page.</small></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeDegreeForm()">Cancel</button><button type="submit" class="btn btn-primary" id="df-submit-btn">Save Degree</button></div>
    </form>
  </div>
</div>

<!-- ══ DEGREE DELETE CONFIRM ══ -->
<div id="deg-del-overlay" onclick="if(event.target===this)closeDegreeDelete()">
  <div class="modal" style="width:360px;text-align:center;padding:32px 28px">
    <div style="font-size:44px;margin-bottom:12px">🗑️</div>
    <div class="modal-title" style="margin-bottom:8px">Delete Degree?</div>
    <div style="font-size:12px;color:var(--text-mid);margin:8px 0 22px" id="deg-del-msg">This cannot be undone.</div>
    <form method="POST">
      <input type="hidden" name="action" value="delete_degree">
      <input type="hidden" name="degree_id" id="deg-del-id" value="">
      <div style="display:flex;gap:10px;justify-content:center"><button type="button" class="btn btn-outline" onclick="closeDegreeDelete()">Cancel</button><button type="submit" class="btn btn-danger">Yes, Delete</button></div>
    </form>
  </div>
</div>

<!-- ══ COURSE ADD/EDIT MODAL ══ -->
<div class="modal-overlay" id="course-form-overlay" onclick="if(event.target===this)closeCourseForm()">
  <div class="modal">
    <div class="modal-header"><div class="modal-title" id="course-form-title">Add New Course</div><button class="close-btn" onclick="closeCourseForm()">✕</button></div>
    <form method="POST" id="course-php-form">
      <div style="padding:24px">
        <input type="hidden" name="action" id="cf-action" value="add_course">
        <input type="hidden" name="course_id" id="cf-course-id" value="">
        <div class="form-grid">
          <div class="form-group full"><label>Course ID *</label><input type="text" id="cf-id-display" placeholder="e.g. CRS001" required><small style="color:#999;font-size:11px;margin-top:3px;display:block">Unique Firestore ID — cannot change after creation.</small></div>
          <div class="form-group full"><label>Course Name *</label><input type="text" name="cname" id="cf-cname" required></div>
          <div class="form-group full"><label>Type *</label><input type="text" name="type" id="cf-type" required></div>
          <div class="form-group full"><label>Description</label><textarea name="description" id="cf-description" rows="3"></textarea></div>
          <div class="form-group full"><label>Icon URL</label><input type="url" name="iconUrl" id="cf-iconUrl"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeCourseForm()">Cancel</button><button type="submit" class="btn btn-primary" id="cf-submit-btn">Save Course</button></div>
    </form>
  </div>
</div>

<!-- ══ ENROLLMENT EDIT MODAL ══ -->
<div class="modal-overlay" id="enrollment-form-overlay" onclick="if(event.target===this)closeEnrollmentForm()">
  <div class="modal">
    <div class="modal-header"><div class="modal-title">Edit Enrollment</div><button class="close-btn" onclick="closeEnrollmentForm()">✕</button></div>
    <form method="POST">
      <div style="padding:24px">
        <input type="hidden" name="action" value="update_enrollment">
        <input type="hidden" name="enrollment_id" id="ef-id">
        <div class="form-grid">
          <div class="form-group full"><label>Full Name *</label><input type="text" name="fullName" id="ef-fullName" required></div>
          <div class="form-group"><label>Email *</label><input type="email" name="email" id="ef-email" required></div>
          <div class="form-group"><label>Age</label><input type="number" name="age" id="ef-age" min="10" max="99"></div>
          <div class="form-group"><label>Location</label><input type="text" name="location" id="ef-location"></div>
          <div class="form-group"><label>Phone</label><input type="text" name="phone" id="ef-phone"></div>
          <div class="form-group full"><label>Course</label><input type="text" name="course" id="ef-course"></div>
          <div class="form-group full"><label>Status</label><select name="status" id="ef-status"><option value="Pending">⏳ Pending</option><option value="Under Review">🔄 Under Review</option><option value="Approved">✅ Approved</option><option value="Rejected">❌ Rejected</option></select></div>
          <div class="form-group full"><label>Result Sheet URL</label><input type="text" name="result" id="ef-result"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeEnrollmentForm()">Cancel</button><button type="submit" class="btn btn-primary">Update Enrollment</button></div>
    </form>
  </div>
</div>

<!-- ══ ADD ENROLLMENT MODAL ══ -->
<div class="modal-overlay" id="add-enrollment-overlay" onclick="if(event.target===this)closeAddEnrollment()">
  <div class="modal">
    <div class="modal-header"><div class="modal-title">＋ Add Enrollment</div><button class="close-btn" onclick="closeAddEnrollment()">✕</button></div>
    <form method="POST" id="add-enrollment-form" onsubmit="return validateAddEnrollment()">
      <div style="padding:24px">
        <input type="hidden" name="action" value="add_enrollment">
        <div class="form-grid">
          <div class="form-group full"><label>Full Name *</label><input type="text" name="fullName" id="ae-fullName" placeholder="e.g. John Silva"><span class="ae-field-error" id="ae-err-fullName"></span></div>
          <div class="form-group"><label>Email *</label><input type="email" name="email" id="ae-email"><span class="ae-field-error" id="ae-err-email"></span></div>
          <div class="form-group"><label>Age *</label><input type="number" name="age" id="ae-age" min="10" max="99"><span class="ae-field-error" id="ae-err-age"></span></div>
          <div class="form-group"><label>Location *</label><input type="text" name="location" id="ae-location"><span class="ae-field-error" id="ae-err-location"></span></div>
          <div class="form-group"><label>Phone *</label><input type="text" name="phone" id="ae-phone"><span class="ae-field-error" id="ae-err-phone"></span></div>
          <div class="form-group full"><label>Course *</label><input type="text" name="course" id="ae-course" placeholder="e.g. Bachelor of Computer Science"><span class="ae-field-error" id="ae-err-course"></span></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeAddEnrollment()">Cancel</button><button type="submit" class="btn btn-primary">Save Enrollment</button></div>
    </form>
  </div>
</div>

<!-- ══ ADD ACCOUNT MODAL ══ -->
<div class="modal-overlay" id="add-account-overlay" onclick="if(event.target===this)closeAddAccountModal()">
  <div class="modal" style="width:520px">
    <div class="modal-header"><div class="modal-title" id="aa-title">Add Admin Account</div><button class="close-btn" onclick="closeAddAccountModal()">✕</button></div>
    <div style="padding:20px 24px 0">
      <div id="aa-alert" style="display:none;padding:10px 13px;border-radius:8px;font-size:12px;line-height:1.5;margin-bottom:14px"></div>
      <div class="form-grid">
        <div class="form-group"><label>First Name *</label><input type="text" id="aa-fname"></div>
        <div class="form-group"><label>Last Name *</label><input type="text" id="aa-lname"></div>
        <div class="form-group full"><label>Email *</label><input type="email" id="aa-email"></div>
        <div class="form-group" id="aa-dob-wrap"><label>Date of Birth</label><input type="date" id="aa-dob"></div>
        <div class="form-group" id="aa-tel-wrap"><label>Telephone</label><input type="text" id="aa-tel"></div>
        <div class="form-group full" id="aa-country-wrap"><label>Country</label><input type="text" id="aa-country"></div>
        <div class="form-group full">
          <label>Password * <span id="aa-pwd-strength" style="font-size:10.5px"></span></label>
          <div style="position:relative"><input type="password" id="aa-pwd" style="padding-right:38px" oninput="aaPwdStrength()"><button type="button" onclick="aaTogglePwd('aa-pwd',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#8aa898;font-size:13px">👁</button></div>
        </div>
        <div class="form-group full">
          <label>Confirm Password *</label>
          <div style="position:relative"><input type="password" id="aa-pwd2" style="padding-right:38px"><button type="button" onclick="aaTogglePwd('aa-pwd2',this)" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:#8aa898;font-size:13px">👁</button></div>
        </div>
        <div class="form-group full" id="aa-role-wrap"><label>Role</label><select id="aa-role"><option value="admin">Admin — can log in to dashboard</option><option value="staff">Staff — portal access only</option></select></div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-outline" onclick="closeAddAccountModal()">Cancel</button>
      <button type="button" class="btn btn-primary" id="aa-save-btn" onclick="saveNewAccount()">
        <span id="aa-spinner" style="display:none;width:13px;height:13px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:smSpin .7s linear infinite;vertical-align:middle;margin-right:4px"></span>
        <span id="aa-save-label">Create Account</span>
      </button>
    </div>
  </div>
</div>

<!-- ══ USER EDIT MODAL ══ -->
<div class="modal-overlay" id="user-edit-overlay" onclick="if(event.target===this)closeUserEdit()">
  <div class="modal" style="width:420px">
    <div class="modal-header"><div class="modal-title" id="ue-title">Edit User</div><button class="close-btn" onclick="closeUserEdit()">✕</button></div>
    <form method="POST"><div style="padding:24px">
      <input type="hidden" name="action" value="update_user"><input type="hidden" name="user_id" id="ue-id">
      <div class="form-grid">
        <div class="form-group full"><label>Role</label><select name="role" id="ue-role"><option value="user">User</option><option value="staff">Staff</option><option value="admin">Admin</option></select></div>
        <div class="form-group full"><label>Status</label><select name="status" id="ue-status"><option value="active">✅ Active</option><option value="inactive">⏸ Inactive</option><option value="suspended">🚫 Suspended</option></select></div>
      </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeUserEdit()">Cancel</button><button type="submit" class="btn btn-primary">Save Changes</button></div>
    </form>
  </div>
</div>

<!-- ══ GENERAL MODAL ══ -->
<div class="modal-overlay" id="modal-overlay" onclick="if(event.target===this)closeModal()">
  <div class="modal" id="modal-box"><div class="modal-header"><div class="modal-title" id="modal-title">Record</div><button class="close-btn" onclick="closeModal()">✕</button></div><div id="modal-body"></div></div>
</div>

<!-- ══ CONFIRM DELETE ══ -->
<div class="modal-overlay" id="confirm-overlay" onclick="if(event.target===this)closeConfirm()">
  <div class="modal" style="width:340px;text-align:center;padding:32px 26px">
    <div style="font-size:44px;margin-bottom:12px">🗑️</div>
    <div class="modal-title" style="margin-bottom:8px">Delete Record?</div>
    <div style="font-size:12px;color:var(--text-mid);margin:8px 0 20px" id="confirm-msg">This cannot be undone.</div>
    <div style="display:flex;gap:10px;justify-content:center"><button class="btn btn-outline" onclick="closeConfirm()">Cancel</button><button class="btn btn-danger" id="confirm-yes-btn">Yes, Delete</button></div>
  </div>
</div>

<form id="signout-form" method="POST" action="signout.php" style="display:none"></form>
<div id="toast">✓ <span id="toast-msg">Done</span></div>

<script src="right.js"></script>
<script>
/* ════ SIGN OUT ════ */
function signOut() {
  if (confirm('Sign out of the admin dashboard?')) document.getElementById('signout-form').submit();
}
function dismissTempBanner() {
  const b = document.getElementById('temp-admin-banner');
  if (b) { b.style.display='none'; document.body.classList.remove('has-temp-banner'); }
}
function openSetupModal() { openAddAccountModal('admin'); }

/* ════ DEGREE MODAL ════ */
document.getElementById('degree-php-form').addEventListener('submit', function() {
  if (document.getElementById('df-action').value === 'add_degree') {
    document.getElementById('df-degree-id').value = document.getElementById('df-id-display').value.trim();
  }
});
function openDegreeAdd() {
  document.getElementById('degree-form-title').textContent = 'Add New Degree';
  document.getElementById('df-action').value    = 'add_degree';
  document.getElementById('df-degree-id').value = '';
  document.getElementById('df-id-display').value = '';
  document.getElementById('df-id-display').readOnly = false;
  document.getElementById('df-id-display').style.background = '';
  ['df-degreeName','df-field','df-university','df-duration','df-imageUrl','df-program'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('df-submit-btn').textContent = 'Save Degree';
  document.getElementById('degree-form-overlay').classList.add('open');
}
function openDegreeEdit(id,degreeName,field,university,duration,imageUrl,program) {
  document.getElementById('degree-form-title').textContent = 'Edit Degree';
  document.getElementById('df-action').value    = 'update_degree';
  document.getElementById('df-degree-id').value = id;
  document.getElementById('df-id-display').value = id;
  document.getElementById('df-id-display').readOnly = true;
  document.getElementById('df-id-display').style.background = '#f0f0f0';
  document.getElementById('df-degreeName').value = degreeName;
  document.getElementById('df-field').value      = field;
  document.getElementById('df-university').value = university;
  document.getElementById('df-duration').value   = duration;
  document.getElementById('df-imageUrl').value   = imageUrl;
  document.getElementById('df-program').value    = program;
  document.getElementById('df-submit-btn').textContent = 'Update Degree';
  document.getElementById('degree-form-overlay').classList.add('open');
}
function closeDegreeForm() { document.getElementById('degree-form-overlay').classList.remove('open'); }
function openDegreeDelete(id,name) {
  document.getElementById('deg-del-id').value = id;
  document.getElementById('deg-del-msg').textContent = 'Permanently delete "'+name+'"? This cannot be undone.';
  document.getElementById('deg-del-overlay').classList.add('open');
}
function closeDegreeDelete() { document.getElementById('deg-del-overlay').classList.remove('open'); }
function filterDegrees() {
  const q=(document.getElementById('degree-search')?.value||'').toLowerCase().trim();
  let shown=0;
  document.querySelectorAll('#degrees-tbody tr[data-search]').forEach(row=>{
    const ok=!q||(row.dataset.search||'').includes(q);
    row.classList.toggle('row-hidden',!ok);if(ok)shown++;
  });
  const c=document.getElementById('degrees-count');
  if(c)c.textContent='Showing '+shown+' record'+(shown!==1?'s':'');
}

/* ════ COURSE MODAL ════ */
function openCourseAdd() {
  document.getElementById('course-form-title').textContent = 'Add New Course';
  document.getElementById('cf-action').value = 'add_course';
  document.getElementById('cf-course-id').value = '';
  document.getElementById('cf-id-display').value = '';
  document.getElementById('cf-id-display').readOnly = false;
  document.getElementById('cf-id-display').style.background = '';
  ['cf-cname','cf-type','cf-description','cf-iconUrl'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('cf-submit-btn').textContent = 'Save Course';
  document.getElementById('course-php-form').onsubmit = function() {
    document.getElementById('cf-course-id').value = document.getElementById('cf-id-display').value.trim();
    return true;
  };
  document.getElementById('course-form-overlay').classList.add('open');
}
function openCourseEdit(id,cname,type,description,iconUrl) {
  document.getElementById('course-form-title').textContent = 'Edit Course';
  document.getElementById('cf-action').value = 'update_course';
  document.getElementById('cf-course-id').value = id;
  document.getElementById('cf-id-display').value = id;
  document.getElementById('cf-id-display').readOnly = true;
  document.getElementById('cf-id-display').style.background = '#f0f0f0';
  document.getElementById('cf-cname').value = cname;
  document.getElementById('cf-type').value  = type;
  document.getElementById('cf-description').value = description;
  document.getElementById('cf-iconUrl').value = iconUrl;
  document.getElementById('cf-submit-btn').textContent = 'Update Course';
  document.getElementById('course-php-form').onsubmit = null;
  document.getElementById('course-form-overlay').classList.add('open');
}
function closeCourseForm() { document.getElementById('course-form-overlay').classList.remove('open'); }

/* ════ ENROLLMENT MODALS ════ */
function openEnrollmentEdit(id,fullName,email,age,location,phone,course,status,result) {
  document.getElementById('ef-id').value=id;document.getElementById('ef-fullName').value=fullName;
  document.getElementById('ef-email').value=email;document.getElementById('ef-age').value=age;
  document.getElementById('ef-location').value=location;document.getElementById('ef-phone').value=phone;
  document.getElementById('ef-course').value=course;document.getElementById('ef-result').value=result||'';
  const sel=document.getElementById('ef-status');
  for(let i=0;i<sel.options.length;i++){if(sel.options[i].value===status){sel.selectedIndex=i;break;}}
  document.getElementById('enrollment-form-overlay').classList.add('open');
}
function closeEnrollmentForm() { document.getElementById('enrollment-form-overlay').classList.remove('open'); }
function openAddEnrollment() {
  ['ae-fullName','ae-email','ae-age','ae-location','ae-phone','ae-course'].forEach(id=>{
    const el=document.getElementById(id);if(el){el.value='';el.classList.remove('ae-invalid');}
  });
  ['ae-err-fullName','ae-err-email','ae-err-age','ae-err-location','ae-err-phone','ae-err-course'].forEach(id=>{
    const el=document.getElementById(id);if(el)el.textContent='';
  });
  document.getElementById('add-enrollment-overlay').classList.add('open');
}
function closeAddEnrollment() { document.getElementById('add-enrollment-overlay').classList.remove('open'); }
function validateAddEnrollment() {
  let ok=true;
  [{id:'ae-fullName',err:'ae-err-fullName',msg:'Full name required.'},
   {id:'ae-email',err:'ae-err-email',msg:'Valid email required.',extra:v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)},
   {id:'ae-age',err:'ae-err-age',msg:'Age 10–99.',extra:v=>+v>=10&&+v<=99},
   {id:'ae-location',err:'ae-err-location',msg:'Location required.'},
   {id:'ae-phone',err:'ae-err-phone',msg:'Phone required.'},
   {id:'ae-course',err:'ae-err-course',msg:'Course required.'},
  ].forEach(r=>{
    const el=document.getElementById(r.id),err=document.getElementById(r.err);if(!el||!err)return;
    const val=el.value.trim(),pass=val!==''&&(!r.extra||r.extra(val));
    el.classList.toggle('ae-invalid',!pass);err.textContent=pass?'':r.msg;if(!pass)ok=false;
  });
  return ok;
}

/* ════ ENROLLMENT FILTERS ════ */
let _enrollStatus='all';
function enrollFilter(status,el){
  _enrollStatus=status;
  el.closest('.table-toolbar').querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
  el.classList.add('active');applyEnrollFilters();
}
function applyEnrollFilters(){
  const q=(document.getElementById('enroll-search')?.value||'').toLowerCase().trim();
  let shown=0;
  document.querySelectorAll('#enrollment-tbody tr[data-status]').forEach(row=>{
    const ok=(_enrollStatus==='all'||row.dataset.status===_enrollStatus)&&(!q||(row.dataset.search||'').includes(q));
    row.classList.toggle('row-hidden',!ok);if(ok)shown++;
  });
  const c=document.getElementById('enroll-count');
  if(c)c.textContent=shown+' record'+(shown!==1?'s':'')+' shown';
}

/* ════ CSV EXPORT ════ */
function exportEnrollCSV(){
  const headers=['Full Name','Email','Age','Location','Phone','Course','Result','Submitted','Status'];
  const rows=[];
  document.querySelectorAll('#enrollment-tbody tr[data-status]:not(.row-hidden)').forEach(row=>{
    const td=row.querySelectorAll('td');if(td.length<9)return;
    rows.push([
      td[0]?.querySelector('[style*="font-weight"]')?.textContent?.trim()||'',
      td[1]?.textContent?.trim()||'',td[2]?.textContent?.trim()||'',
      td[3]?.textContent?.trim()||'',td[4]?.textContent?.trim()||'',
      td[5]?.textContent?.trim()||'',
      td[6]?.querySelector('a')?.href||td[6]?.textContent?.trim()||'',
      td[7]?.textContent?.trim()||'',td[8]?.textContent?.trim()||''
    ].map(v=>`"${v.replace(/"/g,'""')}"`).join(','));
  });
  const url=URL.createObjectURL(new Blob([[headers.join(','),...rows].join('\n')],{type:'text/csv'}));
  Object.assign(document.createElement('a'),{href:url,download:'enrollments_'+new Date().toISOString().slice(0,10)+'.csv'}).click();
  URL.revokeObjectURL(url);
}

/* ════ ADD ACCOUNT MODAL ════ */
let _aaMode='admin';
function openAddAccountModal(mode){
  _aaMode=mode;const isUser=mode==='user';
  document.getElementById('aa-title').textContent=isUser?'＋ Add User Account':'＋ Add Admin Account';
  ['aa-dob-wrap','aa-tel-wrap','aa-country-wrap'].forEach(id=>{document.getElementById(id).style.display=isUser?'flex':'none';});
  document.getElementById('aa-role-wrap').style.display=isUser?'none':'flex';
  ['aa-fname','aa-lname','aa-email','aa-dob','aa-tel','aa-country','aa-pwd','aa-pwd2'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  document.getElementById('aa-pwd-strength').textContent='';
  document.getElementById('aa-alert').style.display='none';
  document.getElementById('aa-save-label').textContent=isUser?'Create User':'Create Admin';
  document.getElementById('aa-save-btn').disabled=false;
  document.getElementById('aa-spinner').style.display='none';
  document.getElementById('add-account-overlay').classList.add('open');
}
function closeAddAccountModal(){ document.getElementById('add-account-overlay').classList.remove('open'); }
function aaTogglePwd(id,btn){const el=document.getElementById(id);el.type=el.type==='password'?'text':'password';btn.textContent=el.type==='password'?'👁':'🙈';}
function aaPwdStrength(){
  const pwd=document.getElementById('aa-pwd').value,el=document.getElementById('aa-pwd-strength');
  if(!pwd){el.textContent='';return;}
  let s=0;if(pwd.length>=8)s++;if(/[A-Z]/.test(pwd))s++;if(/[0-9]/.test(pwd))s++;if(/[^A-Za-z0-9]/.test(pwd))s++;
  const lbl=['','— Weak','— Fair','— Good','— Strong'],col=['','#e05c5c','#c9a84c','#4a7fb5','#2d7a4f'];
  el.textContent=lbl[s]||'';el.style.color=col[s]||'';
}
function aaSetAlert(msg,ok){
  const el=document.getElementById('aa-alert');el.textContent=msg;el.style.display='block';
  el.style.background=ok?'#eafaf1':'#fdf0f0';el.style.border=ok?'1px solid #a9dfbf':'1px solid #f5c6c6';
  el.style.color=ok?'#1e8449':'#922b21';
}
async function saveNewAccount(){
  const fname=document.getElementById('aa-fname').value.trim(),lname=document.getElementById('aa-lname').value.trim();
  const email=document.getElementById('aa-email').value.trim(),pwd=document.getElementById('aa-pwd').value,pwd2=document.getElementById('aa-pwd2').value;
  const dob=document.getElementById('aa-dob')?.value||'',tel=document.getElementById('aa-tel')?.value.trim()||'',country=document.getElementById('aa-country')?.value.trim()||'';
  const role=_aaMode==='admin'?(document.getElementById('aa-role')?.value||'admin'):'user';
  if(!fname||!lname) return aaSetAlert('First and last name are required.',false);
  if(!/\S+@\S+\.\S+/.test(email)) return aaSetAlert('Please enter a valid email address.',false);
  if(pwd.length<8) return aaSetAlert('Password must be at least 8 characters.',false);
  if(!/[A-Z]/.test(pwd)) return aaSetAlert('Password needs at least one uppercase letter.',false);
  if(!/[0-9]/.test(pwd)) return aaSetAlert('Password needs at least one number.',false);
  if(pwd!==pwd2) return aaSetAlert('Passwords do not match.',false);
  const btn=document.getElementById('aa-save-btn'),spin=document.getElementById('aa-spinner'),label=document.getElementById('aa-save-label');
  btn.disabled=true;spin.style.display='inline-block';label.textContent='Creating…';
  document.getElementById('aa-alert').style.display='none';
  try {
    /* ── FIXED: simple relative path — no more 404 ── */
    const setupUrl = 'admin_setup.php';
    const fd=new FormData();
    fd.append('action','add_account');fd.append('firstName',fname);fd.append('lastName',lname);
    fd.append('email',email);fd.append('password',pwd);fd.append('role',role);
    fd.append('dob',dob);fd.append('telephone',tel);fd.append('country',country);
    const res=await fetch(setupUrl,{method:'POST',body:fd});
    const rawText=await res.text();let data;
    try{data=JSON.parse(rawText);}catch(e){aaSetAlert('PHP error: '+rawText.slice(0,200),false);btn.disabled=false;spin.style.display='none';label.textContent=_aaMode==='admin'?'Create Admin':'Create User';return;}
    if(data.success){aaSetAlert('✓ '+data.message,true);label.textContent='Created ✓';setTimeout(()=>{closeAddAccountModal();window.location.reload();},2000);}
    else{aaSetAlert(data.message||'Something went wrong.',false);btn.disabled=false;spin.style.display='none';label.textContent=_aaMode==='admin'?'Create Admin':'Create User';}
  }catch(err){aaSetAlert('Unexpected error: '+err.message,false);btn.disabled=false;spin.style.display='none';label.textContent=_aaMode==='admin'?'Create Admin':'Create User';}
}

/* ════ USER EDIT ════ */
function openUserEdit(id,name,role,status){
  document.getElementById('ue-id').value=id;document.getElementById('ue-title').textContent='Edit — '+name;
  const r=document.getElementById('ue-role');for(let i=0;i<r.options.length;i++)if(r.options[i].value===role){r.selectedIndex=i;break;}
  const s=document.getElementById('ue-status');for(let i=0;i<s.options.length;i++)if(s.options[i].value===status){s.selectedIndex=i;break;}
  document.getElementById('user-edit-overlay').classList.add('open');
}
function closeUserEdit(){document.getElementById('user-edit-overlay').classList.remove('open');}

/* ════ EMPLOYEE TABS ════ */
function empTab(tab){
  ['admins','users'].forEach(t=>{
    document.getElementById('emp-panel-'+t).style.display=(t===tab)?'block':'none';
    document.getElementById('emp-tab-'+t).classList.toggle('active',t===tab);
  });
}

/* ════ FIREBASE EMPLOYEE FILTER ════ */
function fbEmpChip(el,panel,val){
  el.closest('.table-toolbar').querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));el.classList.add('active');
  const tbody=document.getElementById('tb-firebase-'+panel);if(!tbody)return;let shown=0;
  tbody.querySelectorAll('tr[data-fbstatus]').forEach(row=>{const ok=!val||row.dataset.fbstatus===val;row.classList.toggle('row-hidden',!ok);if(ok)shown++;});
  const pi=document.getElementById('pi-firebase-'+panel);if(pi)pi.textContent=shown+' record'+(shown!==1?'s':'');
}
function fbEmpSearch(panel){
  const q=(document.getElementById(panel==='admins'?'admin-search':'user-search')?.value||'').toLowerCase().trim();
  const tbody=document.getElementById('tb-firebase-'+panel);if(!tbody)return;let shown=0;
  tbody.querySelectorAll('tr[data-fbsearch]').forEach(row=>{const ok=!q||(row.dataset.fbsearch||'').includes(q);row.classList.toggle('row-hidden',!ok);if(ok)shown++;});
  const pi=document.getElementById('pi-firebase-'+panel);if(pi)pi.textContent=shown+' record'+(shown!==1?'s':'');
}

/* ════ MISC ════ */
function chipActive(el){el.closest('.table-toolbar').querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));el.classList.add('active');}
function closeModal(){document.getElementById('modal-overlay').classList.remove('open');}
function closeConfirm(){document.getElementById('confirm-overlay').classList.remove('open');}

document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    closeDegreeForm();closeDegreeDelete();closeCourseForm();closeEnrollmentForm();
    closeAddEnrollment();closeUserEdit();closeModal();closeConfirm();
    document.getElementById('add-account-overlay').classList.remove('open');
  }
});
</script>
</body>
</html>
