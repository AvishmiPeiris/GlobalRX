<?php
require_once 'config.php';

class CourseManager {
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    public function __construct() {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/courses";
    }

    private function request(string $method, string $url, ?array $body = null): array {
        $url .= (str_contains($url, '?') ? '&' : '?') . "key={$this->apiKey}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? 'Unknown Firestore error';
            return ['success' => false, 'message' => "Firestore error: $msg"];
        }
        return ['success' => true, 'data' => $data];
    }

    private function parseDoc(array $doc): array {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');
        return [
            'id'          => $id,
            'cname'       => $fields['cname']['stringValue']       ?? '',
            'type'        => $fields['type']['stringValue']         ?? '',
            'description' => $fields['description']['stringValue']  ?? '',
            'iconUrl'     => $fields['iconUrl']['stringValue']      ?? '',
        ];
    }

    private function buildDoc(string $cname, string $type, string $description, string $iconUrl): array {
        return [
            'fields' => [
                'cname'       => ['stringValue' => $cname],
                'type'        => ['stringValue' => $type],
                'description' => ['stringValue' => $description],
                'iconUrl'     => ['stringValue' => $iconUrl],
            ]
        ];
    }

    public function getAllCourses(): array {
        $result = $this->request('GET', $this->baseUrl);
        if (!$result['success']) return $result;
        $courses = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $courses[] = $this->parseDoc($doc);
        }
        return ['success' => true, 'courses' => $courses];
    }

    public function getCourse(string $courseId): array {
        $result = $this->request('GET', "{$this->baseUrl}/{$courseId}");
        if (!$result['success']) return $result;
        return ['success' => true, 'course' => $this->parseDoc($result['data'])];
    }

    public function addCourse(string $courseId, string $cname, string $type, string $description, string $iconUrl = ''): array {
        if (empty($courseId) || empty($cname) || empty($type)) {
            return ['success' => false, 'message' => 'Course ID, name, and type are required.'];
        }
        $url    = $this->baseUrl . '?documentId=' . urlencode($courseId);
        $result = $this->request('POST', $url, $this->buildDoc($cname, $type, $description, $iconUrl));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Course '{$cname}' added successfully."];
    }

    public function updateCourse(string $courseId, string $cname, string $type, string $description, string $iconUrl = ''): array {
        if (empty($courseId) || empty($cname) || empty($type)) {
            return ['success' => false, 'message' => 'Course ID, name, and type are required.'];
        }
        $mask   = 'updateMask.fieldPaths=cname&updateMask.fieldPaths=type&updateMask.fieldPaths=description&updateMask.fieldPaths=iconUrl';
        $url    = "{$this->baseUrl}/{$courseId}?{$mask}";
        $result = $this->request('PATCH', $url, $this->buildDoc($cname, $type, $description, $iconUrl));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Course '{$cname}' updated successfully."];
    }

    public function deleteCourse(string $courseId): array {
        if (empty($courseId)) {
            return ['success' => false, 'message' => 'Course ID is required.'];
        }
        $result = $this->request('DELETE', "{$this->baseUrl}/{$courseId}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Course deleted successfully.'];
    }
}
