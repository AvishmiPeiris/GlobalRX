<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;
$firstName  = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName   = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$userEmail  = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role       = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');
$initial    = !empty($firstName) ? strtoupper($firstName[0]) : '?';
if (empty($fullName) && !empty($firstName)) $fullName = $firstName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enroll – Global RX Business</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="enrollment.css" rel="stylesheet">

<!-- Firebase (only needed when logged in) -->
<?php if ($isLoggedIn): ?>
<script type="module">
  import { initializeApp }       from "https://www.gstatic.com/firebasejs/11.0.0/firebase-app.js";
  import { getFirestore, collection, addDoc, getDocs, query, where, serverTimestamp }
                                  from "https://www.gstatic.com/firebasejs/11.0.0/firebase-firestore.js";
  import { getStorage, ref, uploadBytes, getDownloadURL }
                                  from "https://www.gstatic.com/firebasejs/11.0.0/firebase-storage.js";

  const firebaseConfig = {
    apiKey:            "AIzaSyA8wy_aEO2Pc3uMaNPyEEN2UsoGE9nQzeU",
    authDomain:        "globalrx-9085e.firebaseapp.com",
    projectId:         "globalrx-9085e",
    storageBucket:     "globalrx-9085e.firebasestorage.app",
    messagingSenderId: "632389557622",
    appId:             "1:632389557622:web:1f5da5ef9ecb13b018ae57"
  };

  const app     = initializeApp(firebaseConfig);
  const db      = getFirestore(app);
  const storage = getStorage(app);

  // Firestore helpers
  window._db             = db;
  window._firestoreAdd   = addDoc;
  window._collection     = collection;
  window._getDocs        = getDocs;
  window._query          = query;
  window._where          = where;
  window._serverTs       = serverTimestamp;

  // Storage helpers
  window._storage        = storage;
  window._storageRef     = ref;
  window._uploadBytes    = uploadBytes;
  window._getDownloadURL = getDownloadURL;

  /* ── Load courses & degrees from Firestore ── */
  async function loadCourses() {
    const loadingEl = document.getElementById('courseLoadingMsg');
    const selectEl  = document.getElementById('f_course');

    try {
      const coursesSnap  = await getDocs(collection(db, 'courses'));
      const degreesSnap  = await getDocs(collection(db, 'degrees'));

      let diplomasSnap = null;
      try { diplomasSnap = await getDocs(collection(db, 'diplomas')); } catch(e) {}

      const courses  = [];
      const degrees  = [];
      const diplomas = [];

      coursesSnap.forEach(doc => {
        const d = doc.data();
        if (d.cname || d.name) courses.push({ id: doc.id, name: d.cname || d.name });
      });

      degreesSnap.forEach(doc => {
        const d = doc.data();
        if (d.dname || d.name || d.degreeName) degrees.push({ id: doc.id, name: d.dname || d.degreeName || d.name });
      });

      if (diplomasSnap) {
        diplomasSnap.forEach(doc => {
          const d = doc.data();
          if (d.name || d.dname) diplomas.push({ id: doc.id, name: d.name || d.dname });
        });
      }

      if (loadingEl) loadingEl.remove();

      let html = '<option value="" disabled selected>Select Course / Degree</option>';

      if (degrees.length > 0) {
        html += '<optgroup label="🎓 A-Squared Higher Education — Degrees">';
        degrees.forEach(d => { html += `<option value="${escHtml(d.name)}">${escHtml(d.name)}</option>`; });
        html += '</optgroup>';
      }

      if (diplomas.length > 0) {
        html += '<optgroup label="📜 A-Squared Higher Education — Diplomas">';
        diplomas.forEach(d => { html += `<option value="${escHtml(d.name)}">${escHtml(d.name)}</option>`; });
        html += '</optgroup>';
      }

      if (courses.length > 0) {
        html += '<optgroup label="📚 A-Squared English Academy — Courses">';
        courses.forEach(c => { html += `<option value="${escHtml(c.name)}">${escHtml(c.name)}</option>`; });
        html += '</optgroup>';
      }

      if (degrees.length === 0 && diplomas.length === 0 && courses.length === 0) {
        html += buildFallbackOptions();
      }

      selectEl.innerHTML = html;

    } catch (err) {
      console.error('Failed to load courses:', err);
      if (loadingEl) loadingEl.textContent = 'Failed to load — using defaults';
      document.getElementById('f_course').innerHTML =
        '<option value="" disabled selected>Select Course / Degree</option>' + buildFallbackOptions();
    }
  }

  function escHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function buildFallbackOptions() {
    return `
      <optgroup label="A-Squared Higher Education Institute">
        <option>Bachelor of Business Administration</option>
        <option>Bachelor of Computer Science</option>
        <option>Bachelor of Engineering</option>
        <option>Master of Business Administration (MBA)</option>
        <option>Master of Information Technology</option>
        <option>Diploma in Project Management</option>
      </optgroup>
      <optgroup label="A-Squared English Academy">
        <option>Foundation English (A1–A2)</option>
        <option>Intermediate English (B1–B2)</option>
        <option>Advanced English (C1–C2)</option>
        <option>IELTS Preparation Course</option>
        <option>Business English</option>
      </optgroup>`;
  }

  document.addEventListener('DOMContentLoaded', loadCourses);
</script>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
<script>emailjs.init("WrHE0Z9-UkVWJ7rl7");</script>

<style>
/* ── NAV USER WIDGET ── */
.nav-user{position:relative}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #d0d0d0;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#111;transition:border-color .2s,background .2s;font-family:inherit}
.nav-user-toggle:hover{border-color:var(--red,#e63946);background:rgba(230,57,70,0.05)}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:var(--red,#e63946);overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0}
.nav-user-name{font-size:14px;font-weight:600;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111}
.nav-chevron{display:flex;align-items:center}
.nav-chevron svg{width:10px;height:6px;stroke:#555;fill:none;stroke-width:2;transition:transform .25s}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg)}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:280px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.14);border:1px solid #ececec;padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px}
.num-avatar-lg{width:48px;height:48px;border-radius:50%;background:var(--red,#e63946);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;color:#fff;flex-shrink:0;overflow:hidden}
.num-info{flex:1;min-width:0}
.num-name{font-size:14px;font-weight:700;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-email{font-size:12px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#f0f0f0;color:#555;font-size:10px;font-weight:700;letter-spacing:.5px;border-radius:50px;text-transform:capitalize}
.num-divider{height:1px;background:#f0f0f0;margin:4px 0}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#222;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#888;fill:currentColor}
.num-item:hover{background:#f6f6f6}
.num-logout{color:#e63946 !important}
.num-logout svg{color:#e63946 !important}
.num-logout:hover{background:#fff3f3 !important}
@media(max-width:768px){.nav-user-menu{width:260px;right:-10px}.nav-user-name{display:none}}

/* ── Login wall overlay ── */
#loginWall{min-height:60vh;display:flex;align-items:center;justify-content:center;padding:60px 20px}
.login-wall-card{background:#fff;border-radius:24px;padding:52px 44px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.10);border:1px solid #f0f0f0;max-width:480px;width:100%}
.login-wall-icon{font-size:3.5rem;margin-bottom:20px;line-height:1}
.login-wall-card h2{font-family:'Playfair Display',serif;font-size:1.9rem;font-weight:700;color:#111;margin-bottom:12px}
.login-wall-card p{color:#777;font-size:0.95rem;line-height:1.7;margin-bottom:28px}
.login-wall-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.btn-wall-login{background:#111;color:#fff;padding:12px 28px;border-radius:50px;font-weight:700;font-size:0.9rem;text-decoration:none;transition:background .2s,transform .2s;display:inline-flex;align-items:center;gap:8px}
.btn-wall-login:hover{background:var(--red,#e63946);transform:translateY(-2px)}
.btn-wall-signup{border:2px solid #e0e0e0;color:#555;padding:12px 28px;border-radius:50px;font-weight:700;font-size:0.9rem;text-decoration:none;transition:border-color .2s,color .2s;display:inline-flex;align-items:center;gap:8px}
.btn-wall-signup:hover{border-color:#111;color:#111}

/* ── Course loading spinner ── */
.course-loading-option{color:#aaa;font-style:italic}
.sel-loading-wrap{position:relative}
.sel-loading-wrap::after{content:'';position:absolute;right:36px;top:50%;transform:translateY(-50%);width:14px;height:14px;border:2px solid #e0e0e0;border-top-color:#2d9c5f;border-radius:50%;animation:spin .7s linear infinite;pointer-events:none}
.sel-loading-wrap.loaded::after{display:none}

/* ── Field errors ── */
.field-error{font-size:.74rem;color:#e63946;margin-top:3px;min-height:16px;display:block}
.inp.invalid,.sel.invalid{border-color:#e63946 !important;box-shadow:0 0 0 3px rgba(230,57,70,0.12) !important}
#phone-wrap.invalid{border-color:#e63946 !important;box-shadow:0 0 0 3px rgba(230,57,70,0.12) !important}

/* ── Success banner ── */
#successBanner{margin-top:28px;background:linear-gradient(135deg,#e8f9f0,#d1f5e2);border:1.5px solid #2d9c5f;border-radius:16px;padding:28px 32px;display:flex;align-items:center;gap:20px;animation:slideDown .4s ease}
@keyframes slideDown{from{opacity:0;transform:translateY(-12px)}to{opacity:1;transform:none}}
.success-icon{font-size:2.6rem;flex-shrink:0}
.success-text h3{font-family:'Playfair Display',serif;font-size:1.2rem;color:#1a6e42;margin-bottom:4px}
.success-text p{font-size:.88rem;color:#2d7a50;line-height:1.5}

/* ── Loading spinner on button ── */
.submit-btn.loading{pointer-events:none;opacity:.75}
.submit-btn.loading::after{content:'';display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;margin-left:10px;vertical-align:middle}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── Pre-fill indicator ── */
.prefill-note{font-size:0.75rem;color:#2d9c5f;margin-top:4px;display:flex;align-items:center;gap:4px}
.prefill-note::before{content:'✓';font-weight:700}

/* ── Upload progress bar ── */
.upload-progress-wrap{margin-top:8px;display:none}
.upload-progress-wrap.visible{display:block}
.upload-progress-bar{height:4px;border-radius:4px;background:#e0e0e0;overflow:hidden}
.upload-progress-fill{height:100%;width:0%;background:linear-gradient(90deg,#2d9c5f,#45c47a);border-radius:4px;transition:width .3s ease}
.upload-progress-label{font-size:.73rem;color:#2d9c5f;margin-top:4px}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php"            class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php"         class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $userEmail ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <div id="navLoggedOut">
    <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  </div>
  <?php endif; ?>
</nav>

<!-- HERO BANNER -->
<div class="hero-banner">
  <div class="hero-arc"></div>
  <svg class="plane" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 24L42 6L30 42L22 28L6 24Z" fill="white" fill-opacity="0.9"/>
    <path d="M22 28L30 20" stroke="white" stroke-width="2" stroke-linecap="round"/>
  </svg>
  <div class="hero-content">
    <h1>Enroll Today With<br><em>A Squared</em></h1>
    <p>Take the first step towards your future — fill in your details and choose your program. Our team will guide you every step of the way.</p>
  </div>
  <div class="hero-icons">
    <div class="hero-icon-circle">🌐</div>
    <div class="hero-icon-circle">📚</div>
  </div>
</div>

<!-- PAGE WRAP -->
<div class="page-wrap">

<?php if (!$isLoggedIn): ?>
  <!-- ══════════════════════════════════════════
       LOGIN WALL — shown to guests
       ══════════════════════════════════════════ -->
  <div id="loginWall">
    <div class="login-wall-card">
      <div class="login-wall-icon">🔒</div>
      <h2>Sign In to Enroll</h2>
      <p>
        You need to be signed in to submit an enrollment application.
        Create a free account or log in to continue — it only takes a minute.
      </p>
      <div class="login-wall-btns">
        <a href="signin.html?redirect=enrollment.php" class="btn-wall-login">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
          Log In
        </a>
        <a href="signup.html" class="btn-wall-signup">
          <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
          Create Account
        </a>
      </div>
    </div>
  </div>

<?php else: ?>
  <!-- ══════════════════════════════════════════
       ENROLLMENT FORM — shown to logged-in users
       ══════════════════════════════════════════ -->

  <div class="intro-card">
    <div class="intro-icon-wrap">🎓</div>
    <div class="intro-card-text">
      <h2>Fill Out the Form Below to Enroll in one of our Programs</h2>
      <p>Global RX Business LTD — Connecting individuals with life-changing opportunities worldwide.</p>
    </div>
    <div class="intro-lady">👩‍💼</div>
  </div>

  <div class="form-card">

    <!-- PERSONAL INFORMATION -->
    <div class="section-hd">
      <div class="section-hd-dot"></div>
      <h3>Personal Information</h3>
    </div>
    <div class="form-body">

      <div class="form-row">
        <div class="field">
          <label><span class="lbl-icon">👤</span>Full Name</label>
          <input class="inp" id="f_name" type="text" placeholder="Full Name"
                 value="<?= $fullName ?>" />
          <?php if (!empty($fullName)): ?>
          <span class="prefill-note">Pre-filled from your account</span>
          <?php endif; ?>
          <span class="field-error" id="err_name"></span>
        </div>
        <div class="field">
          <label><span class="lbl-icon">✉️</span>Email</label>
          <input class="inp" id="f_email" type="email" placeholder="Email Address"
                 value="<?= $userEmail ?>" />
          <?php if (!empty($userEmail)): ?>
          <span class="prefill-note">Pre-filled from your account</span>
          <?php endif; ?>
          <span class="field-error" id="err_email"></span>
        </div>
      </div>

      <div class="form-row">
        <div class="field">
          <label><span class="lbl-icon">📅</span>Age</label>
          <input class="inp" id="f_age" type="number" placeholder="Age" min="10" max="99" />
          <span class="field-error" id="err_age"></span>
        </div>
        <div class="field">
          <label><span class="lbl-icon">📍</span>Location</label>
          <input class="inp" id="f_location" type="text" placeholder="Location" />
          <span class="field-error" id="err_location"></span>
        </div>
      </div>

      <div class="form-row single" style="margin-bottom:0">
        <div class="field">
          <label><span class="lbl-icon">📞</span>Contact</label>
          <div class="phone-wrap" id="phone-wrap">
            <div class="country-select-wrap">
              <select class="country-sel" id="countryCode">
                <option value="+93">🇦🇫 +93</option><option value="+355">🇦🇱 +355</option>
                <option value="+213">🇩🇿 +213</option><option value="+54">🇦🇷 +54</option>
                <option value="+61">🇦🇺 +61</option><option value="+43">🇦🇹 +43</option>
                <option value="+880">🇧🇩 +880</option><option value="+32">🇧🇪 +32</option>
                <option value="+55">🇧🇷 +55</option><option value="+1">🇨🇦 +1</option>
                <option value="+86">🇨🇳 +86</option><option value="+57">🇨🇴 +57</option>
                <option value="+20">🇪🇬 +20</option><option value="+33">🇫🇷 +33</option>
                <option value="+49">🇩🇪 +49</option><option value="+233">🇬🇭 +233</option>
                <option value="+30">🇬🇷 +30</option><option value="+91">🇮🇳 +91</option>
                <option value="+62">🇮🇩 +62</option><option value="+98">🇮🇷 +98</option>
                <option value="+353">🇮🇪 +353</option><option value="+972">🇮🇱 +972</option>
                <option value="+39">🇮🇹 +39</option><option value="+81">🇯🇵 +81</option>
                <option value="+254">🇰🇪 +254</option><option value="+82">🇰🇷 +82</option>
                <option value="+965">🇰🇼 +965</option><option value="+60">🇲🇾 +60</option>
                <option value="+960">🇲🇻 +960</option><option value="+52">🇲🇽 +52</option>
                <option value="+212">🇲🇦 +212</option><option value="+977">🇳🇵 +977</option>
                <option value="+31">🇳🇱 +31</option><option value="+64">🇳🇿 +64</option>
                <option value="+234">🇳🇬 +234</option><option value="+47">🇳🇴 +47</option>
                <option value="+968">🇴🇲 +968</option><option value="+92">🇵🇰 +92</option>
                <option value="+63">🇵🇭 +63</option><option value="+48">🇵🇱 +48</option>
                <option value="+351">🇵🇹 +351</option><option value="+974">🇶🇦 +974</option>
                <option value="+7">🇷🇺 +7</option><option value="+966">🇸🇦 +966</option>
                <option value="+65">🇸🇬 +65</option><option value="+27">🇿🇦 +27</option>
                <option value="+34">🇪🇸 +34</option>
                <option value="+94" selected>🇱🇰 +94</option>
                <option value="+46">🇸🇪 +46</option><option value="+41">🇨🇭 +41</option>
                <option value="+66">🇹🇭 +66</option><option value="+90">🇹🇷 +90</option>
                <option value="+971">🇦🇪 +971</option><option value="+44">🇬🇧 +44</option>
                <option value="+1">🇺🇸 +1</option><option value="+84">🇻🇳 +84</option>
              </select>
              <span class="country-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
            </div>
            <input class="phone-number-inp" id="f_phone" type="tel" placeholder="Mobile number" />
          </div>
          <span class="field-error" id="err_phone"></span>
        </div>
      </div>

    </div>

    <div style="height:1px;background:#f0f0f0;"></div>

    <!-- COURSE SELECTION -->
    <div class="section-hd">
      <div class="section-hd-dot" style="background:#2d9c5f;"></div>
      <h3>Course Selection</h3>
    </div>
    <div class="form-body">

      <div class="form-row single">
        <div class="field">
          <label><span class="lbl-icon">📋</span>Latest Result Sheet <span style="color:#aaa;font-weight:400;font-size:.8rem">(optional)</span></label>
          <div class="file-zone" onclick="document.getElementById('resultFile').click()">
            <div class="file-zone-left">
              <div class="file-zone-icon">📄</div>
              <div class="file-zone-info">
                <strong>Upload your latest result sheet</strong>
                PDF, JPG or PNG — Max 5MB
              </div>
            </div>
            <button class="file-browse-btn" type="button">Browse From Computer</button>
            <input type="file" id="resultFile" accept=".pdf,.jpg,.jpeg,.png" style="display:none"
                   onchange="handleFile(this,'resultName')" />
          </div>
          <!-- File name display -->
          <div id="resultName" style="font-size:.78rem;color:#2d9c5f;margin-top:5px;display:none;"></div>
          <!-- Upload progress bar -->
          <div class="upload-progress-wrap" id="uploadProgressWrap">
            <div class="upload-progress-bar">
              <div class="upload-progress-fill" id="uploadProgressFill"></div>
            </div>
            <div class="upload-progress-label" id="uploadProgressLabel">Uploading…</div>
          </div>
        </div>
      </div>

      <div class="form-row single">
        <div class="field">
          <label><span class="lbl-icon">🎓</span>Course / Degree</label>
          <div class="sel-wrap sel-loading-wrap" id="courseSelectWrap">
            <select class="sel" id="f_course">
              <option id="courseLoadingMsg" class="course-loading-option" disabled selected>
                ⏳ Loading available programmes…
              </option>
            </select>
          </div>
          <span class="field-error" id="err_course"></span>
        </div>
      </div>

    </div>

    <div class="submit-area">
      <button class="submit-btn" id="submitBtn" type="button" onclick="handleSubmit()">Submit Enrollment</button>
      <p class="submit-terms">By submitting this form, you agree to our <a href="#">Terms &amp; Conditions</a> and <a href="#">Privacy Policy</a>.</p>
    </div>

  </div><!-- /form-card -->

  <!-- SUCCESS BANNER -->
  <div id="successBanner" style="display:none">
    <div class="success-icon">🎉</div>
    <div class="success-text">
      <h3>Enrollment Submitted!</h3>
      <p>Thank you! Our team will review your application and reach out to you shortly.</p>
    </div>
  </div>

<?php endif; ?>

</div><!-- /page-wrap -->

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Global RX Business LTD is a London-based professional services firm dedicated to connecting individuals with life-changing opportunities worldwide.</p>
      </div>
      <div class="footer-col"><h4>PAGES</h4><ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
      </ul></div>
      <div class="footer-col"><h4>SUBSIDIARIES</h4><ul>
        <li><a href="visa.php">A² Visa Consultation</a></li>
        <li><a href="english.php">A² English Academy</a></li>
        <li><a href="higherEducation.php">A² Higher Education</a></li>
      </ul></div>
      <div class="footer-col"><h4>CONTACT</h4><ul>
        <li><span>info@globalrx.co.uk</span></li>
        <li><span>+44 1234 56789</span></li>
        <li><span>London, United Kingdom</span></li>
      </ul></div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business LTD. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
const EMAILJS_SERVICE_ID  = "service_w1mlupf";
const EMAILJS_TEMPLATE_ID = "template_tblae0c";

/* ── Nav helpers ── */
function toggleDropdown() {
  document.getElementById('divDropdown').classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('divDropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});
window.addEventListener('scroll', () => {
  document.querySelector('nav').style.boxShadow =
    window.scrollY > 40 ? '0 8px 32px rgba(0,0,0,0.14)' : '0 4px 24px rgba(0,0,0,0.06)';
});

/* ── User menu ── */
const navUserToggle = document.getElementById('navUserToggle');
const navUserMenu   = document.getElementById('navUserMenu');
if (navUserToggle && navUserMenu) {
  navUserToggle.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = navUserMenu.classList.toggle('open');
    navUserToggle.setAttribute('aria-expanded', isOpen);
  });
  document.addEventListener('click', e => {
    const navUser = document.getElementById('navUser');
    if (navUser && !navUser.contains(e.target)) {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
}

/* ── Remove spinner once courses loaded ── */
document.addEventListener('DOMContentLoaded', () => {
  const wrap = document.getElementById('courseSelectWrap');
  const sel  = document.getElementById('f_course');
  if (wrap && sel) {
    const obs = new MutationObserver(() => {
      if (sel.options.length > 1) { wrap.classList.add('loaded'); obs.disconnect(); }
    });
    obs.observe(sel, { childList: true, subtree: true });
    setTimeout(() => wrap.classList.add('loaded'), 5000);
  }
});

/* ── File picker ── */
function handleFile(input, labelId) {
  const label = document.getElementById(labelId);
  if (input.files && input.files[0]) {
    const file = input.files[0];

    // 5MB size guard
    if (file.size > 5 * 1024 * 1024) {
      alert('File is too large. Maximum size is 5MB.');
      input.value = '';
      return;
    }

    label.textContent = '✓ ' + file.name;
    label.style.display = 'block';
  }
}

/* ── Validation helpers ── */
function clearErrors() {
  ['name','email','age','location','phone','course'].forEach(k => {
    const e = document.getElementById('err_' + k);
    if (e) e.textContent = '';
  });
  document.querySelectorAll('.inp, .sel').forEach(el => el.classList.remove('invalid'));
  const pw = document.getElementById('phone-wrap');
  if (pw) pw.classList.remove('invalid');
}

function showError(fieldId, errId, msg) {
  const field = document.getElementById(fieldId);
  const err   = document.getElementById(errId);
  if (field) field.classList.add('invalid');
  if (err)   err.textContent = msg;
}

function validate(data) {
  let ok = true;
  if (!data.fullName)  { showError('f_name','err_name','Full name is required.'); ok = false; }
  if (!data.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    showError('f_email','err_email','A valid email address is required.'); ok = false;
  }
  if (!data.age || data.age < 10 || data.age > 99) {
    showError('f_age','err_age','Please enter a valid age (10–99).'); ok = false;
  }
  if (!data.location)  { showError('f_location','err_location','Location is required.'); ok = false; }
  if (!data.phone) {
    document.getElementById('phone-wrap').classList.add('invalid');
    document.getElementById('err_phone').textContent = 'Phone number is required.';
    ok = false;
  }
  if (!data.course)    { showError('f_course','err_course','Please select a course or degree.'); ok = false; }
  return ok;
}

/* ── Progress bar helpers ── */
function showProgress(label) {
  const wrap  = document.getElementById('uploadProgressWrap');
  const fill  = document.getElementById('uploadProgressFill');
  const lbl   = document.getElementById('uploadProgressLabel');
  wrap.classList.add('visible');
  lbl.textContent = label || 'Uploading…';
  // Animate to 80% while waiting — snaps to 100% on complete
  fill.style.width = '0%';
  setTimeout(() => { fill.style.width = '80%'; }, 50);
}

function completeProgress() {
  const fill = document.getElementById('uploadProgressFill');
  const wrap = document.getElementById('uploadProgressWrap');
  const lbl  = document.getElementById('uploadProgressLabel');
  fill.style.width = '100%';
  lbl.textContent  = '✓ Upload complete';
  setTimeout(() => { wrap.classList.remove('visible'); fill.style.width = '0%'; }, 1800);
}

/* ── Submit (only reachable when logged in) ── */
async function handleSubmit() {
  clearErrors();

  const data = {
    fullName    : (document.getElementById('f_name')?.value    || '').trim(),
    email       : (document.getElementById('f_email')?.value   || '').trim(),
    age         : parseInt(document.getElementById('f_age')?.value),
    location    : (document.getElementById('f_location')?.value || '').trim(),
    countryCode : document.getElementById('countryCode')?.value || '+94',
    phone       : (document.getElementById('f_phone')?.value   || '').trim(),
    course      : document.getElementById('f_course')?.value   || '',
    submittedAt : new Date().toLocaleString('en-GB', { dateStyle:'long', timeStyle:'short' }),
    status      : 'Pending'
  };
  data.fullPhone = data.countryCode + ' ' + data.phone;

  if (!validate(data)) return;

  const btn = document.getElementById('submitBtn');
  btn.classList.add('loading');

  try {
    if (!window._firestoreAdd) throw new Error('Firebase not ready. Please refresh.');

    // ── STEP 1: Upload result sheet to Firebase Storage (if provided) ──
    let resultSheetURL = 'Not provided';
    const fileInput = document.getElementById('resultFile');

    if (fileInput?.files?.[0]) {
      btn.textContent = 'Uploading file…';
      showProgress('Uploading result sheet…');

      const file     = fileInput.files[0];
      const safeName = file.name.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9._-]/g, '');
      const filePath = `result-sheets/${Date.now()}_${safeName}`;
      const fileRef  = window._storageRef(window._storage, filePath);

      await window._uploadBytes(fileRef, file);
      resultSheetURL = await window._getDownloadURL(fileRef);
      completeProgress();
    }

    // ── STEP 2: Save enrollment document to Firestore ──
    btn.textContent = 'Saving enrollment…';
    const docRef = await window._firestoreAdd(
      window._collection(window._db, 'enrollments'),
      {
        fullName    : data.fullName,
        email       : data.email,
        age         : data.age,
        location    : data.location,
        phone       : data.fullPhone,
        course      : data.course,
        status      : 'Pending',
        resultSheet : resultSheetURL,   // Firebase Storage URL or 'Not provided'
        createdAt   : window._serverTs()
      }
    );

    // ── STEP 3: Send notification email via EmailJS ──
    btn.textContent = 'Sending confirmation…';
    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
      student_name        : data.fullName,
      student_email       : data.email,
      student_age         : data.age,
      student_location    : data.location,
      student_phone       : data.fullPhone,
      student_course      : data.course,
      submitted_at        : data.submittedAt,
      record_id           : docRef.id,
      result_sheet_url    : resultSheetURL   // Clean download link in the email
    });

    // ── STEP 4: Show success banner ──
    document.querySelector('.form-card').style.display = 'none';
    const banner = document.getElementById('successBanner');
    banner.style.display = 'flex';
    banner.scrollIntoView({ behavior: 'smooth', block: 'center' });

  } catch (err) {
    console.error('Enrollment error:', err);
    btn.textContent = 'Something went wrong — try again';
    btn.classList.remove('loading');
    btn.style.background = 'linear-gradient(135deg,#c0392b,#e05c5c)';
  }
}
</script>
</body>
</html>