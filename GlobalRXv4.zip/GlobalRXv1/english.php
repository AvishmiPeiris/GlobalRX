<?php
require_once 'CourseManager.php';
$cm      = new CourseManager();
$result  = $cm->getAllCourses();
$courses = $result['success'] ? $result['courses'] : [];
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>A-Squared English Academy</title>
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800&family=Barlow+Condensed:wght@400;600;700;800&family=Montserrat:wght@400;600;700;800;900&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="englishAc.css">
</head>
<body>

<!-- ══ NAV ══════════════════════════════════════════ -->

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.html">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.html" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.html">About Us</a></li>
    <li><a href="contactus.html">Contact Us</a></li>
  </ul>
  <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
</nav>

<!-- ══ HERO BANNER ══════════════════════════════════ -->
<div class="hero-banner">
  <h1>English <span>Academy</span></h1>
  <div class="breadcrumb">
    <a href="index.html">Home</a>
    <span class="sep">›</span>
    <span class="bc-active">English Academy</span>
  </div>
</div>

<!-- ══ ABOUT ════════════════════════════════════════ -->
<section class="about-strip">
  <div class="about-left">
    <div class="sec-label">Who We Are</div>
    <h2 class="sec-title">A-SQUARED ACADEMY<br>AROUND <span class="hl">THE WORLD</span></h2>
    <p class="sec-text">A-Squared Academy is a leading provider of English language training programmes, serving students globally. Our expert tutors and accredited courses help learners of all levels achieve their goals — from business communication to Cambridge qualifications and TEFL certification.</p>
  </div>
  <div class="about-right">
    <div class="about-right-wrap">
      <div class="about-img-grid">
        <div class="aib tall"><img src="images/girl.jpg.jpg" style="width:100%;height:100%;object-fit:cover;" /></div>
        <div class="aib tall"><img src="images/all.jpg.jpg"  style="width:100%;height:100%;object-fit:cover;" /></div>
      </div>
      <div class="about-badge">2,400+<small>Students</small></div>
    </div>
  </div>
</section>

<!-- ══ STATS BAR ═════════════════════════════════════ -->
<div class="stats-bar">
  <div class="stat-item"><div class="stat-num">IELTS</div><div class="stat-lbl">Preparation</div></div>
  <div class="stat-item"><div class="stat-num">Cambridge</div><div class="stat-lbl">Qualifications</div></div>
  <div class="stat-item"><div class="stat-num">Business</div><div class="stat-lbl">English</div></div>
  <div class="stat-item"><div class="stat-num">TEFL</div><div class="stat-lbl">Certification</div></div>
  <div class="stat-item"><div class="stat-num">Academic</div><div class="stat-lbl">English</div></div>
</div>

<!-- ══ PROGRAMMES ════════════════════════════════════ -->
<section class="programmes">
  <div class="sec-header">
    <div>
      <div class="sec-label">What We Offer</div>
      <h2 class="sec-title">EXPLORE OUR <span class="hl">PROGRAMMES</span></h2>
    </div>
  </div>

  <div class="prog-grid">
    <?php if (!empty($courses)): ?>
      <?php foreach ($courses as $course): ?>
        <div class="prog-card">
          <div class="prog-icon">
            <?php if (!empty($course['iconUrl'])): ?>
              <img src="<?php echo htmlspecialchars($course['iconUrl']); ?>"
                   alt="<?php echo htmlspecialchars($course['cname']); ?>"
                   style="width:100%;height:100%;object-fit:contain;">
            <?php else: ?>
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3zM5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/>
              </svg>
            <?php endif; ?>
          </div>
          <p class="prog-title"><?php echo htmlspecialchars($course['cname']); ?></p>
          <p class="prog-description"><?php echo htmlspecialchars($course['description']); ?></p>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p style="grid-column:1/-1;text-align:center;color:#888;padding:40px 0;">
        No programmes available at the moment.
      </p>
    <?php endif; ?>
  </div>
</section>

<!-- ══ CAMBRIDGE ══════════════════════════════════════ -->
<section class="cambridge">
  <div class="cambridge-left">
    <div class="sec-label">Internationally Recognised</div>
    <h2 class="sec-title">CAMBRIDGE <span class="hl">ENGLISH</span> QUALIFICATIONS</h2>
    <p class="sec-text">Our Cambridge-approved programmes prepare students for globally recognised English qualifications. Whether you're aiming for B2 First, C1 Advanced or C2 Proficiency, our expert tutors guide you every step of the way.</p>
    <div class="cam-stats">
      <div class="cam-stat"><div class="cam-stat-num">B1</div><div class="cam-stat-lbl">Preliminary</div></div>
      <div class="cam-stat"><div class="cam-stat-num">B2</div><div class="cam-stat-lbl">First</div></div>
      <div class="cam-stat"><div class="cam-stat-num">C1</div><div class="cam-stat-lbl">Advanced</div></div>
      <div class="cam-stat"><div class="cam-stat-num">C2</div><div class="cam-stat-lbl">Proficiency</div></div>
    </div>
  </div>
  <div class="cambridge-right">
    <img src="images/cambridge.jpg" style="width:100%;height:100%;object-fit:cover;display:block;" />
  </div>
</section>

<!-- ══ ACCREDITED ═════════════════════════════════════ -->
<section class="accredited">
  <div class="accredited-left">
    <div class="acc-img-ph">
      <img src="images/teach.jpg" style="width:100%;height:100%;min-height:280px;object-fit:cover;display:block;" />
    </div>
  </div>
  <div class="accredited-right">
    <div class="sec-label">Credentials That Count</div>
    <h2 class="sec-title">ACCREDITED TEACHING<br><span class="hl">QUALIFICATIONS</span></h2>
    <ul class="acc-list">
      <li><div class="acc-dot"></div><div><p class="acc-item-title">Level 5 TEFL Certification</p><p>Internationally recognised — accepted in over 80 countries worldwide.</p></div></li>
      <li><div class="acc-dot"></div><div><p class="acc-item-title">Ofqual Regulated Qualifications</p><p>Regulated by Ofqual and recognised by top employers globally.</p></div></li>
      <li><div class="acc-dot"></div><div><p class="acc-item-title">CPD Accredited Courses</p><p>Continuing Professional Development credits accepted across all sectors.</p></div></li>
    </ul>
  </div>
</section>

<!-- ══ TEFL ═══════════════════════════════════════════ -->
<section class="tefl">
  <div>
    <div class="sec-label">Teach English Globally</div>
    <h2 class="sec-title">WHY CHOOSE OUR <span class="hl">TEFL</span> PROGRAMME?</h2>
    <ul class="tefl-list">
      <li><span class="tag-pill">01</span> Internationally accredited with placements in 80+ countries</li>
      <li><span class="tag-pill">02</span> Flexible online study — complete at your own pace</li>
      <li><span class="tag-pill">03</span> Dedicated job placement support and career guidance</li>
      <li><span class="tag-pill">04</span> Expert tutors with 10+ years classroom experience</li>
    </ul>
  </div>
  <div style="display:flex;align-items:center;justify-content:center;">
    <div class="tefl-badge">
      <span class="tefl-badge-top">TEFL</span>
      <span class="tefl-badge-mid">120</span>
      <span class="tefl-badge-bot">Hours</span>
    </div>
  </div>
</section>

<!-- ══ BIG STATS ══════════════════════════════════════ -->
<div class="big-stats">
  <div class="big-stat"><div class="big-stat-num">2,400<sup>+</sup></div><div class="big-stat-lbl">Students Enrolled</div></div>
  <div class="big-stat"><div class="big-stat-num">89<sup>%</sup></div><div class="big-stat-lbl">Pass Rate</div></div>
  <div class="big-stat"><div class="big-stat-num">12<sup>+</sup></div><div class="big-stat-lbl">Years Experience</div></div>
  <div class="big-stat"><div class="big-stat-num">40<sup>+</sup></div><div class="big-stat-lbl">Expert Tutors</div></div>
</div>

<!-- ══ ENROLLMENT BANNER ══════════════════════════════ -->
<div class="cta-banner">
  <div>
    <p class="cta-sub">Enrolment Now Open</p>
    <h2 class="cta-title">WANT TO JOIN OUR <span>COURSES?</span> YOU HAVE TO ENROL</h2>
  </div>
  <a href="enrollment.html">
    <button class="btn-white">Enrol Now</button>
  </a>
</div>

<!-- ══ FOOTER ════════════════════════════════════════ -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col">
        <h4>PAGES</h4>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="aboutus.html">About Us</a></li>
          <li><a href="contactus.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>SUBSIDIARIES</h4>
        <ul>
          <li><a href="visa.php">A² Visa Consultation</a></li>
          <li><a href="higherEducation.html">A² Higher Education</a></li>
          <li><a href="english.php">A² English Academy</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>CONTACT</h4>
        <ul>
          <li><span>info@globalrx.com</span></li>
          <li><span>+1 (800) 000-0000</span></li>
          <li><span>Colombo, Sri Lanka</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
  function toggleDropdown() {
    document.getElementById('divDropdown').classList.toggle('open');
  }
  document.addEventListener('click', e => {
    const dd = document.getElementById('divDropdown');
    if (dd && !dd.contains(e.target)) dd.classList.remove('open');
  });
  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 8px 32px rgba(0,0,0,0.14)'
      : '0 4px 24px rgba(0,0,0,0.06)';
  });
</script>

</body>
</html>
