<?php
require_once 'VisaManager.php';

$visaManager  = new VisaManager();
$visaResult   = $visaManager->getAllVisa();
$visaCountries = $visaResult['success'] ? $visaResult['visas'] : [];

// Only show Active countries on the public page
$visaCountries = array_values(array_filter($visaCountries, fn($v) => strtolower($v['status'] ?? 'active') === 'active'));

// Badge colour cycling for variety
$badgeColors = ['blue','green','red','yellow','navy','teal','purple'];
function getBadgeClass(int $i): string {
    $classes = ['badge-blue','badge-green','badge-red','badge-yellow','badge-navy','badge-teal','badge-purple'];
    return $classes[$i % count($classes)];
}

// Helper: build a safe CSS id from countryCode
function panelId(string $code): string {
    return 'panel-' . preg_replace('/[^a-z0-9_-]/', '-', strtolower(trim($code)));
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Global RX Business LTD – Visa Management</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,800;1,700&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="visa.css">
<style>
/* ── Dynamic country panel extras ── */
.cph-flag-text{
  width:72px;height:72px;border-radius:16px;background:linear-gradient(135deg,#1a2e5a,#2e4a8a);
  display:flex;align-items:center;justify-content:center;font-size:32px;flex-shrink:0;
  box-shadow:0 4px 16px rgba(26,46,90,.18);
}
.cph-flag-initials{
  width:72px;height:72px;border-radius:16px;background:linear-gradient(135deg,#1a2e5a,#2e4a8a);
  display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;
  color:#fff;flex-shrink:0;letter-spacing:1px;font-family:'Playfair Display',serif;
  box-shadow:0 4px 16px rgba(26,46,90,.18);
}
.cph-badge{display:inline-flex;align-items:center;padding:4px 12px;border-radius:20px;font-size:11.5px;font-weight:700;margin:3px;border:1.5px solid transparent}
.cph-badge.blue{background:#e8f0fb;color:#1a4a8a;border-color:#c5d8f5}
.cph-badge.green{background:#e6f9f0;color:#1a6b45;border-color:#b5e5cc}
.cph-badge.red{background:#fce8e8;color:#c0392b;border-color:#f5c0c0}
.cph-badge.yellow{background:#fdf6e3;color:#8a6200;border-color:#f0d880}
.cph-badge.navy{background:#eaf0fb;color:#1a2e5a;border-color:#c5d0ea}
.cph-badge.teal{background:#e0f7f5;color:#0d6b63;border-color:#a8e4de}
.cph-badge.purple{background:#f3ecfb;color:#6b2fa0;border-color:#d5b5f0}

/* Visa type info card extras */
.vt-info-card{background:#fff;border-radius:14px;padding:22px 24px;box-shadow:0 2px 12px rgba(26,46,90,.07);border:1px solid #eef2f8}
.vt-info-card-header{display:flex;align-items:center;gap:12px;margin-bottom:16px}
.vt-icon-wrap{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.vt-icon-wrap.c0{background:#e8f0fb} .vt-icon-wrap.c1{background:#fce8e8}
.vt-icon-wrap.c2{background:#e6f9f0} .vt-icon-wrap.c3{background:#fdf6e3}
.vt-icon-wrap.c4{background:#eaf0fb} .vt-icon-wrap.c5{background:#e0f7f5}
.vt-icon-wrap.c6{background:#f3ecfb}
.vt-info-card h4{font-family:'Nunito',sans-serif;font-size:15px;font-weight:800;color:#1a2e5a;margin:0}
.vt-detail-line{font-size:13px;color:#444;padding:5px 0;border-bottom:1px solid #f0f4f8;line-height:1.55}
.vt-detail-line:last-child{border-bottom:none}

/* Pathway bar */
.pathway-bar{background:linear-gradient(135deg,#1a2e5a 0%,#2e4a8a 100%);border-radius:14px;padding:18px 24px;margin:20px 0}
.pathway-bar h4{color:#fff;font-size:13px;font-weight:700;margin:0 0 10px;opacity:.85;font-family:'Nunito',sans-serif}
.pathway-steps{display:flex;align-items:center;flex-wrap:wrap;gap:6px}
.pathway-step{background:rgba(255,255,255,.14);color:#fff;font-size:12px;font-weight:700;padding:6px 14px;border-radius:20px;font-family:'Nunito',sans-serif}
.pathway-arrow{color:rgba(255,255,255,.55);font-size:16px;font-weight:700}

/* Reality box */
.reality-box{background:#fdf6e3;border-radius:14px;padding:18px 22px;margin-top:16px;display:flex;gap:14px;align-items:flex-start;border:1.5px solid #f0d880}
.reality-icon{font-size:22px;flex-shrink:0;margin-top:2px}
.reality-content h4{font-family:'Nunito',sans-serif;font-size:13px;font-weight:800;color:#7a5200;margin:0 0 8px}
.reality-bullets{list-style:none;padding:0;margin:0}
.reality-bullets li{font-size:12.5px;color:#5a3d00;padding:3px 0;padding-left:16px;position:relative}
.reality-bullets li::before{content:'•';position:absolute;left:0;color:#c9a84c;font-weight:900}

/* Info grid */
.info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin:20px 0}

/* Empty state */
.no-countries-msg{text-align:center;padding:60px 20px;color:#888;font-size:16px}
</style>
</head>
<body class="dot-bg">

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.html">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.html" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.html">About Us</a></li>
    <li><a href="contactus.html">Contact Us</a></li>
  </ul>
  <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
</nav>


<!-- HERO -->
<section class="hero">
  <svg class="hero-bg-svg" viewBox="0 0 1400 680" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <style>.map-line{fill:none;stroke:rgba(26,46,90,0.09);stroke-width:1.2}.map-dot{fill:rgba(26,46,90,0.13)}.red-el{fill:rgba(230,57,70,0.1)}.navy-el{fill:rgba(26,46,90,0.07)}.stamp-ring{fill:none;stroke:rgba(26,46,90,0.12);stroke-width:1.5;stroke-dasharray:4 3}.plane-path{fill:none;stroke:rgba(26,46,90,0.11);stroke-width:1.2;stroke-dasharray:6 4}.plane-body{fill:rgba(26,46,90,0.14)}.wave-line{fill:none;stroke:rgba(26,46,90,0.07);stroke-width:1}</style>
      <g id="plane"><path d="M0,-6 L14,0 L0,5 L2,0 Z" class="plane-body"/><path d="M4,-2 L10,-8 L11,-7 L6,0 Z" class="plane-body"/><path d="M4,2 L10,8 L11,7 L6,0 Z" class="plane-body"/></g>
      <g id="stamp"><circle cx="0" cy="0" r="36" class="stamp-ring"/><circle cx="0" cy="0" r="28" class="stamp-ring"/><text x="0" y="4" text-anchor="middle" font-size="9" fill="rgba(26,46,90,0.15)" font-family="sans-serif" font-weight="bold" letter-spacing="1">APPROVED</text><text x="0" y="-10" text-anchor="middle" font-size="7" fill="rgba(26,46,90,0.12)" font-family="sans-serif">VISA</text></g>
      <g id="pin"><path d="M0,-14 C-6,-14 -10,-9 -10,-4 C-10,4 0,14 0,14 C0,14 10,4 10,-4 C10,-9 6,-14 0,-14 Z" fill="rgba(230,57,70,0.15)"/><circle cx="0" cy="-4" r="4" fill="rgba(230,57,70,0.2)"/></g>
    </defs>
    <ellipse cx="1150" cy="340" rx="220" ry="220" class="map-line" opacity=".5"/>
    <ellipse cx="1150" cy="340" rx="160" ry="220" class="map-line" opacity=".4"/>
    <ellipse cx="1150" cy="340" rx="80" ry="220" class="map-line" opacity=".35"/>
    <line x1="930" y1="340" x2="1370" y2="340" class="map-line"/>
    <line x1="1150" y1="120" x2="1150" y2="560" class="map-line"/>
    <path d="M0,350 Q180,310 360,360 Q540,410 720,360 Q900,310 1080,350" class="wave-line"/>
    <g transform="translate(300,120) rotate(15) scale(2.2)"><use href="#plane"/></g>
    <g transform="translate(750,80) rotate(-10) scale(1.8)"><use href="#plane"/></g>
    <g transform="translate(1115,165) rotate(35)"><use href="#plane"/></g>
    <g transform="translate(60,90)"><use href="#stamp" transform="scale(0.7)"/></g>
    <g transform="translate(820,80)"><use href="#stamp" transform="scale(0.6)"/></g>
    <g transform="translate(200,50)"><use href="#pin" transform="scale(0.8)"/></g>
    <g transform="translate(650,60)"><use href="#pin" transform="scale(0.7)"/></g>
    <path d="M430,490 L432,484 L434,490 L440,492 L434,494 L432,500 L430,494 L424,492 Z" fill="rgba(230,57,70,0.18)"/>
  </svg>

  <div class="hero-text">
    <span class="hero-badge"><span class="hero-badge-dot"></span>VALIDATION</span>
    <h1>Visa Management<br><em>Made Simple</em><br>for You</h1>
    <p class="hero-desc">Global RX Business LTD is a London-based consultancy offering expert global education, career, and visa solutions tailored to your needs.</p>
    <div class="hero-stats">
      <div class="stat"><strong>99%</strong><span>Success Rate</span></div>
      <div class="stat"><strong><?= count($visaCountries) ?>+</strong><span>Countries</span></div>
      <div class="stat"><strong>1K+</strong><span>Visas Accepted</span></div>
    </div>
    <div class="search-card">
      <div class="search-field">
        <label>Visa Type</label>
        <select id="visaType">
          <option value="">Select Type</option>
          <option value="student">Student Visa</option>
          <option value="work">Work Visa</option>
          <option value="family">Family Visa</option>
          <option value="business">Business Visa</option>
        </select>
      </div>
      <div class="search-field">
        <label>Country</label>
        <select id="visaCountry">
          <option value="">Select Country</option>
          <?php foreach ($visaCountries as $vc): ?>
          <option value="<?= htmlspecialchars($vc['countryCode']) ?>"
                  data-flag="<?= htmlspecialchars($vc['flagEmoji'] ?: '🌍') ?>"
                  data-name="<?= htmlspecialchars($vc['countryName']) ?>"
                  data-valid="true">
            <?= htmlspecialchars($vc['countryName']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="search-field">
        <label>Date</label>
        <input type="date" id="visaDate" value="<?= date('Y-m-d') ?>">
      </div>
      <button class="btn-check" onclick="checkVisaStatus()">Check Status</button>
    </div>
  </div>

  <div class="hero-right">
    <div class="deco-ring"></div>
    <div class="deco-ring-sm"></div>
    <span class="deco-star s1">✦</span>
    <span class="deco-star s2">✦</span>
    <div class="bubble b1"><span class="bubble-icon">✅</span><div class="bubble-text"><strong>Visa Valid</strong><span>Sri Lanka · Today</span></div></div>
    <div class="bubble b2"><span class="bubble-icon">🌍</span><div class="bubble-text"><strong><?= count($visaCountries) ?>+ Countries</strong><span>Worldwide coverage</span></div></div>
    <div class="bubble b3"><span class="bubble-dot"></span><div class="bubble-text"><strong>Expert Support</strong><span>24/7 assistance</span></div></div>
    <div class="flag-ribbon">🇬🇧 London Office</div>
    <div class="hero-person">
      <div class="person-svg-wrap">
        <img src="images/plane.jpg" alt="Visa consultant" class="hero-real-photo" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"/>
        <span class="person-emoji" style="display:none">🧑‍💼</span>
      </div>
    </div>
  </div>
</section>

<!-- YOUR VISA APPLICATIONS -->
<section class="visa-status-section">
  <svg class="sec-bg-svg" viewBox="0 0 1400 200" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs><style>.vs-line{fill:none;stroke:rgba(26,46,90,0.07);stroke-width:1.2}</style>
      <g id="vplane"><path d="M0,-5 L12,0 L0,4 L1.5,0 Z" fill="rgba(26,46,90,0.12)"/><path d="M3.5,-1.5 L8,-6 L9,-5 L5,0 Z" fill="rgba(26,46,90,0.12)"/><path d="M3.5,1.5 L8,6 L9,5 L5,0 Z" fill="rgba(26,46,90,0.12)"/></g>
    </defs>
    <path d="M0,60 Q350,30 700,65 Q1050,100 1400,60" class="vs-line"/>
    <g transform="translate(120,50) rotate(10) scale(1.8)"><use href="#vplane"/></g>
    <g transform="translate(900,80) rotate(-8) scale(2)"><use href="#vplane"/></g>
  </svg>
  <div class="section-label">My Applications</div>
  <h2 class="section-title">Your Visa Applications</h2>
  <p class="section-sub">Select a country above and click <strong>Check Status</strong> to see your visa eligibility result below.</p>
  <div class="visa-result" id="visaResult"></div>
</section>

<!-- SUBSIDIARIES -->
<section class="subsidiaries dot-bg">
  <svg class="sec-bg-svg" viewBox="0 0 1400 500" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs><style>.sb-line{fill:none;stroke:rgba(26,46,90,0.07);stroke-width:1.2}</style>
      <g id="splane"><path d="M0,-5 L12,0 L0,4 L1.5,0 Z" fill="rgba(26,46,90,0.11)"/><path d="M3.5,-1.5 L8,-6 L9,-5 L5,0 Z" fill="rgba(26,46,90,0.11)"/><path d="M3.5,1.5 L8,6 L9,5 L5,0 Z" fill="rgba(26,46,90,0.11)"/></g>
    </defs>
    <path d="M0,250 Q350,180 700,260 Q1050,340 1400,250" class="sb-line"/>
    <g transform="translate(800,50) rotate(12) scale(2.2)"><use href="#splane"/></g>
    <g transform="translate(200,80) rotate(5) scale(1.6)"><use href="#splane"/></g>
  </svg>
  <div class="subsidiaries-inner">
    <div class="sub-img-wrap">
      <div class="sub-img">
        <img src="images/visalady.jpg" alt="A-Squared International Consultants" class="sub-real-photo" onerror="this.style.display='none'"/>
        <div class="sub-img-badge">
          <span class="sub-img-badge-dot"></span>
          <div class="sub-img-badge-text">
            <strong>A-Squared</strong>
            <span>Trusted by 10,000+ clients</span>
          </div>
        </div>
      </div>
      <div class="sub-img-deco"></div>
    </div>
    <div class="sub-text">
      <div class="section-label">Our Subsidiaries</div>
      <h2 class="section-title">A-Squared<br>International Consultants</h2>
      <span class="sub-name">Global Visa &amp; Immigration Advisory</span>
      <p>A-Squared International Consultants provides comprehensive visa consultation and immigration mobility solutions. The division specialises in student recruitment, work migration, family reunification, and investment pathways.</p>
      <ul class="spec-list">
        <li><span class="check-icon">✓</span> Student Recruitment</li>
        <li><span class="check-icon">✓</span> Work Migration</li>
        <li><span class="check-icon">✓</span> Family Reunification</li>
        <li><span class="check-icon">✓</span> Investment Pathways</li>
      </ul>
    </div>
  </div>
</section>

<!-- VISA TYPES -->
<section class="visa-types">
  <div class="visa-types-header">
    <div class="section-label">What We Offer</div>
    <h2 class="section-title">Visa Categories</h2>
    <p class="section-sub" style="margin:.5rem auto 0;text-align:center;">Choose the right visa pathway for your journey</p>
  </div>
  <div class="cards-grid">
    <div class="visa-card"><div class="visa-card-img student">🎓</div><div class="visa-card-body"><div><h3>Student Visa</h3><p>A student visa is an official permit that allows a person to stay in another country temporarily for the purpose of residence at a school, college, or university.</p></div></div></div>
    <div class="visa-card"><div class="visa-card-img work">💼</div><div class="visa-card-body"><div><h3>Work Visa</h3><p>A work visa is an official document that allows a person to live and work legally in another country for a specific period of time.</p></div></div></div>
    <div class="visa-card"><div class="visa-card-img family">👨‍👩‍👧</div><div class="visa-card-body"><div><h3>Family Visa</h3><p>A family visa is a type of visa that allows family members to join and live with their relatives in another country.</p></div></div></div>
    <div class="visa-card"><div class="visa-card-img business">📈</div><div class="visa-card-body"><div><h3>Investment &amp; Business Visa</h3><p>A business &amp; investment visa permits an individual to enter a country to start or invest money in or start and manage a business.</p></div></div></div>
  </div>
</section>

<!-- ══════════════════════════════════════════════
     COUNTRY VISA DETAILS — Dynamic from Firestore
     ══════════════════════════════════════════════ -->
<section class="country-details-section">
  <svg class="sec-bg-svg" viewBox="0 0 1400 800" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs><style>.cd-line{fill:none;stroke:rgba(26,46,90,0.065);stroke-width:1.2}</style>
      <g id="cdplane"><path d="M0,-5 L12,0 L0,4 L1.5,0 Z" fill="rgba(26,46,90,0.09)"/><path d="M3.5,-1.5 L8,-6 L9,-5 L5,0 Z" fill="rgba(26,46,90,0.09)"/><path d="M3.5,1.5 L8,6 L9,5 L5,0 Z" fill="rgba(26,46,90,0.09)"/></g>
    </defs>
    <path d="M0,100 Q350,70 700,105 Q1050,140 1400,100" class="cd-line"/>
    <path d="M0,700 Q350,670 700,705 Q1050,740 1400,700" class="cd-line" opacity=".5"/>
    <g transform="translate(150,80) rotate(10) scale(1.8)"><use href="#cdplane"/></g>
    <g transform="translate(1200,60) rotate(-8) scale(2)"><use href="#cdplane"/></g>
  </svg>

  <div class="country-details-header">
    <div class="section-label">Visa Intelligence</div>
    <h2 class="section-title">Country-by-Country Visa Guide</h2>
    <p class="section-sub">Detailed immigration systems, pathways, and ground realities for every major destination country.</p>
  </div>

  <?php if (empty($visaCountries)): ?>
    <div class="no-countries-msg">
      <p>🌍 No country visa guides available yet. Check back soon.</p>
    </div>
  <?php else: ?>

  <!-- ── TAB BUBBLES ── -->
  <div class="country-tabs">
    <?php foreach ($visaCountries as $i => $vc):
      $pid   = panelId($vc['countryCode']);
      $flag  = htmlspecialchars($vc['flagEmoji'] ?: '🌍');
      $name  = htmlspecialchars($vc['countryName']);
      $code  = strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $vc['countryCode']), 0, 2));
    ?>
    <button class="ctab-btn <?= $i === 0 ? 'active' : '' ?>"
            onclick="showCountryDyn('<?= $pid ?>', this)">
      <?php if ($vc['flagEmoji']): ?>
        <span class="tab-flag"><?= $flag ?></span>
      <?php else: ?>
        <span class="tab-flag" style="font-size:11px;font-weight:800;font-family:sans-serif"><?= htmlspecialchars($code) ?></span>
      <?php endif; ?>
      <?= $name ?>
    </button>
    <?php endforeach; ?>
  </div>

  <!-- ── COUNTRY PANELS ── -->
  <?php foreach ($visaCountries as $i => $vc):
    $pid      = panelId($vc['countryCode']);
    $flag     = htmlspecialchars($vc['flagEmoji'] ?: '');
    $code     = strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $vc['countryCode']), 0, 2));
    $badges   = $vc['badges'] ?? [];
    $pathway  = $vc['visaPathway'] ?? [];
    $reality  = $vc['groundRealityPoints'] ?? [];
    $visaTypes = $vc['visaTypes'] ?? [];
    $badgeColorKeys = ['blue','green','red','yellow','navy','teal','purple'];
  ?>
  <div class="country-panel <?= $i === 0 ? 'active' : '' ?>" id="<?= $pid ?>">

    <!-- Header card -->
    <div class="country-panel-header">
      <?php if ($flag): ?>
        <span class="cph-flag"><?= $flag ?></span>
      <?php else: ?>
        <div class="cph-flag-initials"><?= htmlspecialchars($code) ?></div>
      <?php endif; ?>
      <div class="cph-info">
        <h2><?= htmlspecialchars($vc['countryName']) ?></h2>
        <?php if (!empty($vc['description'])): ?>
        <p><?= htmlspecialchars($vc['description']) ?></p>
        <?php endif; ?>
        <?php if (!empty($badges)): ?>
        <div class="cph-badges">
          <?php foreach ($badges as $bi => $badge): ?>
          <span class="cph-badge <?= $badgeColorKeys[$bi % count($badgeColorKeys)] ?>"><?= htmlspecialchars($badge) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Visa Type detail cards -->
    <?php if (!empty($visaTypes)): ?>
    <div class="info-grid">
      <?php foreach ($visaTypes as $vti => $vt): ?>
      <div class="vt-info-card">
        <div class="vt-info-card-header">
          <div class="vt-icon-wrap c<?= $vti % 7 ?>">
            <?= htmlspecialchars($vt['icon'] ?: '📋') ?>
          </div>
          <h4><?= htmlspecialchars($vt['type']) ?></h4>
        </div>
        <?php if (!empty($vt['details'])): ?>
          <?php foreach ($vt['details'] as $detail): ?>
          <div class="vt-detail-line"><?= htmlspecialchars($detail) ?></div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Pathway bar -->
    <?php if (!empty($pathway)): ?>
    <div class="pathway-bar">
      <h4>🗺️ Most Common Pathway</h4>
      <div class="pathway-steps">
        <?php foreach ($pathway as $pi => $step): ?>
          <span class="pathway-step"><?= htmlspecialchars($step) ?></span>
          <?php if ($pi < count($pathway) - 1): ?><span class="pathway-arrow">→</span><?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Ground reality box -->
    <?php if (!empty($reality)): ?>
    <div class="reality-box">
      <span class="reality-icon">⚡</span>
      <div class="reality-content">
        <h4>Ground Reality</h4>
        <ul class="reality-bullets">
          <?php foreach ($reality as $point): ?>
          <li><?= htmlspecialchars($point) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
    <?php endif; ?>

  </div><!-- /country-panel -->
  <?php endforeach; ?>

  <?php endif; ?>
</section>

<!-- PARTNER UNIVERSITIES -->
<section class="universities-section dot-bg">
  <div class="universities-header">
    <div class="section-label">University Partnerships</div>
    <h2 class="section-title">Our Partner Institutions</h2>
    <p class="section-sub" style="margin:.5rem auto 0;text-align:center;max-width:560px;">A-Squared collaborates with internationally recognised universities to facilitate smooth and compliant student visa processing.</p>
  </div>
  <div class="uni-grid">
    <div class="uni-card"><span class="uni-flag">🇬🇧</span><div class="uni-name">University of London</div><div class="uni-country">United Kingdom</div><span class="uni-rank">QS Top 100</span></div>
    <div class="uni-card"><span class="uni-flag">🇦🇺</span><div class="uni-name">University of Melbourne</div><div class="uni-country">Australia</div><span class="uni-rank">QS Top 50</span></div>
    <div class="uni-card"><span class="uni-flag">🇨🇦</span><div class="uni-name">University of Toronto</div><div class="uni-country">Canada</div><span class="uni-rank">QS Top 30</span></div>
    <div class="uni-card"><span class="uni-flag">🇩🇪</span><div class="uni-name">TU Munich</div><div class="uni-country">Germany</div><span class="uni-rank">QS Top 50</span></div>
    <div class="uni-card"><span class="uni-flag">🇸🇬</span><div class="uni-name">NUS Singapore</div><div class="uni-country">Singapore</div><span class="uni-rank">QS Top 20</span></div>
    <div class="uni-card"><span class="uni-flag">🇳🇿</span><div class="uni-name">Univ. of Auckland</div><div class="uni-country">New Zealand</div><span class="uni-rank">QS Top 100</span></div>
    <div class="uni-card"><span class="uni-flag">🇫🇷</span><div class="uni-name">Sorbonne University</div><div class="uni-country">France</div><span class="uni-rank">QS Top 80</span></div>
    <div class="uni-card"><span class="uni-flag">🇦🇪</span><div class="uni-name">American Univ. Dubai</div><div class="uni-country">UAE</div><span class="uni-rank">Regional Top 10</span></div>
  </div>
  <p class="uni-note">🤝 <strong>40+ partner institutions</strong> worldwide — and growing every year.</p>
</section>

<!-- CTA BANNER -->
<section class="cta-banner">
  <svg class="sec-bg-svg" viewBox="0 0 1400 220" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs><style>.cb-line{fill:none;stroke:rgba(255,255,255,0.07);stroke-width:1.2}</style>
      <g id="cplane"><path d="M0,-5 L12,0 L0,4 L1.5,0 Z" fill="rgba(255,255,255,0.12)"/></g>
    </defs>
    <ellipse cx="1250" cy="110" rx="180" ry="110" class="cb-line"/>
    <ellipse cx="1250" cy="110" rx="120" ry="110" class="cb-line" opacity=".7"/>
    <path d="M0,55 Q350,30 700,60 Q1000,90 1100,70" class="cb-line"/>
    <g transform="translate(180,40) rotate(12) scale(2)"><use href="#cplane"/></g>
    <g transform="translate(520,180) rotate(-8) scale(1.8)"><use href="#cplane"/></g>
    <g transform="translate(900,35) rotate(6) scale(1.6)"><use href="#cplane"/></g>
  </svg>
  <div class="cta-banner-text">
    <div class="section-label" style="color:rgba(255,255,255,0.5);margin-bottom:.4rem;">Ready to Start?</div>
    <h2>Begin Your Journey with <em>Global RX</em></h2>
    <p>Applications are open. Speak with our advisors today and take the first step towards your international future. For More information :</p>
  </div>
  <button class="btn-cta" onclick="window.location='contactus.html'">Contact US →</button>
</section>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="fn-logo">GLOBAL <span>RX</span></span>
        <p>Empowering individuals through education, language mastery, and international visa opportunities.</p>
        <div class="social-links">
          <a href="#">f</a><a href="#">in</a><a href="#">𝕏</a><a href="#">▶</a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Pages</h4>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="index.html#about">About Us</a></li>
          <li><a href="contactus.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Subsidiaries</h4>
        <ul>
          <li><a href="visa.php">A² Visa Consultation</a></li>
          <li><a href="education.html">A² Higher Education</a></li>
          <li><a href="english.html">A² English Academy</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact</h4>
        <ul>
          <li><span>info@globalrx.com</span></li>
          <li><span>+44 (0) 000 000 0000</span></li>
          <li><span>London, United Kingdom</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© <?= date('Y') ?> Global RX Business LTD. All rights reserved.</span>
      <div class="footer-dots">
        <div class="fdot" style="background:var(--red)"></div>
        <div class="fdot" style="background:var(--green)"></div>
        <div class="fdot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
/* ── Nav scroll shadow ── */
const nav = document.getElementById('mainNav');
window.addEventListener('scroll', () => {
  nav.style.boxShadow = window.scrollY > 40
    ? '0 8px 32px rgba(0,0,0,0.14)'
    : '0 4px 24px rgba(0,0,0,0.06)';
});

/* ── Divisions dropdown ── */
function toggleDropdown() {
  document.getElementById('divDropdown').classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('divDropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});

/* ── Visa status checker ── */
function checkVisaStatus() {
  const countrySelect = document.getElementById('visaCountry');
  const typeSelect    = document.getElementById('visaType');
  const dateInput     = document.getElementById('visaDate');
  const resultDiv     = document.getElementById('visaResult');

  document.querySelector('.visa-status-section').scrollIntoView({ behavior: 'smooth', block: 'start' });

  if (!countrySelect.value) {
    resultDiv.innerHTML = `<div class="no-result-msg">⚠️ Please select a country to check visa status.</div>`;
    resultDiv.classList.add('show');
    return;
  }

  const selectedOption = countrySelect.options[countrySelect.selectedIndex];
  const flag    = selectedOption.getAttribute('data-flag') || '🌍';
  const name    = selectedOption.getAttribute('data-name') || countrySelect.value;
  const isValid = selectedOption.getAttribute('data-valid') === 'true';
  const type    = typeSelect.value ? typeSelect.options[typeSelect.selectedIndex].text : 'General Visa';
  const date    = dateInput.value
    ? new Date(dateInput.value).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })
    : 'N/A';
  const appCode = name.slice(0,2).toUpperCase() + '-<?= date('Y') ?>-'
    + Math.abs(name.split('').reduce((a,c) => a + c.charCodeAt(0), 0) * 37).toString().slice(-6);

  if (isValid) {
    resultDiv.innerHTML = `
      <div class="application-card valid">
        <span class="flag">${flag}</span>
        <div class="app-info">
          <strong>${name}</strong>
          <span>${type}</span>
          <div class="app-meta">Application #${appCode} &nbsp;·&nbsp; Date: ${date}</div>
        </div>
        <span class="status-pill valid">✓ Valid</span>
      </div>`;
  } else {
    resultDiv.innerHTML = `
      <div class="application-card invalid">
        <span class="flag">${flag}</span>
        <div class="app-info">
          <strong>${name}</strong>
          <span>${type}</span>
          <div class="app-meta">Application #${appCode} &nbsp;·&nbsp; Date: ${date}</div>
        </div>
        <span class="status-pill invalid">✗ Not Valid</span>
      </div>`;
  }
  resultDiv.classList.add('show');
}

/* ── Dynamic country tab switcher ── */
function showCountryDyn(panelId, btn) {
  document.querySelectorAll('.country-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.ctab-btn').forEach(b => b.classList.remove('active'));
  const panel = document.getElementById(panelId);
  if (panel) panel.classList.add('active');
  if (btn) btn.classList.add('active');
}

/* ── Smooth anchor scroll ── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    const t = document.querySelector(a.getAttribute('href'));
    if (t) t.scrollIntoView({ behavior: 'smooth' });
  });
});
</script>
</body>
</html>
