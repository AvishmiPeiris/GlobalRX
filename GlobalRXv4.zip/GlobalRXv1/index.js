 // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const t = document.querySelector(a.getAttribute('href'));
      if(t) t.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Nav shadow
  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 8px 32px rgba(0,0,0,0.14)'
      : '0 4px 24px rgba(0,0,0,0.06)';
  });

  // Dropdown
  function toggleDropdown() {
    document.getElementById('divDropdown').classList.toggle('open');
  }
  document.addEventListener('click', e => {
    const dd = document.getElementById('divDropdown');
    if (!dd.contains(e.target)) dd.classList.remove('open');
  });

  // Count-up animation
  function animateCount(el, target, duration) {
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        el.textContent = target;
        clearInterval(timer);
      } else {
        el.textContent = Math.floor(start);
      }
    }, 16);
  }

  // Trigger when stats bar enters viewport
  let animated = false;
  const statsBar = document.getElementById('statsBar');
  const items = statsBar.querySelectorAll('.stats-bar-item');
  const numbers = statsBar.querySelectorAll('.stat-number');

  const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && !animated) {
      animated = true;

      // Stagger fade-in of items
      items.forEach((item, i) => {
        setTimeout(() => item.classList.add('visible'), i * 120);
      });

      // Count up each number
      numbers.forEach((el, i) => {
        const target = parseInt(el.dataset.target);
        setTimeout(() => animateCount(el, target, 1400), i * 120);
      });
    }
  }, { threshold: 0.3 });

  observer.observe(statsBar);