<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'CourseManager.php';
require_once 'EnrollmentManager.php';

$courseManager     = new CourseManager();
$enrollmentManager = new EnrollmentManager();

$message     = '';
$messageType = '';

/* ══════════════════════════════════════════════
   HANDLE FORM SUBMISSIONS
   ══════════════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    switch ($_POST['action']) {

        case 'add_course':
            $r = $courseManager->addCourse(
                trim($_POST['course_id']   ?? ''),
                trim($_POST['cname']       ?? ''),
                trim($_POST['type']        ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['iconUrl']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_course':
            $r = $courseManager->updateCourse(
                trim($_POST['course_id']   ?? ''),
                trim($_POST['cname']       ?? ''),
                trim($_POST['type']        ?? ''),
                trim($_POST['description'] ?? ''),
                trim($_POST['iconUrl']     ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_course':
            $r = $courseManager->deleteCourse(trim($_POST['course_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'add_enrollment':
            $r = $enrollmentManager->addEnrollment(
                trim($_POST['fullName'] ?? ''),
                trim($_POST['email']   ?? ''),
                trim($_POST['age']     ?? ''),
                trim($_POST['location']?? ''),
                trim($_POST['phone']   ?? ''),
                trim($_POST['course']  ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'update_enrollment':
            $r = $enrollmentManager->updateEnrollment(
                trim($_POST['enrollment_id'] ?? ''),
                trim($_POST['fullName']      ?? ''),
                trim($_POST['email']         ?? ''),
                trim($_POST['age']           ?? ''),
                trim($_POST['location']      ?? ''),
                trim($_POST['phone']         ?? ''),
                trim($_POST['course']        ?? ''),
                trim($_POST['status']        ?? ''),
                trim($_POST['result']        ?? '')
            );
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;

        case 'delete_enrollment':
            $r = $enrollmentManager->deleteEnrollment(trim($_POST['enrollment_id'] ?? ''));
            $message = $r['message']; $messageType = $r['success'] ? 'success' : 'error';
            break;
    }
}

/* ══════════════════════════════════════════════
   FETCH LIVE DATA FROM FIRESTORE
   ══════════════════════════════════════════════ */
$coursesResult    = $courseManager->getAllCourses();
$courses          = $coursesResult['success']     ? $coursesResult['courses']         : [];
$coursesError     = $coursesResult['success']     ? ''                                : ($coursesResult['message']     ?? 'Could not load courses.');

$enrollmentsResult = $enrollmentManager->getAllEnrollments();
$enrollments       = $enrollmentsResult['success'] ? $enrollmentsResult['enrollments'] : [];
$enrollmentsError  = $enrollmentsResult['success'] ? ''                                : ($enrollmentsResult['message'] ?? 'Could not load enrollments.');

/* Status counts */
$statusCounts = ['Pending' => 0, 'Under Review' => 0, 'Approved' => 0, 'Rejected' => 0];
foreach ($enrollments as $e) {
    $s = $e['status'] ?? 'Pending';
    isset($statusCounts[$s]) ? $statusCounts[$s]++ : ($statusCounts[$s] = 1);
}

$statusBadge = [
    'Pending'      => 'badge-gold',
    'Under Review' => 'badge-blue',
    'Approved'     => 'badge-green',
    'Rejected'     => 'badge-red',
];
$statusColors = [
    'Pending'      => 'var(--gold)',
    'Under Review' => 'var(--blue)',
    'Approved'     => 'var(--green-dark)',
    'Rejected'     => 'var(--red)',
];

/* Build course options for the add-enrollment dropdown */
$courseOptions = array_map(fn($c) => htmlspecialchars($c['cname']), $courses);
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link href="admin.css" rel="stylesheet">
<style>
  .error-banner {
    background: #fff3cd; border: 1.5px solid #ffc107;
    border-radius: 8px; padding: 11px 15px; font-size: 12px;
    color: #856404; margin-bottom: 14px;
  }
  .enroll-search {
    border: 1.5px solid #dce8e3; border-radius: 8px;
    padding: 5px 11px; font-size: 11.5px; font-family: inherit;
    outline: none; width: 220px; color: var(--text-dark);
    background: #fff;
  }
  .enroll-search:focus { border-color: var(--gold); }
  tr.row-hidden { display: none !important; }

  /* ── Add Enrollment modal field errors ── */
  .ae-field-error {
    font-size: 11px; color: #e05c5c;
    margin-top: 3px; display: block; min-height: 14px;
  }
  .ae-invalid { border-color: #e05c5c !important; box-shadow: 0 0 0 3px rgba(224,92,92,.10) !important; }
</style>
</head>
<body>

<?php if ($message): ?>
<div id="php-toast" style="position:fixed;top:24px;right:24px;z-index:99999;
  padding:14px 22px;border-radius:10px;font-size:13px;font-weight:500;
  box-shadow:0 4px 20px rgba(0,0,0,.15);
  background:<?= $messageType==='success'?'#d4edda':'#f8d7da' ?>;
  color:<?= $messageType==='success'?'#155724':'#721c24' ?>;">
  <?= htmlspecialchars($message) ?>
</div>
<script>setTimeout(()=>{ const t=document.getElementById('php-toast'); if(t)t.remove(); }, 4000);</script>
<?php endif; ?>

<div class="app-shell">

  <!-- SIDEBAR -->
  <div id="sidebar">
    <div class="sidebar-profile">
      <div class="avatar-wrap">A<div class="avatar-dot"></div></div>
      <div class="profile-name">Admin Johnson</div>
      <div class="profile-role">Super Administrator</div>
    </div>
    <div class="sidebar-label">Main Menu</div>
    <div class="nav-item active" onclick="navigate('dashboard',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
        <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
      </svg>Dashboard
    </div>
    <div class="nav-item" onclick="navigate('academics',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
      </svg>Academic Programs<span class="nav-badge">3</span>
    </div>
    <div class="nav-item" onclick="navigate('scholarships',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/>
      </svg>Scholarships<span class="nav-badge">5</span>
    </div>
    <div class="nav-item" onclick="navigate('feedback',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>Feedback<span class="nav-badge">8</span>
    </div>
    <div class="nav-item" onclick="navigate('visa',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M7 15h2M12 15h5"/>
      </svg>Visa Management
    </div>
    <div class="nav-item" onclick="navigate('enrollment',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>Enrollment
      <span class="nav-badge"><?= count($enrollments) ?></span>
    </div>
    <div class="nav-item" onclick="navigate('employees',this)">
      <svg class="nav-icon" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/>
        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
      </svg>Employee Mgmt
    </div>
    <div class="sidebar-bottom">
      <div class="logout-btn">
        <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>
        </svg>Sign Out
      </div>
    </div>
  </div>

  <!-- MAIN -->
  <div id="main">
    <div class="topbar">
      <div class="topbar-left">
        <div class="page-title" id="pageTitle">Dashboard Overview</div>
        <div class="breadcrumb" id="breadcrumb">Admin → Dashboard</div>
      </div>
      <div class="topbar-right">
        <div class="search-bar">
          <svg width="12" height="12" fill="none" stroke="#8aa898" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input placeholder="Search anything…">
        </div>
        <div class="icon-btn">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
          <div class="notif-dot"></div>
        </div>
        <div class="icon-btn">
          <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/>
          </svg>
        </div>
      </div>
    </div>

    <div class="page-scroll">

      <!-- ══════════ DASHBOARD ══════════ -->
      <div id="page-dashboard" class="page active">
        <div class="stats-row">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">🎓</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($enrollments) ?></div><div class="stat-label">Total Enrollments</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">📚</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($courses) ?></div><div class="stat-label">Active Courses</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div><div class="stat-val"><?= $statusCounts['Pending'] ?></div><div class="stat-label">Pending</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val"><?= $statusCounts['Approved'] ?></div><div class="stat-label">Approved</div></div>
        </div>
        <div class="dash-grid">
          <div class="dash-card">
            <div class="dash-card-title">📋 Recent Enrollments</div>
            <?php if ($enrollmentsError): ?>
              <div class="error-banner">⚠️ <?= htmlspecialchars($enrollmentsError) ?></div>
            <?php elseif (!empty($enrollments)): ?>
              <?php foreach (array_slice($enrollments, 0, 5) as $e): ?>
              <div class="activity-item">
                <div class="activity-dot" style="background:#5bc98a"></div>
                <div>
                  <div class="activity-text"><strong><?= htmlspecialchars($e['fullName']) ?></strong> → <?= htmlspecialchars($e['course']) ?></div>
                  <div class="activity-time"><?= htmlspecialchars($e['createdAt']) ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div style="color:#999;font-size:12px;padding:10px 0">No enrollments yet.</div>
            <?php endif; ?>
          </div>
          <div class="dash-card">
            <div class="dash-card-title">📊 Enrollment Status Breakdown</div>
            <?php $total = max(count($enrollments), 1); ?>
            <?php foreach ($statusCounts as $status => $count): ?>
            <div class="progress-item">
              <div class="progress-label"><span><?= $status ?></span><span style="font-weight:600"><?= $count ?></span></div>
              <div class="progress-bar"><div class="progress-fill" style="width:<?= round($count/$total*100) ?>%;background:<?= $statusColors[$status] ?? '#ccc' ?>"></div></div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="dash-card">
            <div class="dash-card-title">🌍 Visa Applications</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <div style="background:#e8f5ee;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2d7a4f">42</div><div style="font-size:10px;color:#2d7a4f;margin-top:2px">Approved</div></div>
              <div style="background:#fdf3dc;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#956c10">18</div><div style="font-size:10px;color:#956c10;margin-top:2px">Pending</div></div>
              <div style="background:#fce8e8;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#c0392b">7</div><div style="font-size:10px;color:#c0392b;margin-top:2px">Rejected</div></div>
              <div style="background:#e8f0fb;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2155a3">23</div><div style="font-size:10px;color:#2155a3;margin-top:2px">Under Review</div></div>
            </div>
          </div>
          <div class="dash-card">
            <div class="dash-card-title">🎓 Programs Summary</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
              <div style="background:#e8f5ee;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2d7a4f"><?= count($courses) ?></div><div style="font-size:10px;color:#2d7a4f;margin-top:2px">Courses</div></div>
              <div style="background:#fdf3dc;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#956c10">24</div><div style="font-size:10px;color:#956c10;margin-top:2px">Degrees</div></div>
              <div style="background:#e8f0fb;border-radius:8px;padding:12px;text-align:center"><div style="font-size:20px;font-weight:700;color:#2155a3">31</div><div style="font-size:10px;color:#2155a3;margin-top:2px">Diplomas</div></div>
            </div>
            <div style="margin-top:12px;padding:10px;background:var(--cream);border-radius:8px;font-size:11px;color:var(--text-mid)">
              <strong><?= count($courses) ?></strong> courses · <strong><?= count($enrollments) ?></strong> enrollments — live from Firestore
            </div>
          </div>
        </div>
      </div>

      <!-- ══════════ ACADEMIC PROGRAMS ══════════ -->
      <div id="page-academics" class="page">
        <div class="stats-row" style="grid-template-columns:repeat(3,1fr)">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">📚</div><span class="stat-trend trend-up">Live</span></div><div class="stat-val"><?= count($courses) ?></div><div class="stat-label">Total Courses</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">🎓</div></div><div class="stat-val">24</div><div class="stat-label">Degree Programs</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">📜</div></div><div class="stat-val">31</div><div class="stat-label">Diploma Programs</div></div>
        </div>
        <div class="sub-tabs">
          <div class="sub-tab active" onclick="switchTab('courses',this)">📚 Course Management <span class="tab-count"><?= count($courses) ?></span></div>
          <div class="sub-tab" onclick="switchTab('degrees',this)">🎓 Degree Management <span class="tab-count">24</span></div>
          <div class="sub-tab" onclick="switchTab('diplomas',this)">📜 Diploma Management <span class="tab-count">31</span></div>
        </div>

        <div id="subtab-courses" class="sub-panel active">
          <div class="section-header">
            <div><div class="section-title">Course Management</div><div class="section-sub">Live from Firestore</div></div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-outline btn-sm">⬇ Export</button>
              <button class="btn btn-primary" onclick="openCourseAdd()">＋ Add Course</button>
            </div>
          </div>
          <?php if ($coursesError): ?><div class="error-banner">⚠️ <?= htmlspecialchars($coursesError) ?></div><?php endif; ?>
          <div class="table-wrap">
            <div class="table-toolbar">
              <span class="filter-chip active" onclick="chipActive(this)">All</span>
              <div style="margin-left:auto"><button class="btn btn-outline btn-sm">🔍 Filter</button></div>
            </div>
            <div style="overflow-x:auto">
              <table>
                <thead><tr><th>Course Name</th><th>Type</th><th>Description</th><th>Icon</th><th>Actions</th></tr></thead>
                <tbody>
                  <?php if (!empty($courses)): ?>
                    <?php foreach ($courses as $c): ?>
                    <tr>
                      <td>
                        <div class="cell-with-avatar">
                          <div class="avatar-sm" style="background:#4a7fb5;color:#fff"><?= strtoupper(substr($c['cname'],0,2)) ?></div>
                          <div><div style="font-weight:600"><?= htmlspecialchars($c['cname']) ?></div><div class="cell-sub"><?= htmlspecialchars($c['id']) ?></div></div>
                        </div>
                      </td>
                      <td><span class="badge badge-blue"><?= htmlspecialchars($c['type']) ?></span></td>
                      <td style="max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($c['description']) ?></td>
                      <td><?php if (!empty($c['iconUrl'])): ?><img src="<?= htmlspecialchars($c['iconUrl']) ?>" style="width:32px;height:32px;object-fit:contain;border-radius:4px;"><?php else: ?><span class="badge badge-gray">No icon</span><?php endif; ?></td>
                      <td>
                        <div class="action-group">
                          <button class="btn btn-outline btn-sm" onclick="openCourseEdit('<?= htmlspecialchars($c['id'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['cname'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['type'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['description'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['iconUrl'],ENT_QUOTES) ?>')">✏️ Edit</button>
                          <form method="POST" style="display:inline" onsubmit="return confirm('Delete \'<?= htmlspecialchars($c['cname'],ENT_QUOTES) ?>\'?')">
                            <input type="hidden" name="action" value="delete_course">
                            <input type="hidden" name="course_id" value="<?= htmlspecialchars($c['id']) ?>">
                            <button type="submit" class="btn btn-danger btn-sm">🗑</button>
                          </form>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr><td colspan="5" style="text-align:center;padding:40px;color:#888">No courses yet. Click "＋ Add Course".</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
            <div class="pagination"><div class="page-info">Showing <?= count($courses) ?> record<?= count($courses)!==1?'s':'' ?></div></div>
          </div>
        </div>

        <div id="subtab-degrees" class="sub-panel">
          <div class="section-header">
            <div><div class="section-title">Degree Management</div><div class="section-sub">Manage degree programs</div></div>
            <div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm">⬇ Export</button><button class="btn btn-primary" onclick="openModal('degree-add')">＋ Add Degree</button></div>
          </div>
          <div class="table-wrap">
            <div class="table-toolbar">
              <span class="filter-chip active" onclick="chipActive(this)">All</span>
              <span class="filter-chip" onclick="chipActive(this)">Bachelor's</span>
              <span class="filter-chip" onclick="chipActive(this)">Master's</span>
              <span class="filter-chip" onclick="chipActive(this)">PhD</span>
              <div style="margin-left:auto"><button class="btn btn-outline btn-sm">🔍 Filter</button></div>
            </div>
            <div style="overflow-x:auto"><table><thead><tr><th>Degree Program</th><th>Level</th><th>Dept</th><th>Duration</th><th>Credits</th><th>Modules</th><th>Head</th><th>Enrolled</th><th>Status</th><th>Actions</th></tr></thead><tbody id="degrees-tbody"></tbody></table></div>
          </div>
        </div>

        <div id="subtab-diplomas" class="sub-panel">
          <div class="section-header">
            <div><div class="section-title">Diploma Management</div><div class="section-sub">Manage diploma programs</div></div>
            <div style="display:flex;gap:8px"><button class="btn btn-outline btn-sm">⬇ Export</button><button class="btn btn-primary" onclick="openModal('diploma-add')">＋ Add Diploma</button></div>
          </div>
          <div class="table-wrap">
            <div class="table-toolbar">
              <span class="filter-chip active" onclick="chipActive(this)">All</span>
              <span class="filter-chip" onclick="chipActive(this)">Professional</span>
              <span class="filter-chip" onclick="chipActive(this)">Technical</span>
              <div style="margin-left:auto"><button class="btn btn-outline btn-sm">🔍 Filter</button></div>
            </div>
            <div style="overflow-x:auto"><table><thead><tr><th>Diploma Program</th><th>Category</th><th>Dept</th><th>Duration</th><th>Delivery</th><th>Fee</th><th>Coordinator</th><th>Enrolled</th><th>Status</th><th>Actions</th></tr></thead><tbody id="diplomas-tbody"></tbody></table></div>
          </div>
        </div>
      </div>

      <!-- ══════════ SCHOLARSHIPS ══════════ -->
      <div id="page-scholarships" class="page">
        <div class="stats-row" style="grid-template-columns:repeat(3,1fr)">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">🏅</div></div><div class="stat-val">63</div><div class="stat-label">Active Scholarships</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">💰</div></div><div class="stat-val">$2.4M</div><div class="stat-label">Total Awarded</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">⏳</div></div><div class="stat-val">18</div><div class="stat-label">Pending Review</div></div>
        </div>
        <div class="section-header">
          <div><div class="section-title">Scholarship Management</div></div>
          <button class="btn btn-primary" onclick="openModal('scholarship-add')">＋ Add Scholarship</button>
        </div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="chipActive(this)">All</span><span class="filter-chip" onclick="chipActive(this)">Merit-Based</span><span class="filter-chip" onclick="chipActive(this)">Need-Based</span><div style="margin-left:auto"><button class="btn btn-outline btn-sm">⬇ Export</button></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>Scholarship Name</th><th>Type</th><th>Amount</th><th>Min GPA</th><th>Recipients</th><th>Deadline</th><th>Status</th><th>Actions</th></tr></thead><tbody id="scholarships-tbody"></tbody></table></div>
        </div>
      </div>

      <!-- ══════════ FEEDBACK ══════════ -->
      <div id="page-feedback" class="page">
        <div class="stats-row">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val">94</div><div class="stat-label">Resolved</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div><div class="stat-val">8</div><div class="stat-label">Open</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">🚨</div></div><div class="stat-val">3</div><div class="stat-label">Urgent</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">⭐</div></div><div class="stat-val">4.4</div><div class="stat-label">Avg Rating</div></div>
        </div>
        <div class="section-header">
          <div><div class="section-title">Feedback Management</div></div>
          <button class="btn btn-primary" onclick="openModal('feedback-add')">＋ Add Feedback</button>
        </div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="chipActive(this)">All</span><span class="filter-chip" onclick="chipActive(this)">Urgent</span><span class="filter-chip" onclick="chipActive(this)">Open</span><span class="filter-chip" onclick="chipActive(this)">Resolved</span><div style="margin-left:auto"><button class="btn btn-outline btn-sm">⬇ Export</button></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>Submitted By</th><th>Category</th><th>Subject</th><th>Rating</th><th>Date</th><th>Priority</th><th>Status</th><th>Actions</th></tr></thead><tbody id="feedback-tbody"></tbody></table></div>
        </div>
      </div>

      <!-- ══════════ VISA ══════════ -->
      <div id="page-visa" class="page">
        <div class="stats-row">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div><div class="stat-val">42</div><div class="stat-label">Approved</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">🔄</div></div><div class="stat-val">23</div><div class="stat-label">Under Review</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">❌</div></div><div class="stat-val">7</div><div class="stat-label">Rejected</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">📋</div></div><div class="stat-val">18</div><div class="stat-label">Pending Docs</div></div>
        </div>
        <div class="section-header">
          <div><div class="section-title">Visa Management</div></div>
          <button class="btn btn-primary" onclick="openModal('visa-add')">＋ New Application</button>
        </div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="chipActive(this)">All</span><span class="filter-chip" onclick="chipActive(this)">Student Visa</span><span class="filter-chip" onclick="chipActive(this)">Work Permit</span><div style="margin-left:auto"><button class="btn btn-outline btn-sm">⬇ Export</button></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>Applicant</th><th>Nationality</th><th>Visa Type</th><th>Destination</th><th>Applied</th><th>Expiry</th><th>Status</th><th>Actions</th></tr></thead><tbody id="visa-tbody"></tbody></table></div>
        </div>
      </div>

      <!-- ══════════════════════════════════════════════════
           ENROLLMENT — LIVE FROM FIREBASE / FIRESTORE
           ══════════════════════════════════════════════════ -->
      <div id="page-enrollment" class="page">

        <div class="stats-row" style="grid-template-columns:repeat(4,1fr)">
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">👩‍🎓</div><span class="stat-trend trend-up">Live</span></div>
            <div class="stat-val"><?= count($enrollments) ?></div>
            <div class="stat-label">Total Enrolled</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">⏳</div></div>
            <div class="stat-val"><?= $statusCounts['Pending'] ?></div>
            <div class="stat-label">Pending</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">✅</div></div>
            <div class="stat-val"><?= $statusCounts['Approved'] ?></div>
            <div class="stat-label">Approved</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:#fce8e8">❌</div></div>
            <div class="stat-val"><?= $statusCounts['Rejected'] ?></div>
            <div class="stat-label">Rejected</div>
          </div>
        </div>

        <div class="section-header">
          <div>
            <div class="section-title">Enrollment Management</div>
            <div class="section-sub">Live from Firestore — all records submitted via the enrollment form</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-outline btn-sm" onclick="exportEnrollCSV()">⬇ Export CSV</button>
            <button class="btn btn-outline btn-sm" onclick="window.location.reload()">🔄 Refresh</button>
            <!-- ══ ADD ENROLLMENT BUTTON ══ -->
            <button class="btn btn-primary" onclick="openAddEnrollment()">＋ Add Enrollment</button>
          </div>
        </div>

        <?php if ($enrollmentsError): ?>
          <div class="error-banner">
            ⚠️ <?= htmlspecialchars($enrollmentsError) ?><br>
            <small>Check that <code>config.php</code> has the correct FIREBASE_PROJECT_ID and FIREBASE_API_KEY, and that Firestore rules allow reads.</small>
          </div>
        <?php endif; ?>

        <div class="table-wrap">
          <div class="table-toolbar">
            <span class="filter-chip active" onclick="enrollFilter('all',this)">All</span>
            <span class="filter-chip" onclick="enrollFilter('Pending',this)">Pending</span>
            <span class="filter-chip" onclick="enrollFilter('Under Review',this)">Under Review</span>
            <span class="filter-chip" onclick="enrollFilter('Approved',this)">Approved</span>
            <span class="filter-chip" onclick="enrollFilter('Rejected',this)">Rejected</span>
            <div style="margin-left:auto">
              <input id="enroll-search" type="text" class="enroll-search"
                placeholder="🔍  Search name, email, course…"
                oninput="applyEnrollFilters()">
            </div>
          </div>

          <div style="overflow-x:auto">
            <table id="enrollment-table">
              <thead>
                <tr>
                  <th>Full Name</th><th>Email</th><th>Age</th><th>Location</th>
                  <th>Phone</th><th>Course</th><th>Result</th>
                  <th>Submitted</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody id="enrollment-tbody">
                <?php if (!empty($enrollments)): ?>
                  <?php foreach ($enrollments as $enr): ?>
                  <?php
                    $cls        = $statusBadge[$enr['status']] ?? 'badge-gray';
                    $initials   = strtoupper(mb_substr($enr['fullName'], 0, 2));
                    $searchData = strtolower($enr['fullName'].' '.$enr['email'].' '.$enr['course'].' '.$enr['location'].' '.$enr['phone']);
                  ?>
                  <tr data-status="<?= htmlspecialchars($enr['status']) ?>"
                      data-search="<?= htmlspecialchars($searchData) ?>">
                    <td>
                      <div class="cell-with-avatar">
                        <div class="avatar-sm" style="background:#3a9b8c;color:#fff"><?= $initials ?></div>
                        <div>
                          <div style="font-weight:600"><?= htmlspecialchars($enr['fullName']) ?></div>
                          <div class="cell-sub" title="<?= htmlspecialchars($enr['id']) ?>"><?= htmlspecialchars(substr($enr['id'],0,12)) ?>…</div>
                        </div>
                      </div>
                    </td>
                    <td style="font-size:12px"><?= htmlspecialchars($enr['email']) ?></td>
                    <td><?= htmlspecialchars($enr['age']) ?></td>
                    <td><?= htmlspecialchars($enr['location']) ?></td>
                    <td style="font-size:12px;white-space:nowrap"><?= htmlspecialchars($enr['phone']) ?></td>
                    <td style="max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="<?= htmlspecialchars($enr['course']) ?>"><?= htmlspecialchars($enr['course']) ?></td>
                    <td>
                      <?php if (!empty($enr['result'])): ?>
                        <a href="<?= htmlspecialchars($enr['result']) ?>" target="_blank" class="btn btn-outline btn-sm">📄 View</a>
                      <?php else: ?>
                        <span class="badge badge-gray">None</span>
                      <?php endif; ?>
                    </td>
                    <td style="font-size:11px;color:#888;white-space:nowrap"><?= htmlspecialchars($enr['createdAt']) ?></td>
                    <td><span class="badge <?= $cls ?>"><?= htmlspecialchars($enr['status']) ?></span></td>
                    <td>
                      <div class="action-group">
                        <button class="btn btn-outline btn-sm" onclick="openEnrollmentEdit(
                          '<?= htmlspecialchars($enr['id'],       ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['fullName'], ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['email'],    ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['age'],      ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['location'], ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['phone'],    ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['course'],   ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['status'],   ENT_QUOTES) ?>',
                          '<?= htmlspecialchars($enr['result'] ?? '', ENT_QUOTES) ?>'
                        )">✏️ Edit</button>
                        <form method="POST" style="display:inline"
                          onsubmit="return confirm('Delete enrollment for \'<?= htmlspecialchars($enr['fullName'],ENT_QUOTES) ?>\'?')">
                          <input type="hidden" name="action"        value="delete_enrollment">
                          <input type="hidden" name="enrollment_id" value="<?= htmlspecialchars($enr['id']) ?>">
                          <button type="submit" class="btn btn-danger btn-sm">🗑</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr id="empty-row">
                    <td colspan="10" style="text-align:center;padding:52px;color:#aaa">
                      <?php if ($enrollmentsError): ?>
                        ⚠️ Failed to load from Firestore.
                      <?php else: ?>
                        📭 No enrollments yet.<br>
                        <small style="font-size:11px">Students who submit the enrollment form will appear here automatically, or click "＋ Add Enrollment" to add one manually.</small>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <div class="pagination">
            <div class="page-info" id="enroll-count">
              <?= count($enrollments) ?> record<?= count($enrollments)!==1?'s':'' ?> total
            </div>
          </div>
        </div>
      </div><!-- /page-enrollment -->

      <!-- ══════════ EMPLOYEES ══════════ -->
      <div id="page-employees" class="page">
        <div class="stats-row">
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f5ee">👥</div></div><div class="stat-val">312</div><div class="stat-label">Total Staff</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fdf3dc">👨‍🏫</div></div><div class="stat-val">89</div><div class="stat-label">Faculty</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#e8f0fb">🔧</div></div><div class="stat-val">143</div><div class="stat-label">Admin Staff</div></div>
          <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#fce8e8">🏖️</div></div><div class="stat-val">12</div><div class="stat-label">On Leave</div></div>
        </div>
        <div class="section-header">
          <div><div class="section-title">Employee Management</div><div class="section-sub">Staff records and HR</div></div>
          <button class="btn btn-primary" onclick="openModal('employee-add')">＋ Add Employee</button>
        </div>
        <div class="table-wrap">
          <div class="table-toolbar"><span class="filter-chip active" onclick="chipActive(this)">All</span><span class="filter-chip" onclick="chipActive(this)">Faculty</span><span class="filter-chip" onclick="chipActive(this)">Administration</span><div style="margin-left:auto"><button class="btn btn-outline btn-sm">⬇ Export</button></div></div>
          <div style="overflow-x:auto"><table><thead><tr><th>Employee</th><th>Employee ID</th><th>Department</th><th>Role</th><th>Joined</th><th>Salary</th><th>Status</th><th>Actions</th></tr></thead><tbody id="employees-tbody"></tbody></table></div>
        </div>
      </div>

    </div><!-- /page-scroll -->
  </div><!-- /main -->
</div><!-- /app-shell -->

<!-- ══════════════════════════════════════════════════════
     ADD ENROLLMENT MODAL
     Fields: fullName, email, age, location, phone, course
     Submits to PHP → EnrollmentManager::addEnrollment()
     ══════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="add-enrollment-overlay" onclick="closeAddEnrollmentOutside(event)">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">＋ Add Enrollment</div>
      <button class="close-btn" onclick="closeAddEnrollment()">✕</button>
    </div>
    <form method="POST" id="add-enrollment-form" onsubmit="return validateAddEnrollment()">
      <div style="padding:24px">
        <input type="hidden" name="action" value="add_enrollment">
        <div class="form-grid">

          <!-- Full Name -->
          <div class="form-group full">
            <label>Full Name <span style="color:var(--red)">*</span></label>
            <input type="text" name="fullName" id="ae-fullName"
              placeholder="e.g. John Silva" autocomplete="off">
            <span class="ae-field-error" id="ae-err-fullName"></span>
          </div>

          <!-- Email -->
          <div class="form-group">
            <label>Email <span style="color:var(--red)">*</span></label>
            <input type="email" name="email" id="ae-email"
              placeholder="e.g. john@email.com" autocomplete="off">
            <span class="ae-field-error" id="ae-err-email"></span>
          </div>

          <!-- Age -->
          <div class="form-group">
            <label>Age <span style="color:var(--red)">*</span></label>
            <input type="number" name="age" id="ae-age"
              placeholder="e.g. 22" min="10" max="99">
            <span class="ae-field-error" id="ae-err-age"></span>
          </div>

          <!-- Location -->
          <div class="form-group">
            <label>Location <span style="color:var(--red)">*</span></label>
            <input type="text" name="location" id="ae-location"
              placeholder="e.g. Colombo, Sri Lanka" autocomplete="off">
            <span class="ae-field-error" id="ae-err-location"></span>
          </div>

          <!-- Phone -->
          <div class="form-group">
            <label>Phone <span style="color:var(--red)">*</span></label>
            <input type="text" name="phone" id="ae-phone"
              placeholder="e.g. +94 77 123 4567" autocomplete="off">
            <span class="ae-field-error" id="ae-err-phone"></span>
          </div>

          <!-- Course — shows Firestore courses if available, else free text -->
          <div class="form-group full">
            <label>Course / Degree <span style="color:var(--red)">*</span></label>
            <?php if (!empty($courses)): ?>
              <select name="course" id="ae-course">
                <option value="" disabled selected>Select a course…</option>
                <?php foreach ($courses as $c): ?>
                  <option value="<?= htmlspecialchars($c['cname'],ENT_QUOTES) ?>">
                    <?= htmlspecialchars($c['cname']) ?>
                  </option>
                <?php endforeach; ?>
                <option value="__other__">— Type manually…</option>
              </select>
              <!-- shown only when "Type manually" is selected -->
              <input type="text" id="ae-course-manual" name="course_manual"
                placeholder="Enter course name"
                style="display:none;margin-top:8px"
                autocomplete="off">
            <?php else: ?>
              <input type="text" name="course" id="ae-course"
                placeholder="e.g. Bachelor of Computer Science" autocomplete="off">
            <?php endif; ?>
            <span class="ae-field-error" id="ae-err-course"></span>
          </div>

        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeAddEnrollment()">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Enrollment</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ COURSE ADD / EDIT MODAL ══ -->
<div class="modal-overlay" id="course-form-overlay" onclick="closeCourseFormOutside(event)">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="course-form-title">Add New Course</div>
      <button class="close-btn" onclick="closeCourseForm()">✕</button>
    </div>
    <form method="POST" id="course-php-form">
      <div style="padding:24px">
        <input type="hidden" name="action"    id="cf-action"    value="add_course">
        <input type="hidden" name="course_id" id="cf-course-id" value="">
        <div class="form-grid">
          <div class="form-group full">
            <label>Course ID <span style="color:var(--red)">*</span></label>
            <input type="text" id="cf-id-display" placeholder="e.g. CRS001" required>
            <small style="color:#999;font-size:11px;margin-top:3px;display:block">Unique Firestore document ID — cannot be changed after creation.</small>
          </div>
          <div class="form-group full"><label>Course Name <span style="color:var(--red)">*</span></label><input type="text" name="cname" id="cf-cname" placeholder="e.g. English for Healthcare" required></div>
          <div class="form-group full"><label>Type <span style="color:var(--red)">*</span></label><input type="text" name="type" id="cf-type" placeholder="e.g. General English, Business…" required></div>
          <div class="form-group full"><label>Description</label><textarea name="description" id="cf-description" rows="3" placeholder="Brief description…"></textarea></div>
          <div class="form-group full"><label>Icon URL</label><input type="url" name="iconUrl" id="cf-iconUrl" placeholder="https://example.com/icon.png"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeCourseForm()">Cancel</button>
        <button type="submit" class="btn btn-primary" id="cf-submit-btn">Save Course</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ ENROLLMENT EDIT MODAL ══ -->
<div class="modal-overlay" id="enrollment-form-overlay" onclick="closeEnrollmentFormOutside(event)">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Edit Enrollment</div>
      <button class="close-btn" onclick="closeEnrollmentForm()">✕</button>
    </div>
    <form method="POST">
      <div style="padding:24px">
        <input type="hidden" name="action"        value="update_enrollment">
        <input type="hidden" name="enrollment_id" id="ef-id">
        <div class="form-grid">
          <div class="form-group full"><label>Full Name <span style="color:var(--red)">*</span></label><input type="text"  name="fullName" id="ef-fullName" required></div>
          <div class="form-group">    <label>Email <span style="color:var(--red)">*</span></label><input type="email" name="email"    id="ef-email"    required></div>
          <div class="form-group">    <label>Age</label><input type="number" name="age" id="ef-age" min="10" max="99"></div>
          <div class="form-group">    <label>Location</label><input type="text" name="location" id="ef-location"></div>
          <div class="form-group">    <label>Phone</label><input type="text" name="phone" id="ef-phone"></div>
          <div class="form-group full"><label>Course / Degree</label><input type="text" name="course" id="ef-course"></div>
          <div class="form-group full">
            <label>Status</label>
            <select name="status" id="ef-status">
              <option value="Pending">⏳ Pending</option>
              <option value="Under Review">🔄 Under Review</option>
              <option value="Approved">✅ Approved</option>
              <option value="Rejected">❌ Rejected</option>
            </select>
          </div>
          <div class="form-group full"><label>Result Sheet URL</label><input type="text" name="result" id="ef-result" placeholder="URL to result file (optional)"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeEnrollmentForm()">Cancel</button>
        <button type="submit" class="btn btn-primary">Update Enrollment</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ GENERAL JS MODAL ══ -->
<div class="modal-overlay" id="modal-overlay" onclick="closeModalOutside(event)">
  <div class="modal" id="modal-box">
    <div class="modal-header">
      <div class="modal-title" id="modal-title">Add Record</div>
      <button class="close-btn" onclick="closeModal()">✕</button>
    </div>
    <div id="modal-body"></div>
  </div>
</div>

<!-- ══ CONFIRM DELETE MODAL ══ -->
<div class="modal-overlay" id="confirm-overlay" onclick="closeConfirmOutside(event)">
  <div class="modal confirm-modal">
    <div class="confirm-icon">🗑️</div>
    <div class="modal-title" style="margin-bottom:8px">Delete Record?</div>
    <div class="confirm-msg" id="confirm-msg">This cannot be undone.</div>
    <div style="display:flex;gap:10px;justify-content:center">
      <button class="btn btn-outline" onclick="closeConfirm()">Cancel</button>
      <button class="btn btn-danger"  id="confirm-yes-btn">Yes, Delete</button>
    </div>
  </div>
</div>

<div id="toast">✓ <span id="toast-msg">Done</span></div>

<script src="right.js"></script>
<script>
/* ════════════════════════════════════════════
   ADD ENROLLMENT MODAL
   ════════════════════════════════════════════ */
function openAddEnrollment() {
  /* Reset all fields */
  ['ae-fullName','ae-email','ae-age','ae-location','ae-phone'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.value = ''; el.classList.remove('ae-invalid'); }
  });
  ['ae-err-fullName','ae-err-email','ae-err-age','ae-err-location','ae-err-phone','ae-err-course']
    .forEach(id => { const el = document.getElementById(id); if (el) el.textContent = ''; });

  const sel    = document.getElementById('ae-course');
  const manual = document.getElementById('ae-course-manual');
  if (sel) {
    sel.selectedIndex = 0;
    sel.classList.remove('ae-invalid');
  }
  if (manual) { manual.value = ''; manual.style.display = 'none'; manual.classList.remove('ae-invalid'); }

  document.getElementById('add-enrollment-overlay').classList.add('open');
}

function closeAddEnrollment() {
  document.getElementById('add-enrollment-overlay').classList.remove('open');
}
function closeAddEnrollmentOutside(e) {
  if (e.target === document.getElementById('add-enrollment-overlay')) closeAddEnrollment();
}

/* Show/hide manual course input when "Type manually…" is selected */
const aeCourseSelect = document.getElementById('ae-course');
if (aeCourseSelect && aeCourseSelect.tagName === 'SELECT') {
  aeCourseSelect.addEventListener('change', function () {
    const manual = document.getElementById('ae-course-manual');
    if (!manual) return;
    if (this.value === '__other__') {
      manual.style.display = 'block';
      manual.required = true;
    } else {
      manual.style.display = 'none';
      manual.required = false;
      manual.value = '';
    }
  });
}

/* Client-side validation before submit */
function validateAddEnrollment() {
  let ok = true;

  const rules = [
    { id: 'ae-fullName', err: 'ae-err-fullName', msg: 'Full name is required.' },
    { id: 'ae-email',    err: 'ae-err-email',    msg: 'A valid email is required.',
      extra: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) },
    { id: 'ae-age',      err: 'ae-err-age',      msg: 'Age must be between 10 and 99.',
      extra: v => +v >= 10 && +v <= 99 },
    { id: 'ae-location', err: 'ae-err-location', msg: 'Location is required.' },
    { id: 'ae-phone',    err: 'ae-err-phone',    msg: 'Phone number is required.' },
  ];

  rules.forEach(r => {
    const el  = document.getElementById(r.id);
    const err = document.getElementById(r.err);
    if (!el || !err) return;
    const val = el.value.trim();
    const pass = val !== '' && (!r.extra || r.extra(val));
    if (!pass) {
      el.classList.add('ae-invalid');
      err.textContent = r.msg;
      ok = false;
    } else {
      el.classList.remove('ae-invalid');
      err.textContent = '';
    }
  });

  /* Course validation */
  const sel    = document.getElementById('ae-course');
  const manual = document.getElementById('ae-course-manual');
  const errC   = document.getElementById('ae-err-course');

  if (sel && sel.tagName === 'SELECT') {
    if (!sel.value || sel.value === '__other__') {
      /* If "other" was chosen, validate the manual input */
      if (sel.value === '__other__' && manual && manual.value.trim() !== '') {
        /* Valid — copy manual value into the select so it posts correctly */
        /* We'll use a hidden input instead */
      } else if (!sel.value) {
        sel.classList.add('ae-invalid');
        if (errC) errC.textContent = 'Please select a course.';
        ok = false;
      }
    } else {
      sel.classList.remove('ae-invalid');
      if (errC) errC.textContent = '';
    }
  } else if (sel) {
    /* Plain text input */
    if (!sel.value.trim()) {
      sel.classList.add('ae-invalid');
      if (errC) errC.textContent = 'Course / Degree is required.';
      ok = false;
    } else {
      sel.classList.remove('ae-invalid');
      if (errC) errC.textContent = '';
    }
  }

  /* If valid and "other" was chosen, rename the manual input to "course"
     so it's picked up by PHP as $_POST['course'] */
  if (ok && sel && sel.tagName === 'SELECT' && sel.value === '__other__' && manual) {
    if (manual.value.trim() === '') {
      manual.classList.add('ae-invalid');
      if (errC) errC.textContent = 'Please type the course name.';
      return false;
    }
    /* Rename fields for correct POST */
    sel.removeAttribute('name');
    manual.name = 'course';
  }

  return ok;
}

/* Remove red border on input */
document.querySelectorAll('#add-enrollment-form input, #add-enrollment-form select').forEach(el => {
  el.addEventListener('input', () => el.classList.remove('ae-invalid'));
  el.addEventListener('change', () => el.classList.remove('ae-invalid'));
});

/* ════════════════════════════════════════════
   ENROLLMENT FILTER + SEARCH
   ════════════════════════════════════════════ */
let _enrollStatus = 'all';

function enrollFilter(status, el) {
  _enrollStatus = status;
  el.closest('.table-toolbar').querySelectorAll('.filter-chip')
    .forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  applyEnrollFilters();
}

function applyEnrollFilters() {
  const q    = (document.getElementById('enroll-search')?.value || '').toLowerCase().trim();
  const rows = document.querySelectorAll('#enrollment-tbody tr[data-status]');
  let shown  = 0;
  rows.forEach(row => {
    const okS = _enrollStatus === 'all' || row.dataset.status === _enrollStatus;
    const okQ = !q || (row.dataset.search || '').includes(q);
    if (okS && okQ) { row.classList.remove('row-hidden'); shown++; }
    else            { row.classList.add('row-hidden'); }
  });
  const c = document.getElementById('enroll-count');
  if (c) c.textContent = shown + ' record' + (shown !== 1 ? 's' : '') + ' shown';
}

/* ════════════════════════════════════════════
   CSV EXPORT
   ════════════════════════════════════════════ */
function exportEnrollCSV() {
  const headers = ['Full Name','Email','Age','Location','Phone','Course','Result','Submitted','Status'];
  const rows = [];
  document.querySelectorAll('#enrollment-tbody tr[data-status]:not(.row-hidden)').forEach(row => {
    const td = row.querySelectorAll('td');
    if (td.length < 9) return;
    rows.push([
      td[0]?.querySelector('[style*="font-weight"]')?.textContent?.trim() || '',
      td[1]?.textContent?.trim() || '',
      td[2]?.textContent?.trim() || '',
      td[3]?.textContent?.trim() || '',
      td[4]?.textContent?.trim() || '',
      td[5]?.textContent?.trim() || '',
      td[6]?.querySelector('a')?.href || td[6]?.textContent?.trim() || '',
      td[7]?.textContent?.trim() || '',
      td[8]?.textContent?.trim() || '',
    ].map(v => `"${v.replace(/"/g,'""')}"`).join(','));
  });
  const url = URL.createObjectURL(new Blob([[headers.join(','),...rows].join('\n')],{type:'text/csv'}));
  Object.assign(document.createElement('a'),{
    href:url, download:'enrollments_'+new Date().toISOString().slice(0,10)+'.csv'
  }).click();
  URL.revokeObjectURL(url);
}

/* ════════════════════════════════════════════
   COURSE MODAL
   ════════════════════════════════════════════ */
function openCourseAdd() {
  document.getElementById('course-form-title').textContent  = 'Add New Course';
  document.getElementById('cf-action').value                = 'add_course';
  document.getElementById('cf-course-id').value             = '';
  document.getElementById('cf-id-display').value            = '';
  document.getElementById('cf-id-display').readOnly         = false;
  document.getElementById('cf-id-display').style.background = '';
  document.getElementById('cf-cname').value                 = '';
  document.getElementById('cf-type').value                  = '';
  document.getElementById('cf-description').value           = '';
  document.getElementById('cf-iconUrl').value               = '';
  document.getElementById('cf-submit-btn').textContent      = 'Save Course';
  document.getElementById('course-php-form').onsubmit = function() {
    document.getElementById('cf-course-id').value = document.getElementById('cf-id-display').value.trim();
    return true;
  };
  document.getElementById('course-form-overlay').classList.add('open');
}
function openCourseEdit(id, cname, type, description, iconUrl) {
  document.getElementById('course-form-title').textContent  = 'Edit Course';
  document.getElementById('cf-action').value                = 'update_course';
  document.getElementById('cf-course-id').value             = id;
  document.getElementById('cf-id-display').value            = id;
  document.getElementById('cf-id-display').readOnly         = true;
  document.getElementById('cf-id-display').style.background = '#f0f0f0';
  document.getElementById('cf-cname').value                 = cname;
  document.getElementById('cf-type').value                  = type;
  document.getElementById('cf-description').value           = description;
  document.getElementById('cf-iconUrl').value               = iconUrl;
  document.getElementById('cf-submit-btn').textContent      = 'Update Course';
  document.getElementById('course-php-form').onsubmit       = null;
  document.getElementById('course-form-overlay').classList.add('open');
}
function closeCourseForm()         { document.getElementById('course-form-overlay').classList.remove('open'); }
function closeCourseFormOutside(e) { if(e.target===document.getElementById('course-form-overlay')) closeCourseForm(); }

/* ════════════════════════════════════════════
   ENROLLMENT EDIT MODAL
   ════════════════════════════════════════════ */
function openEnrollmentEdit(id,fullName,email,age,location,phone,course,status,result) {
  document.getElementById('ef-id').value       = id;
  document.getElementById('ef-fullName').value = fullName;
  document.getElementById('ef-email').value    = email;
  document.getElementById('ef-age').value      = age;
  document.getElementById('ef-location').value = location;
  document.getElementById('ef-phone').value    = phone;
  document.getElementById('ef-course').value   = course;
  document.getElementById('ef-result').value   = result || '';
  const sel = document.getElementById('ef-status');
  for (let i = 0; i < sel.options.length; i++) {
    if (sel.options[i].value === status) { sel.selectedIndex = i; break; }
  }
  document.getElementById('enrollment-form-overlay').classList.add('open');
}
function closeEnrollmentForm()         { document.getElementById('enrollment-form-overlay').classList.remove('open'); }
function closeEnrollmentFormOutside(e) { if(e.target===document.getElementById('enrollment-form-overlay')) closeEnrollmentForm(); }

/* Escape closes all modals */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeAddEnrollment();
    closeCourseForm();
    closeEnrollmentForm();
    if (typeof closeModal   === 'function') closeModal();
    if (typeof closeConfirm === 'function') closeConfirm();
  }
});
</script>
</body>
</html>
