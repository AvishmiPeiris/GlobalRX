<?php
require_once 'config.php';

class ScholarshipManager {

    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    public function __construct() {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/scholarships";
    }

    /* ════════════════════════════
       PRIVATE HELPERS
    ════════════════════════════ */

    private function firestoreValue(mixed $val): array {
        if (is_null($val) || $val === '') return ['nullValue'    => null];
        if (is_bool($val))                return ['booleanValue' => $val];
        if (is_numeric($val) && strpos((string)$val, '.') !== false)
                                          return ['doubleValue'  => (float)$val];
        if (is_int($val))                 return ['integerValue' => (string)$val];
        return ['stringValue' => (string)$val];
    }

    private function toFields(array $data): array {
        $fields = [];
        foreach ($data as $k => $v) {
            $fields[$k] = $this->firestoreValue($v);
        }
        return $fields;
    }

    private function fromDocument(array $doc): array {
        $id     = basename($doc['name'] ?? '');
        $fields = $doc['fields'] ?? [];
        $row    = ['id' => $id];
        foreach ($fields as $k => $typeVal) {
            $row[$k] = $typeVal['stringValue']
                    ?? $typeVal['integerValue']
                    ?? $typeVal['doubleValue']
                    ?? $typeVal['booleanValue']
                    ?? null;
        }
        return $row;
    }

    private function request(string $method, string $url, ?array $body = null): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT        => 15,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $raw  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $decoded = json_decode($raw, true) ?? [];
        return ['code' => $code, 'data' => $decoded];
    }

    /* ════════════════════════════
       PUBLIC METHODS
    ════════════════════════════ */

    /** Fetch all scholarships, sorted by sName */
    public function getAllScholarships(): array {
        $url = $this->baseUrl . '?key=' . $this->apiKey;
        $res = $this->request('GET', $url);

        if ($res['code'] !== 200) {
            return [
                'success'      => false,
                'message'      => 'Could not load scholarships. (HTTP ' . $res['code'] . ')',
                'scholarships' => []
            ];
        }

        $docs         = $res['data']['documents'] ?? [];
        $scholarships = array_map([$this, 'fromDocument'], $docs);

        usort($scholarships, fn($a, $b) => strcmp(
            strtolower($a['sName'] ?? ''),
            strtolower($b['sName'] ?? '')
        ));

        return ['success' => true, 'scholarships' => $scholarships];
    }

    /** Add a new scholarship — document ID = $scholarshipId */
    public function addScholarship(
        string $scholarshipId,
        string $sName,
        string $academicLevel,
        string $university,
        string $country,
        string $imageUrl
    ): array {
        if (empty($scholarshipId)) return ['success' => false, 'message' => 'Scholarship ID is required.'];
        if (empty($sName))         return ['success' => false, 'message' => 'Scholarship name is required.'];

        $url  = $this->baseUrl
              . '?documentId=' . urlencode($scholarshipId)
              . '&key='        . $this->apiKey;

        $body = ['fields' => $this->toFields([
            'sName'         => $sName,
            'academicLevel' => $academicLevel,
            'university'    => $university,
            'country'       => $country,
            'imageUrl'      => $imageUrl,
        ])];

        $res = $this->request('POST', $url, $body);

        if (in_array($res['code'], [200, 201])) {
            return ['success' => true, 'message' => "Scholarship '{$sName}' added successfully."];
        }

        $errMsg = $res['data']['error']['message'] ?? 'Failed to add scholarship.';
        return ['success' => false, 'message' => $errMsg];
    }

    /** Update an existing scholarship */
    public function updateScholarship(
        string $scholarshipId,
        string $sName,
        string $academicLevel,
        string $university,
        string $country,
        string $imageUrl
    ): array {
        if (empty($scholarshipId)) return ['success' => false, 'message' => 'Scholarship ID is required.'];
        if (empty($sName))         return ['success' => false, 'message' => 'Scholarship name is required.'];

        $fieldNames = ['sName', 'academicLevel', 'university', 'country', 'imageUrl'];
        $mask       = implode('&', array_map(
            fn($f) => 'updateMask.fieldPaths=' . $f,
            $fieldNames
        ));

        $url  = $this->baseUrl
              . '/' . urlencode($scholarshipId)
              . '?' . $mask
              . '&key=' . $this->apiKey;

        $body = ['fields' => $this->toFields([
            'sName'         => $sName,
            'academicLevel' => $academicLevel,
            'university'    => $university,
            'country'       => $country,
            'imageUrl'      => $imageUrl,
        ])];

        $res = $this->request('PATCH', $url, $body);

        if ($res['code'] === 200) {
            return ['success' => true, 'message' => "Scholarship '{$sName}' updated successfully."];
        }

        $errMsg = $res['data']['error']['message'] ?? 'Failed to update scholarship.';
        return ['success' => false, 'message' => $errMsg];
    }

    /** Delete a scholarship by document ID */
    public function deleteScholarship(string $scholarshipId): array {
        if (empty($scholarshipId)) return ['success' => false, 'message' => 'Scholarship ID is required.'];

        $url = $this->baseUrl . '/' . urlencode($scholarshipId) . '?key=' . $this->apiKey;
        $res = $this->request('DELETE', $url);

        if ($res['code'] === 200) {
            return ['success' => true, 'message' => 'Scholarship deleted successfully.'];
        }

        $errMsg = $res['data']['error']['message'] ?? 'Failed to delete scholarship.';
        return ['success' => false, 'message' => $errMsg];
    }
}
