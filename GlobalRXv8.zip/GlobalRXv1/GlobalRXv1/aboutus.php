<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;
$firstName  = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName   = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email      = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role       = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');
$initial    = !empty($firstName) ? strtoupper($firstName[0]) : '?';
if (empty($fullName) && !empty($firstName)) $fullName = $firstName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us – Global RX Business</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&family=Barlow+Condensed:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link href="aboutus.css" rel="stylesheet">
<style>
/* ── NAV USER WIDGET (same as index.php) ── */
.nav-user{position:relative}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #d0d0d0;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#111;transition:border-color .2s,background .2s;font-family:inherit}
.nav-user-toggle:hover{border-color:var(--red,#e63946);background:rgba(230,57,70,0.05)}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:var(--red,#e63946);overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0}
.nav-user-name{font-size:14px;font-weight:600;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111}
.nav-chevron{display:flex;align-items:center}
.nav-chevron svg{width:10px;height:6px;stroke:#555;fill:none;stroke-width:2;transition:transform .25s}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg)}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:280px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.14);border:1px solid #ececec;padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px}
.num-avatar-lg{width:48px;height:48px;border-radius:50%;background:var(--red,#e63946);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;color:#fff;flex-shrink:0;overflow:hidden}
.num-info{flex:1;min-width:0}
.num-name{font-size:14px;font-weight:700;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-email{font-size:12px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#f0f0f0;color:#555;font-size:10px;font-weight:700;letter-spacing:.5px;border-radius:50px;text-transform:capitalize}
.num-divider{height:1px;background:#f0f0f0;margin:4px 0}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#222;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#888;fill:currentColor}
.num-item:hover{background:#f6f6f6}
.num-logout{color:#e63946 !important}
.num-logout svg{color:#e63946 !important}
.num-logout:hover{background:#fff3f3 !important}
@media(max-width:768px){.nav-user-menu{width:260px;right:-10px}.nav-user-name{display:none}}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <div id="navLoggedOut">
    <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  </div>
  <?php endif; ?>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-content">
    <div class="hero-eyebrow">Established with Purpose</div>
    <h1>About <em>Us</em></h1>
    <p>Empowering individuals through education, language mastery, and international opportunities — from the heart of London to the world.</p>
    <a href="#who" class="btn-primary">
      Discover Our Story
      <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg>
    </a>
  </div>
</section>

<!-- WHO WE ARE -->
<section class="who-section" id="who">
  <div class="photo-mosaic">
    <img class="p1" src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=500&q=80" alt="Global RX Team" />
    <img class="p2" src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=500&q=80" alt="Consultation" />
    <img class="p3" src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=500&q=80" alt="Education" />
    <div class="badge-years">
      <strong>5+</strong>
      <span>Years</span>
    </div>
  </div>
  <div class="who-text">
    <div class="label">Who We Are</div>
    <h2>A Global <span>Pathways</span> Company</h2>
    <p>Global RX Business LTD is a London-based professional services firm dedicated to connecting individuals with life-changing opportunities worldwide. From expert visa consultation to higher education placement and English language mastery, we guide every step of your journey.</p>
    <blockquote>As certified international consultants, we understand that navigating global systems requires trust, expertise, and personalised care.</blockquote>
    <p>Our team brings together decades of combined experience across immigration, education, and professional development — ensuring you receive the most accurate, up-to-date guidance tailored to your unique goals.</p>
    <div class="stats-row">
      <div class="stat"><strong>2,400+</strong><span>Clients Served</span></div>
      <div class="stat"><strong>38</strong><span>Countries Covered</span></div>
      <div class="stat"><strong>98%</strong><span>Success Rate</span></div>
    </div>
  </div>
</section>

<!-- WHAT WE DO -->
<section class="services-section">
  <div class="section-header">
    <div class="label">What We Do</div>
    <h2>Our Core Services</h2>
  </div>
  <div class="services-grid">
    <div class="service-card card-navy">
      <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg></div>
      <div class="service-label">Subsidiary</div>
      <h3>Visa<br>Consultation</h3>
      <p>Expert guidance on all visa categories — student, work, family, and settlement routes. We handle complexity so you don't have to.</p>
      <a href="visa.php" class="service-link">Learn More <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></a>
    </div>
    <div class="service-card card-tan">
      <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M12 3L1 9l11 6 9-4.91V17h2V9M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/></svg></div>
      <div class="service-label">Subsidiary</div>
      <h3>Higher<br>Education</h3>
      <p>Connecting students to top universities and colleges worldwide. From applications to enrolment — we support every step.</p>
      <a href="higherEducation.php" class="service-link">Learn More <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></a>
    </div>
    <div class="service-card card-red">
      <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zm4.24 16L12 15.45 7.77 18l1.12-4.81-3.73-3.23 4.92-.42L12 5l1.92 4.53 4.92.42-3.73 3.23L16.23 18z"/></svg></div>
      <div class="service-label">Subsidiary</div>
      <h3>English<br>Academy</h3>
      <p>Accredited English language programmes designed to accelerate proficiency for academic and professional success.</p>
      <a href="english.php" class="service-link">Learn More <svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></a>
    </div>
  </div>
</section>

<!-- FOUNDERS -->
<section class="founders-section">
  <div class="section-header">
    <div class="label">Leadership</div>
    <h2>Meet The Founders</h2>
  </div>
  <div class="founders-grid">
    <div class="founder-card">
      <div class="founder-photo">
        <div class="fallback-icon"><svg viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg></div>
        <img src="images/Founder.jpeg" alt="M.H. Ali" onerror="this.style.display='none'" />
      </div>
      <div class="founder-info">
        <div class="founder-role">Founder &amp; CEO</div>
        <h3>M.H. Ali</h3>
        <p>Lecturer and Academic researcher in social care, public health and health policy.</p>
        <div class="founder-tags">
          <span class="tag">BPharm(Hons)</span><span class="tag">MPharm(BNG)</span>
          <span class="tag">MBA(UK)</span><span class="tag">PgCert in HE(London,UK)</span>
          <span class="tag">FHEA(UK)</span><span class="tag">Ph.D(France)</span>
        </div>
      </div>
    </div>
    <div class="founder-card">
      <div class="founder-photo">
        <div class="fallback-icon"><svg viewBox="0 0 24 24"><path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/></svg></div>
        <img src="images/Cofounder.jpeg" alt="M. Ahamed" onerror="this.style.display='none'" />
      </div>
      <div class="founder-info">
        <div class="founder-role">Co-Founder &amp; COO</div>
        <h3>M. Ahamed</h3>
        <p>Reader in clinical medicine and board certified internist and critical care physician.</p>
        <div class="founder-tags">
          <span class="tag">BS</span><span class="tag">M.D.</span>
          <span class="tag">MRCPS (Canada)</span><span class="tag">FCCP (Stanford, USA)</span>
          <span class="tag">Ph.D(Cambridge, UK)</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA FULLBLEED -->
<section class="cta-fullbleed">
  <div class="cta-bg"></div>
  <div class="cta-watermark">CONTACT</div>
  <div class="cta-content">
    <div class="label">Get In Touch</div>
    <h2>Home, Global,<br><em>You Name It,</em><br>We'll Be There.</h2>
    <p>Wherever your ambitions take you — we have the expertise to make it happen. Reach out today and take the first step toward your next chapter.</p>
    <div class="cta-btn-row">
      <a href="tel:+441234567890" class="btn-primary">
        Call +44 1234 56789
        <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
      </a>
      <a href="mailto:info@globalrx.co.uk" class="btn-ghost">
        Email Us
        <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
      </a>
    </div>
  </div>
</section>

<!-- CONTACT STRIP -->
<div class="contact-strip">
  <div class="contact-strip-item">
    <div class="cs-icon"><svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></div>
    <h4>Head Office</h4>
    <p>Global RX Business LTD<br>London, United Kingdom</p>
  </div>
  <div class="contact-strip-item">
    <div class="cs-icon"><svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></div>
    <h4>Call Us</h4>
    <p>+44 1234 56789</p>
  </div>
  <div class="contact-strip-item">
    <div class="cs-icon"><svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg></div>
    <h4>Email Us</h4>
    <p>info@globalrx.co.uk<br>support@globalrx.co.uk</p>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col"><h4>Pages</h4><ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
      </ul></div>
      <div class="footer-col"><h4>Subsidiaries</h4><ul>
        <li><a href="visa.php">A² Visa Consultation</a></li>
        <li><a href="higherEducation.php">A² Higher Education</a></li>
        <li><a href="english.php">A² English Academy</a></li>
      </ul></div>
      <div class="footer-col"><h4>Contact</h4><ul>
        <li><span>info@globalrx.co.uk</span></li>
        <li><span>+44 1234 56789</span></li>
        <li><span>London, United Kingdom</span></li>
      </ul></div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:#2c3e5a"></div>
        <div class="dot" style="background:#b5a898"></div>
      </div>
    </div>
  </div>
</footer>

<script>
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const t = document.querySelector(a.getAttribute('href'));
      if (t) t.scrollIntoView({ behavior: 'smooth' });
    });
  });

  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 8px 32px rgba(0,0,0,0.14)'
      : '0 4px 24px rgba(0,0,0,0.06)';
  });

  function toggleDropdown() {
    document.getElementById('divDropdown').classList.toggle('open');
  }
  document.addEventListener('click', e => {
    const dd = document.getElementById('divDropdown');
    if (dd && !dd.contains(e.target)) dd.classList.remove('open');
  });

  // User menu
  const navUserToggle = document.getElementById('navUserToggle');
  const navUserMenu   = document.getElementById('navUserMenu');
  if (navUserToggle && navUserMenu) {
    navUserToggle.addEventListener('click', e => {
      e.stopPropagation();
      const isOpen = navUserMenu.classList.toggle('open');
      navUserToggle.setAttribute('aria-expanded', isOpen);
    });
    document.addEventListener('click', e => {
      const navUser = document.getElementById('navUser');
      if (navUser && !navUser.contains(e.target)) {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }
</script>
</body>
</html>