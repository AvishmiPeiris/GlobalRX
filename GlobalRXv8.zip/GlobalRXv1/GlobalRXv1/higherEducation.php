<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');

$initial = !empty($firstName) ? strtoupper($firstName[0]) : '?';

if (empty($fullName) && !empty($firstName)) {
    $fullName = $firstName;
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=1280"/>
<title>Global RX – Higher Education</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,800;1,700;1,800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet"/>
<link href="higherEducation.css" rel="stylesheet">
<style>
/* ── NAV USER WIDGET ── */
.nav-user{position:relative}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #d0d0d0;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#111;transition:border-color .2s,background .2s;font-family:inherit}
.nav-user-toggle:hover{border-color:#e63946;background:rgba(230,57,70,0.05)}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:#e63946;overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0}
.nav-user-name{font-size:14px;font-weight:600;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111}
.nav-chevron{display:flex;align-items:center}
.nav-chevron svg{width:10px;height:6px;stroke:#555;fill:none;stroke-width:2;transition:transform .25s}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg)}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:280px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.14);border:1px solid #ececec;padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px}
.num-avatar-lg{width:48px;height:48px;border-radius:50%;background:#e63946;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;color:#fff;flex-shrink:0}
.num-info{flex:1;min-width:0}
.num-name{font-size:14px;font-weight:700;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-email{font-size:12px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#f0f0f0;color:#555;font-size:10px;font-weight:700;letter-spacing:.5px;border-radius:50px;text-transform:capitalize}
.num-divider{height:1px;background:#f0f0f0;margin:4px 0}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#222;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#888;fill:currentColor}
.num-item:hover{background:#f6f6f6}
.num-logout{color:#e63946!important}.num-logout svg{color:#e63946!important}.num-logout:hover{background:#fff3f3!important}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  <?php endif; ?>
</nav>

<!-- HERO -->
<section class="hero">
  <div class="hero-w">
    <div class="hero-left">
      <div class="hero-tag"><span class="blink"></span>100% Satisfaction Guarantee</div>
      <h1>Turn Your Ambition<br/>into <em>Achievement</em></h1>
      <p class="hero-desc">Empowering students with world-class pharmaceutical education, innovation and global opportunity. Join 5,000+ graduates transforming healthcare worldwide.</p>
      <div class="hero-actions">
        <a href="scholarship.php" class="btn-primary">
          View Scholarships
          <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </a>
      </div>
      <div class="hero-stats">
        <div class="h-stat"><div class="n">99<em>%</em></div><div class="l">Success Rate</div></div>
        <div class="h-stat"><div class="n">16<em>+</em></div><div class="l">Years Excellence</div></div>
        <div class="h-stat"><div class="n">40<em>+</em></div><div class="l">Partner Universities</div></div>
        <div class="h-stat"><div class="n">5K<em>+</em></div><div class="l">Graduates</div></div>
      </div>
    </div>
    <div class="hero-right">
      <div class="hero-photo">
        <img src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=900&q=85&auto=format&fit=crop&crop=center" alt="University students"/>
      </div>
      <div class="hero-photo-overlay"></div>
      <div class="fc fc1"><div class="fn">5,000+</div><div class="fl">Students Enrolled</div></div>
      <div class="fc fc2"><div class="fn">✓ Learn Online Anywhere</div><div class="fl">Any device · Anytime · Anywhere</div></div>
    </div>
  </div>
</section>

<!-- STRIP -->
<div class="strip">
  <div class="strip-w">
    <div class="strip-item">
      <div class="s-ico"><svg viewBox="0 0 24 24"><path d="M22 10v6M2 10l10-5 10 5-10 5-10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg></div>
      <div><div class="s-title">Scholarship Facility</div><div class="s-sub">Generous funding for every qualified student</div></div>
    </div>
    <div class="strip-item">
      <div class="s-ico"><svg viewBox="0 0 24 24"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg></div>
      <div><div class="s-title">Book &amp; Library Store</div><div class="s-sub">Access 50,000+ academic resources online</div></div>
    </div>
    <div class="strip-item">
      <div class="s-ico"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div>
      <div><div class="s-title">Online Learning</div><div class="s-sub">Flexible programmes that fit your life</div></div>
    </div>
  </div>
</div>

<!-- ABOUT -->
<section class="about-sec" id="about">
  <div class="about-w">
    <div class="about-photos">
      <div class="ap-main"><img src="https://images.unsplash.com/photo-1627556704302-624286467c65?w=500&q=80&auto=format&fit=crop" alt="Graduates"/></div>
      <div class="ap-sub"><img src="https://images.unsplash.com/photo-1543269865-cbf427effbad?w=440&q=80&auto=format&fit=crop" alt="Students"/></div>
      <div class="ap-since">Since 1999</div>
      <div class="ap-years"><div class="big">16+</div><div class="sm">Years of<br/>Excellence</div></div>
    </div>
    <div class="about-content">
      <div class="chip">About Us</div>
      <h2 class="sh">Who We Are – Introduction to<br/><em>Global RX Online Platform</em></h2>
      <p class="sp">The ultimate destination for pharmaceutical knowledge seekers and educators alike. We are committed to transforming healthcare education, reaching global channels without compromising on academic standards.</p>
      <ul class="check-list">
        <li>Course Catalog &amp; Program Information</li>
        <li>Online Application &amp; Admission Process</li>
        <li>Financial Aid and Scholarships</li>
      </ul>
      <div class="about-meta">
        <div class="a-phone">
          <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
          +(680) 3290 570
        </div>
        <div class="trust">
          <div class="trust-ico"><svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>
          <div class="trust-t"><strong>Trusted Online &amp; Offline</strong><span>Best Educations — John Doe</span></div>
        </div>
      </div>
      <a href="aboutus.php" class="btn-primary" style="margin-top:24px;display:inline-flex">More About Us <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
    </div>
  </div>
</section>

<!-- DEGREE MANAGEMENT -->
<section class="degree-sec">
  <div class="degree-w">
    <div class="degree-head">
      <div class="degree-head-text">
        <div class="chip">Global RX Business</div>
        <h2 class="sh">Higher Education <em>Degree Management</em></h2>
        <p class="sp">Choose your academic pathway — from accelerated diplomas to fully accredited degrees, designed around the global pharmaceutical industry.</p>
      </div>
    </div>
    <div class="degree-grid">
      <div class="d-card">
        <div class="d-card-img">
          <img src="https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=800&q=80&auto=format&fit=crop&crop=center" alt="University lecture hall"/>
          <div class="d-card-img-overlay"></div>
          <div class="d-card-cat">Undergraduate &amp; Postgraduate</div>
          <div class="d-card-headline">Bachelor's &amp; Master's Degree</div>
        </div>
        <div class="d-body">
          <p class="d-desc">Fully accredited degree programmes designed in partnership with global universities — tailored to the pharmaceutical and RX business landscape. Blended online and on-campus delivery.</p>
          <ul class="d-list">
            <li>BSc / BBA in Pharmaceutical Management</li>
            <li>MSc Global Health &amp; RX Business</li>
            <li>MBA Healthcare Administration</li>
            <li>PhD Research Pathways available</li>
            <li>Blended online &amp; on-campus learning</li>
          </ul>
          <div class="d-stats">
            <div class="d-st"><div class="n">3–4 yrs</div><div class="l">Duration</div></div>
            <div class="d-st"><div class="n">12+</div><div class="l">Specialisations</div></div>
            <div class="d-st"><div class="n">100%</div><div class="l">Accredited</div></div>
          </div>
          <div class="d-cta"><a href="degrees.php"><button class="d-cta-btn">Explore Degrees <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></button></a></div>
        </div>
      </div>
      <div class="d-card">
        <div class="d-card-img">
          <img src="https://images.unsplash.com/photo-1532012197267-da84d127e765?w=800&q=80&auto=format&fit=crop&crop=center" alt="Students studying"/>
          <div class="d-card-img-overlay"></div>
          <div class="d-card-cat">Professional Certification</div>
          <div class="d-card-headline">Professional Diploma</div>
        </div>
        <div class="d-body">
          <p class="d-desc">Accelerated, industry-focused diploma programmes equipping professionals with applied skills for the global pharmaceutical and healthcare business sector.</p>
          <ul class="d-list">
            <li>Diploma in RX Business Operations</li>
            <li>Diploma in Clinical Supply Chain</li>
            <li>Diploma in Regulatory Affairs</li>
            <li>Healthcare Marketing &amp; Sales Diploma</li>
            <li>Executive Diploma (evenings / weekends)</li>
          </ul>
          <div class="d-stats">
            <div class="d-st"><div class="n">6–18 mo</div><div class="l">Duration</div></div>
            <div class="d-st"><div class="n">8+</div><div class="l">Tracks</div></div>
            <div class="d-st"><div class="n">Fast</div><div class="l">Entry</div></div>
          </div>
          <div class="d-cta"><a href="diplomas.php"><button class="d-cta-btn">Explore Diplomas <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></button></a></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WHY US -->
<section class="why-sec">
  <div class="why-w">
    <div class="why-grid">
      <div>
        <div class="chip">Why Choose Us</div>
        <h2 class="sh">One of the most <em>diverse</em><br/>universities in the World</h2>
        <p class="sp" style="margin-bottom:0">Home to students from every corner of the globe, fostering diversity, inclusion, and world-class academic excellence.</p>
      </div>
      <div class="why-cards">
        <div class="w-card"><div class="w-ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg></div><h4>Inspiring Student Life</h4><p>Vibrant campus experience that empowers every student to thrive and grow.</p></div>
        <div class="w-card"><div class="w-ico"><svg viewBox="0 0 24 24"><path d="M22 10v6M2 10l10-5 10 5-10 5-10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg></div><h4>Education Affordability</h4><p>Accessible pathways with generous scholarship and financial aid programmes.</p></div>
        <div class="w-card"><div class="w-ico"><svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div><h4>Core-level Academics</h4><p>Cutting-edge pharmaceutical research and rigorous academic curriculum.</p></div>
        <div class="w-card"><div class="w-ico"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></div><h4>Global Network</h4><p>Connect with 40+ partner universities and 5,000+ alumni worldwide.</p></div>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testi-sec">
  <div class="testi-w">
    <div class="testi-head">
      <div class="chip">Testimonials</div>
      <h2 class="sh">Voices From Our <em>Global Community</em></h2>
    </div>
    <div class="testi-grid">
      <div class="t-card"><div class="t-stars">★★★★★</div><p class="t-quote">"A truly global learning experience. GlobalRX allowed me to grow from different cultures while getting a strong academic foundation."</p><div class="t-auth"><div class="t-av">LA</div><div><div class="t-name">Leslie Alexander</div><div class="t-role">MSc Graduate, 2024</div></div></div></div>
      <div class="t-card"><div class="t-stars">★★★★★</div><p class="t-quote">"Education that builds confidence. The support and mentoring helped me grow both academically and professionally."</p><div class="t-auth"><div class="t-av">JJ</div><div><div class="t-name">Jacob Jones</div><div class="t-role">MBA Graduate, 2023</div></div></div></div>
      <div class="t-card"><div class="t-stars">★★★★★</div><p class="t-quote">"A future-focused institution. My degree prepared me for global pharmaceutical challenges. The curriculum is genuinely world-class."</p><div class="t-auth"><div class="t-av">RE</div><div><div class="t-name">Ralph Edwards</div><div class="t-role">BBA Graduate, 2024</div></div></div></div>
    </div>
  </div>
</section>

<!-- FAQ + NEWS -->
<section class="faq-sec">
  <div class="faq-w">
    <div>
      <div class="chip">News &amp; Events</div>
      <h2 class="sh" style="margin-bottom:22px">News about<br/>our <em>university</em></h2>
      <div class="acc">
        <div class="acc-item open"><div class="acc-h" onclick="tog(this)"><span class="acc-date">Jan 01, 2025</span><span class="acc-title">How can I apply for admission?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span><button class="apply-tag">Apply Now</button></div><div class="acc-b"><p>Applications are open year-round via our online portal. Submit your academic transcripts, a personal statement, and two references. Our admissions team responds within 5 business days.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-date">Jan 01, 2025</span><span class="acc-title">What scholarships are available?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>We offer merit-based and need-based scholarships covering up to 80% of tuition. International students may also qualify for the Global Excellence Award.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-date">Jan 01, 2025</span><span class="acc-title">Are courses available fully online?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>Yes. All diploma programmes and select degree courses are fully online with live weekly sessions, recorded lectures, and virtual lab simulations.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-date">Jan 01, 2025</span><span class="acc-title">What support services are available?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>Students access academic advisors, career counselling, mental health support, a 24/7 library portal, and a peer mentoring network across 40+ countries.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-date">Jan 01, 2025</span><span class="acc-title">Does the university provide on-campus accommodation?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>On-campus housing is available for full-time students. Applications open 3 months before semester start. Off-campus housing assistance is also provided.</p></div></div>
      </div>
    </div>
    <div>
      <div class="chip">FAQ</div>
      <h2 class="sh" style="margin-bottom:22px">Frequently Asked <em>Questions</em></h2>
      <div class="faq-img"><img src="https://images.unsplash.com/photo-1562774053-701939374585?w=700&q=80&auto=format&fit=crop" alt="University campus"/></div>
      <div class="acc">
        <div class="acc-item open"><div class="acc-h" onclick="tog(this)"><span class="acc-title">What programs does the university offer?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>We offer undergraduate and postgraduate programmes in pharmaceutical management and healthcare business.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-title">Are scholarships or financial aid available?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>Yes — we offer merit-based, need-based, and international awards. Our financial aid team can help identify the right option for you.</p></div></div>
        <div class="acc-item"><div class="acc-h" onclick="tog(this)"><span class="acc-title">Does the university provide on-campus accommodation?</span><span class="acc-arr"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></span></div><div class="acc-b"><p>On-campus housing available for full-time students, with off-campus housing assistance also provided.</p></div></div>
      </div>
    </div>
  </div>
</section>

<!-- PARTNERS SLIDER -->
<section class="partners-sec">
  <div class="partners-w">
    <div class="p-top">
      <div><div class="chip">Academic Alliances</div><h2 class="sh" style="margin-bottom:0">Our <em>Partner</em> Universities</h2></div>
      <div class="p-count">40+<small>globally accredited partners</small></div>
    </div>
    <div class="s-vp">
      <div class="s-track">
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="6" y="8" width="24" height="24" rx="4" fill="#15803d"/><text x="36" y="26" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">UniMed</text></svg><span class="u-name">Univ. of Medical Sciences</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><circle cx="19" cy="20" r="13" stroke="#15803d" stroke-width="2"/><text x="19" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="10" fill="#15803d" text-anchor="middle">GH</text><text x="40" y="18" font-family="DM Sans,sans-serif" font-weight="600" font-size="11" fill="#0a0f0c">GlobalHealth</text><text x="40" y="30" font-family="DM Sans,sans-serif" font-size="9" fill="#7a9485">Institute</text></svg><span class="u-name">Global Health Institute</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><polygon points="19,5 33,20 19,35 5,20" fill="#15803d" opacity=".18"/><polygon points="19,10 28,20 19,30 10,20" fill="#15803d"/><text x="40" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">PharmaX</text></svg><span class="u-name">PharmaX Business School</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="4" y="16" width="26" height="9" rx="2" fill="#0f3d20"/><rect x="10" y="7" width="14" height="9" rx="2" fill="#15803d"/><text x="36" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">RxAcad</text></svg><span class="u-name">RX Academy of Sciences</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><path d="M19 5L31 17 19 35 7 17Z" fill="none" stroke="#15803d" stroke-width="1.8"/><circle cx="19" cy="20" r="4" fill="#15803d"/><text x="38" y="17" font-family="DM Sans,sans-serif" font-weight="600" font-size="11" fill="#0a0f0c">Nexus</text><text x="38" y="29" font-family="DM Sans,sans-serif" font-size="9" fill="#7a9485">University</text></svg><span class="u-name">Nexus University</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><path d="M6 30Q19 5 32 30" stroke="#15803d" stroke-width="2" fill="none"/><line x1="6" y1="30" x2="32" y2="30" stroke="#0f3d20" stroke-width="1.8"/><text x="40" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">HealthBiz</text></svg><span class="u-name">HealthBiz College</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="4" y="5" width="28" height="28" rx="4" fill="none" stroke="#15803d" stroke-width="1.8"/><line x1="4" y1="19" x2="32" y2="19" stroke="#15803d" stroke-width="1"/><text x="38" y="17" font-family="DM Sans,sans-serif" font-weight="600" font-size="10" fill="#0a0f0c">ClinEdge</text><text x="38" y="29" font-family="DM Sans,sans-serif" font-size="8" fill="#7a9485">Graduate School</text></svg><span class="u-name">ClinEdge Grad. School</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><circle cx="12" cy="20" r="8" fill="#0f3d20"/><circle cx="26" cy="20" r="8" fill="#15803d" opacity=".45"/><text x="40" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">MedLink</text></svg><span class="u-name">MedLink University</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><path d="M8 31L19 8 30 31Z" fill="#15803d" opacity=".15"/><path d="M8 31L19 8 30 31Z" fill="none" stroke="#15803d" stroke-width="1.8"/><text x="37" y="18" font-family="DM Sans,sans-serif" font-weight="600" font-size="10" fill="#0a0f0c">Apex</text><text x="37" y="29" font-family="DM Sans,sans-serif" font-size="8" fill="#7a9485">Medical College</text></svg><span class="u-name">Apex Medical College</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="4" y="13" width="13" height="17" rx="2" fill="#15803d" opacity=".4"/><rect x="14" y="5" width="14" height="25" rx="2" fill="#15803d"/><text x="34" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">ProRx</text></svg><span class="u-name">ProRx Business School</span></div>
        <!-- Duplicate for infinite scroll -->
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="6" y="8" width="24" height="24" rx="4" fill="#15803d"/><text x="36" y="26" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">UniMed</text></svg><span class="u-name">Univ. of Medical Sciences</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><circle cx="19" cy="20" r="13" stroke="#15803d" stroke-width="2"/><text x="19" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="10" fill="#15803d" text-anchor="middle">GH</text><text x="40" y="18" font-family="DM Sans,sans-serif" font-weight="600" font-size="11" fill="#0a0f0c">GlobalHealth</text><text x="40" y="30" font-family="DM Sans,sans-serif" font-size="9" fill="#7a9485">Institute</text></svg><span class="u-name">Global Health Institute</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><polygon points="19,5 33,20 19,35 5,20" fill="#15803d" opacity=".18"/><polygon points="19,10 28,20 19,30 10,20" fill="#15803d"/><text x="40" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">PharmaX</text></svg><span class="u-name">PharmaX Business School</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><rect x="4" y="16" width="26" height="9" rx="2" fill="#0f3d20"/><rect x="10" y="7" width="14" height="9" rx="2" fill="#15803d"/><text x="36" y="25" font-family="DM Sans,sans-serif" font-weight="600" font-size="12" fill="#0a0f0c">RxAcad</text></svg><span class="u-name">RX Academy of Sciences</span></div>
        <div class="u-card"><svg viewBox="0 0 140 40" fill="none"><path d="M19 5L31 17 19 35 7 17Z" fill="none" stroke="#15803d" stroke-width="1.8"/><circle cx="19" cy="20" r="4" fill="#15803d"/><text x="38" y="17" font-family="DM Sans,sans-serif" font-weight="600" font-size="11" fill="#0a0f0c">Nexus</text><text x="38" y="29" font-family="DM Sans,sans-serif" font-size="9" fill="#7a9485">University</text></svg><span class="u-name">Nexus University</span></div>
      </div>
    </div>
    <div class="s-dots" id="sdots"><span class="on"></span><span></span><span></span><span></span><span></span></div>
  </div>
</section>

<!-- CTA -->
<div class="cta">
  <div class="cta-w">
    <div>
      <h2>Start Your Journey Toward a <em>Brighter Future</em></h2>
      <p>Be part of a diverse, forward-thinking academic community committed to excellence, innovation and global impact.</p>
    </div>
    <a href="enrollment.php" class="btn-primary" style="flex-shrink:0;font-size:.9rem;padding:15px 32px">Enroll Now <svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col"><h4>PAGES</h4><ul><li><a href="index.php">Home</a></li><li><a href="aboutus.php">About Us</a></li><li><a href="contactus.php">Contact Us</a></li></ul></div>
      <div class="footer-col"><h4>SUBSIDIARIES</h4><ul><li><a href="visa.php">A² Visa Consultation</a></li><li><a href="higherEducation.php">A² Higher Education</a></li><li><a href="english.php">A² English Academy</a></li></ul></div>
      <div class="footer-col"><h4>CONTACT</h4><ul><li><span>info@globalrx.com</span></li><li><span>+1 (800) 000-0000</span></li><li><span>Colombo, Sri Lanka</span></li></ul></div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
function tog(h){
  const item=h.parentElement;
  const was=item.classList.contains('open');
  item.closest('.acc,.faq-sec').querySelectorAll('.acc-item').forEach(i=>i.classList.remove('open'));
  if(!was)item.classList.add('open');
}

const dots=document.querySelectorAll('#sdots span');
let c=0;
setInterval(()=>{dots[c].classList.remove('on');c=(c+1)%dots.length;dots[c].classList.add('on')},2700);

document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{e.preventDefault();const t=document.querySelector(a.getAttribute('href'));if(t)t.scrollIntoView({behavior:'smooth'})});
});

const nav=document.querySelector('nav');
window.addEventListener('scroll',()=>{
  nav.style.boxShadow=window.scrollY>40?'0 8px 32px rgba(0,0,0,0.14)':'0 4px 24px rgba(0,0,0,0.06)';
});

function toggleDropdown(){document.getElementById('divDropdown').classList.toggle('open')}
document.addEventListener('click',e=>{const dd=document.getElementById('divDropdown');if(!dd.contains(e.target))dd.classList.remove('open')});

/* ── User menu ── */
const navUserToggle=document.getElementById('navUserToggle');
const navUserMenu  =document.getElementById('navUserMenu');
if(navUserToggle&&navUserMenu){
  navUserToggle.addEventListener('click',e=>{e.stopPropagation();const isOpen=navUserMenu.classList.toggle('open');navUserToggle.setAttribute('aria-expanded',isOpen)});
  document.addEventListener('click',e=>{const navUser=document.getElementById('navUser');if(navUser&&!navUser.contains(e.target)){navUserMenu.classList.remove('open');navUserToggle.setAttribute('aria-expanded','false')}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){navUserMenu.classList.remove('open');navUserToggle.setAttribute('aria-expanded','false')}});
}
</script>
</body>
</html>