<?php
/**
 * get_scholarships.php
 * Public JSON API — returns all scholarships from Firestore.
 * Called by scholarship.php via fetch() on the frontend.
 * Uses config.php + ScholarshipManager.php (no hardcoded credentials).
 */

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once 'config.php';
require_once 'ScholarshipManager.php';

$manager = new ScholarshipManager();
$result  = $manager->getAllScholarships();

if ($result['success']) {
    echo json_encode([
        'success'      => true,
        'scholarships' => $result['scholarships'],
        'count'        => count($result['scholarships']),
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        'success'      => false,
        'message'      => $result['message'] ?? 'Failed to load scholarships.',
        'scholarships' => [],
        'count'        => 0,
    ]);
}
