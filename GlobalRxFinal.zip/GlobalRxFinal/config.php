<?php

define('FIREBASE_PROJECT_ID', 'globalrx-9085e');
define('FIREBASE_API_KEY',    'AIzaSyA8wy_aEO2Pc3uMaNPyEEN2UsoGE9nQzeU');
