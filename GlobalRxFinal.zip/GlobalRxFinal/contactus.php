<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;
$firstName  = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName   = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email      = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role       = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');
$initial    = !empty($firstName) ? strtoupper($firstName[0]) : '?';
if (empty($fullName) && !empty($firstName)) $fullName = $firstName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us – Global RX Business</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800&family=Barlow+Condensed:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="contactus.css">
<style>
/* ── NAV USER WIDGET ── */
.nav-user{position:relative}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #d0d0d0;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#111;transition:border-color .2s,background .2s;font-family:inherit}
.nav-user-toggle:hover{border-color:var(--red,#e63946);background:rgba(230,57,70,0.05)}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:var(--red,#e63946);overflow:hidden;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0}
.nav-user-name{font-size:14px;font-weight:600;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111}
.nav-chevron{display:flex;align-items:center}
.nav-chevron svg{width:10px;height:6px;stroke:#555;fill:none;stroke-width:2;transition:transform .25s}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg)}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:280px;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.14);border:1px solid #ececec;padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px}
.num-avatar-lg{width:48px;height:48px;border-radius:50%;background:var(--red,#e63946);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:19px;color:#fff;flex-shrink:0;overflow:hidden}
.num-info{flex:1;min-width:0}
.num-name{font-size:14px;font-weight:700;color:#111;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-email{font-size:12px;color:#888;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#f0f0f0;color:#555;font-size:10px;font-weight:700;letter-spacing:.5px;border-radius:50px;text-transform:capitalize}
.num-divider{height:1px;background:#f0f0f0;margin:4px 0}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#222;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#888;fill:currentColor}
.num-item:hover{background:#f6f6f6}
.num-logout{color:#e63946 !important}
.num-logout svg{color:#e63946 !important}
.num-logout:hover{background:#fff3f3 !important}
@media(max-width:768px){.nav-user-menu{width:260px;right:-10px}.nav-user-name{display:none}}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <div id="navLoggedOut">
    <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  </div>
  <?php endif; ?>
</nav>

<!-- HERO BANNER -->
<div class="hero-banner">
  <h1>Contact Us</h1>
  <div class="breadcrumb">
    <a href="index.php">Home</a>
    <span class="sep">›</span>
    <span>Contact Us</span>
  </div>
</div>

<!-- CONTACT INFO SECTION -->
<section class="contact-info-section">
  <div class="contact-photo">
    <img src="https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=700&q=80" alt="Global RX Support Team" />
  </div>
  <div class="contact-info-content">
    <div class="section-label">Get In Touch</div>
    <h2>Contact<br>Information</h2>
    <p>We're here to help you navigate every step of your journey — from visa consulting to higher education pathways. Reach out and our team will respond promptly.</p>
    <div class="info-item">
      <div class="info-icon"><svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg></div>
      <div class="info-text"><h4>Our Address</h4><p>Global RX Business LTD<br>London, United Kingdom</p></div>
    </div>
    <div class="info-item">
      <div class="info-icon"><svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></div>
      <div class="info-text"><h4>Free Call Centre</h4><p>+44 1234 56789</p></div>
    </div>
    <div class="info-item">
      <div class="info-icon"><svg viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg></div>
      <div class="info-text"><h4>Email Address</h4><p>info@globalrx.co.uk<br>support@globalrx.co.uk</p></div>
    </div>
  </div>
</section>

<!-- ENQUIRY FORM SECTION -->
<section class="enquiry-section" id="enquiry">
  <div class="enquiry-photo-left"></div>
  <div class="enquiry-form-wrap">
    <div class="section-label">Contact Us</div>
    <h2>Feel Free To Enquire<br>About Any Question.</h2>
    <p>Our consultants are available to answer your queries about visas, higher education, and language programmes. Fill in the form and we'll be in touch shortly.</p>
    <form id="contactForm" class="contact-form" novalidate>
      <input type="text" name="fullName" id="fullName" placeholder="Full Name" required />
      <div class="form-row">
        <input type="email" name="email" id="email" placeholder="Email Address" required />
        <input type="tel" name="phone" id="phone" placeholder="Phone Number" required />
      </div>
      <textarea name="message" id="message" placeholder="Your Message" required></textarea>
      <button class="btn-send" type="submit" id="sendMessageBtn">
        <span id="sendMessageText">Send Message</span>
        <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
      </button>
      <div id="formError" style="display:none;margin-top:12px;color:#c0392b;font-weight:600"></div>
    </form>
  </div>
  <div class="enquiry-photo-right"></div>
</section>

<!-- MAP SECTION -->
<section class="map-section">
  <div class="map-header">
    <div class="map-header-left">
      <div class="section-label">Find Location</div>
      <h2>Global RX<br>London, United Kingdom</h2>
    </div>
    <div class="map-header-right">
      <a href="https://maps.google.com/?q=London,United+Kingdom" target="_blank" class="map-btn">
        Get Directions
        <svg viewBox="0 0 24 24"><path d="M21.71 11.29l-9-9a1 1 0 0 0-1.42 0l-9 9a1 1 0 0 0 0 1.42l9 9a1 1 0 0 0 1.42 0l9-9a1 1 0 0 0 0-1.42zM14 14.5V12h-4v3H8v-4a1 1 0 0 1 1-1h5V7.5l3.5 3.5-3.5 3.5z"/></svg>
      </a>
    </div>
  </div>
  <iframe class="map-embed"
    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d158858.47340002482!2d-0.24168120642509524!3d51.52855824164916!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a00baf21de75%3A0x52963a5addd52a99!2sLondon%2C%20UK!5e0!3m2!1sen!2slk!4v1709000000000!5m2!1sen!2slk"
    allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Global RX London Location">
  </iframe>
</section>

<!-- CTA STRIP -->
<div class="cta-strip">
  <div class="cta-strip-left">
    <h3>Let's Get Started With Us</h3>
    <p>Further Info &amp; Support Team — we're ready to help.</p>
  </div>
  <div class="cta-strip-right">
    <div class="cta-phone-icon"><svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg></div>
    <div class="cta-phone-text">
      <small>Feel Free To Call Us</small>
      <strong>+44 1234 56789</strong>
    </div>
  </div>
</div>

<!-- SUCCESS POPUP -->
<div id="contactPopup" style="position:fixed;inset:0;background:rgba(0,0,0,.45);display:none;align-items:center;justify-content:center;z-index:9999;padding:20px;">
  <div style="background:#fff;max-width:420px;width:100%;border-radius:18px;padding:28px 24px;text-align:center;box-shadow:0 20px 50px rgba(0,0,0,.18);">
    <div style="width:70px;height:70px;border-radius:50%;background:#eafaf1;color:#1e8449;display:flex;align-items:center;justify-content:center;font-size:34px;margin:0 auto 16px;">✓</div>
    <h3 style="margin:0 0 8px;font-size:28px;color:#143125;">Message Sent</h3>
    <p style="margin:0 0 18px;color:#4d5b55;line-height:1.6;">Your message was sent successfully. Our team will contact you soon.</p>
    <button type="button" id="closeContactPopup" style="border:none;background:#c62828;color:#fff;padding:12px 24px;border-radius:999px;font-weight:700;cursor:pointer;">OK</button>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col"><h4>PAGES</h4><ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
      </ul></div>
      <div class="footer-col"><h4>SUBSIDIARIES</h4><ul>
        <li><a href="visa.php">A² Visa Consultation</a></li>
        <li><a href="higherEducation.php">A² Higher Education</a></li>
        <li><a href="english.php">A² English Academy</a></li>
      </ul></div>
      <div class="footer-col"><h4>CONTACT</h4><ul>
        <li><span>info@globalrx.co.uk</span></li>
        <li><span>+44 1234 56789</span></li>
        <li><span>London, United Kingdom</span></li>
      </ul></div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:#22c55e"></div>
        <div class="dot" style="background:#eab308"></div>
      </div>
    </div>
  </div>
</footer>

<script>
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const t = document.querySelector(a.getAttribute('href'));
      if(t) t.scrollIntoView({ behavior: 'smooth' });
    });
  });

  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 8px 32px rgba(0,0,0,0.14)'
      : '0 4px 24px rgba(0,0,0,0.06)';
  });

  function toggleDropdown() {
    document.getElementById('divDropdown').classList.toggle('open');
  }
  document.addEventListener('click', e => {
    const dd = document.getElementById('divDropdown');
    if (!dd.contains(e.target)) dd.classList.remove('open');
  });

  // User menu
  const navUserToggle = document.getElementById('navUserToggle');
  const navUserMenu   = document.getElementById('navUserMenu');
  if (navUserToggle && navUserMenu) {
    navUserToggle.addEventListener('click', e => {
      e.stopPropagation();
      const isOpen = navUserMenu.classList.toggle('open');
      navUserToggle.setAttribute('aria-expanded', isOpen);
    });
    document.addEventListener('click', e => {
      const navUser = document.getElementById('navUser');
      if (navUser && !navUser.contains(e.target)) {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Contact form
  const contactForm  = document.getElementById('contactForm');
  const popup        = document.getElementById('contactPopup');
  const closePopupBtn = document.getElementById('closeContactPopup');
  const formError    = document.getElementById('formError');
  const sendBtn      = document.getElementById('sendMessageBtn');
  const sendText     = document.getElementById('sendMessageText');

  function closeContactPopup() { popup.style.display = 'none'; }
  closePopupBtn.addEventListener('click', closeContactPopup);
  popup.addEventListener('click', e => { if (e.target === popup) closeContactPopup(); });

  contactForm.addEventListener('submit', async e => {
    e.preventDefault();
    formError.style.display = 'none';
    formError.textContent   = '';

    const formData = new FormData(contactForm);
    const fullName = formData.get('fullName').toString().trim();
    const email    = formData.get('email').toString().trim();
    const phone    = formData.get('phone').toString().trim();
    const message  = formData.get('message').toString().trim();

    if (!fullName || !email || !phone || !message) {
      formError.textContent   = 'Please fill in all fields.';
      formError.style.display = 'block';
      return;
    }

    sendBtn.disabled     = true;
    sendText.textContent = 'Sending...';

    try {
      const response = await fetch('contact_submit.php', { method: 'POST', body: formData });
      const data     = await response.json();
      if (!response.ok || !data.success) throw new Error(data.message || 'Unable to send your message right now.');
      contactForm.reset();
      popup.style.display = 'flex';
    } catch (error) {
      formError.textContent   = error.message || 'Something went wrong. Please try again.';
      formError.style.display = 'block';
    } finally {
      sendBtn.disabled     = false;
      sendText.textContent = 'Send Message';
    }
  });
</script>
</body>
</html>