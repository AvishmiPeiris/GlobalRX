<?php
require_once 'DiplomaManager.php';

$diplomaManager = new DiplomaManager();
$result         = $diplomaManager->getAllDiplomas();
$diplomas       = $result['success'] ? $result['diplomas'] : [];
$fetchError     = $result['success'] ? '' : ($result['message'] ?? 'Could not load diplomas from Firestore.');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Diploma Programs</title>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    :root{
      --orange:#d4842a;--orange-light:#fdf3dc;--orange-mid:#e9a84c;
      --bg:#f5f7f5;--card-bg:#ffffff;--text:#1a1a1a;--muted:#6b7280;--radius:18px;
    }
    body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;padding:60px 40px}
    .section-label{display:inline-flex;align-items:center;gap:8px;background:var(--orange-light);color:var(--orange);font-size:12px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;padding:6px 16px;border-radius:100px;margin-bottom:22px}
    .section-label::before{content:'';width:7px;height:7px;background:var(--orange);border-radius:50%}
    .section-heading{font-family:'DM Serif Display',serif;font-size:clamp(2rem,4vw,3rem);line-height:1.15;margin-bottom:48px;max-width:600px}
    .section-heading em{font-style:italic;color:var(--orange)}
    .courses-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
    @media(max-width:900px){.courses-grid{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:580px){.courses-grid{grid-template-columns:1fr}}
    .card{background:var(--card-bg);border-radius:var(--radius);overflow:hidden;box-shadow:0 2px 16px rgba(0,0,0,.06);transition:transform .25s ease,box-shadow .25s ease;display:flex;flex-direction:column}
    .card:hover{transform:translateY(-5px);box-shadow:0 12px 36px rgba(212,132,42,.14)}
    .card-image{position:relative;height:160px;overflow:hidden;background:var(--orange-light)}
    .card-image img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease}
    .card:hover .card-image img{transform:scale(1.05)}
    .card-image-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:48px;background:linear-gradient(135deg,var(--orange-light),#f5d9aa)}
    .card-tag{position:absolute;top:14px;left:14px;background:rgba(255,255,255,.88);backdrop-filter:blur(6px);color:var(--orange);font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:5px 12px;border-radius:100px}
    .card-body{padding:14px 16px 10px;flex:1;display:flex;flex-direction:column;gap:10px}
    .card-title{font-family:'DM Serif Display',serif;font-size:0.95rem;line-height:1.35;color:var(--text)}
    .meta-list{display:flex;flex-direction:column;gap:6px}
    .meta-item{display:flex;flex-direction:column;background:var(--orange-light);border-radius:8px;padding:7px 10px}
    .meta-label{font-size:9px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--orange);margin-bottom:2px}
    .meta-value{font-size:12px;font-weight:500;color:var(--text);line-height:1.3}
    .card-footer{display:flex;align-items:center;justify-content:flex-end;padding:0 16px 14px;margin-top:auto}
    .enroll-btn{background:var(--orange-light);color:var(--orange);border:none;border-radius:100px;padding:7px 20px;font-size:12px;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;transition:background .2s,color .2s}
    .enroll-btn:hover{background:var(--orange);color:#fff}
    .state-box{grid-column:1/-1;text-align:center;padding:60px 20px;color:var(--muted)}
    .state-box span{font-size:48px;display:block;margin-bottom:14px}
    .state-box p{font-size:14px}
    .error-box{background:#fff3cd;border:1.5px solid #ffc107;border-radius:12px;padding:14px 18px;font-size:13px;color:#856404;margin-bottom:24px}
  </style>
</head>
<body>

  <span class="section-label">Diploma Programs</span>
  <h1 class="section-heading">Our Diplomas — <em>Practical</em><br>Career-Ready Qualifications</h1>

  <?php if ($fetchError): ?>
  <div class="error-box">⚠️ <?= htmlspecialchars($fetchError) ?></div>
  <?php endif; ?>

  <div class="courses-grid">

    <?php if (empty($diplomas) && !$fetchError): ?>
      <div class="state-box">
        <span>📜</span>
        <p>No diploma programs available yet. Check back soon!</p>
      </div>

    <?php else: ?>
      <?php foreach ($diplomas as $d): ?>
      <?php
        $tag = !empty($d['field']) ? $d['field'] : 'Diploma';
        $tag = strlen($tag) > 20 ? substr($tag, 0, 20) . '…' : $tag;
      ?>
      <div class="card">

        <!-- IMAGE / PLACEHOLDER -->
        <div class="card-image">
          <?php if (!empty($d['imageUrl'])): ?>
            <img src="<?= htmlspecialchars($d['imageUrl']) ?>"
                 alt="<?= htmlspecialchars($d['diplomaName']) ?>"
                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="card-image-placeholder" style="display:none">📜</div>
          <?php else: ?>
            <div class="card-image-placeholder">📜</div>
          <?php endif; ?>
          <span class="card-tag"><?= htmlspecialchars($tag) ?></span>
        </div>

        <!-- BODY -->
        <div class="card-body">
          <div class="card-title"><?= htmlspecialchars($d['diplomaName']) ?></div>
          <div class="meta-list">
            <?php if (!empty($d['university'])): ?>
            <div class="meta-item">
              <span class="meta-label">University</span>
              <span class="meta-value"><?= htmlspecialchars($d['university']) ?></span>
            </div>
            <?php endif; ?>
            <?php if (!empty($d['field'])): ?>
            <div class="meta-item">
              <span class="meta-label">Field</span>
              <span class="meta-value"><?= htmlspecialchars($d['field']) ?></span>
            </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- FOOTER -->
        <div class="card-footer">
          <a href="enrollment.html">
            <button class="enroll-btn">Enroll Now</button>
          </a>
        </div>

      </div>
      <?php endforeach; ?>
    <?php endif; ?>

  </div>

</body>
</html>
