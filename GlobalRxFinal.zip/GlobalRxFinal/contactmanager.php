<?php
require_once __DIR__ . '/config.php';

class ContactManager
{
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    private array $certPaths = [
        'C:/xampp/php/extras/ssl/cacert.pem',
        'C:/xampp/apache/conf/ssl.crt/cacert.pem',
        'C:/xampp/php/cacert.pem',
        'C:/curl/cacert.pem',
    ];

    public function __construct()
    {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/contact_messages";
    }

    private function getCertPath(): string
    {
        $ini = ini_get('curl.cainfo');
        if ($ini && file_exists($ini)) return $ini;
        foreach ($this->certPaths as $p) {
            if (file_exists($p)) return $p;
        }
        $local = __DIR__ . '/cacert.pem';
        return file_exists($local) ? $local : '';
    }

    private function request(string $method, string $url, ?array $body = null): array
    {
        $sep  = str_contains($url, '?') ? '&' : '?';
        $url .= "{$sep}key={$this->apiKey}";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 20,
        ]);

        $certPath = $this->getCertPath();
        if ($certPath !== '') {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_CAINFO, $certPath);
        } else {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        }

        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr) return ['success' => false, 'message' => "cURL error: $curlErr"];
        if ($response === false || $response === '') return ['success' => false, 'message' => "Empty response (HTTP $httpCode)"];

        $data = json_decode($response, true);
        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP $httpCode";
            return ['success' => false, 'message' => "Firestore error ($httpCode): $msg"];
        }

        return ['success' => true, 'data' => $data];
    }

    private function extractValue(array $tv): mixed
    {
        if (isset($tv['stringValue'])) return (string)$tv['stringValue'];
        if (isset($tv['integerValue'])) return (int)$tv['integerValue'];
        if (isset($tv['booleanValue'])) return (bool)$tv['booleanValue'];
        if (isset($tv['timestampValue'])) {
            try {
                $dt = new DateTime($tv['timestampValue']);
                $dt->setTimezone(new DateTimeZone('Asia/Colombo'));
                return $dt->format('d M Y, H:i');
            } catch (Exception) {
                return $tv['timestampValue'];
            }
        }
        return '';
    }

    private function parseDoc(array $doc): array
    {
        $fields = $doc['fields'] ?? [];
        $id = basename($doc['name'] ?? '');
        $sortKey = 0;
        if (isset($fields['createdAt']['timestampValue'])) {
            try {
                $sortKey = (new DateTime($fields['createdAt']['timestampValue']))->getTimestamp();
            } catch (Exception) {
                $sortKey = 0;
            }
        }

        return [
            'id'        => $id,
            'fullName'  => isset($fields['fullName']) ? (string)$this->extractValue($fields['fullName']) : '',
            'email'     => isset($fields['email']) ? (string)$this->extractValue($fields['email']) : '',
            'phone'     => isset($fields['phone']) ? (string)$this->extractValue($fields['phone']) : '',
            'message'   => isset($fields['message']) ? (string)$this->extractValue($fields['message']) : '',
            'status'    => isset($fields['status']) ? (string)$this->extractValue($fields['status']) : 'New',
            'createdAt' => isset($fields['createdAt']) ? (string)$this->extractValue($fields['createdAt']) : '',
            '_sortKey'  => $sortKey,
        ];
    }

    public function getAllMessages(): array
    {
        $res = $this->request('GET', $this->baseUrl);
        if (!$res['success']) return $res;

        $messages = [];
        foreach ($res['data']['documents'] ?? [] as $doc) {
            $parsed = $this->parseDoc($doc);
            if (!empty($parsed['id'])) $messages[] = $parsed;
        }
        usort($messages, fn($a, $b) => $b['_sortKey'] <=> $a['_sortKey']);
        return ['success' => true, 'messages' => $messages];
    }

    public function addMessage(string $fullName, string $email, string $phone, string $message): array
    {
        $fullName = trim($fullName);
        $email = trim($email);
        $phone = trim($phone);
        $message = trim($message);

        if ($fullName === '') return ['success' => false, 'message' => 'Full name is required.'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['success' => false, 'message' => 'A valid email address is required.'];
        if ($phone === '') return ['success' => false, 'message' => 'Phone number is required.'];
        if ($message === '') return ['success' => false, 'message' => 'Message is required.'];

        $body = [
            'fields' => [
                'fullName'  => ['stringValue' => $fullName],
                'email'     => ['stringValue' => $email],
                'phone'     => ['stringValue' => $phone],
                'message'   => ['stringValue' => $message],
                'status'    => ['stringValue' => 'New'],
                'createdAt' => ['timestampValue' => gmdate('Y-m-d\TH:i:s\Z')],
            ]
        ];

        $res = $this->request('POST', $this->baseUrl, $body);
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => 'Message sent successfully.'];
    }

    public function updateMessage(string $id, string $fullName, string $email, string $phone, string $message, string $status): array
    {
        if (trim($id) === '') return ['success' => false, 'message' => 'Message ID is required.'];
        if (trim($fullName) === '') return ['success' => false, 'message' => 'Full name is required.'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return ['success' => false, 'message' => 'A valid email address is required.'];
        if (trim($message) === '') return ['success' => false, 'message' => 'Message is required.'];

        $fields = ['fullName','email','phone','message','status'];
        $mask = implode('&', array_map(fn($f) => "updateMask.fieldPaths={$f}", $fields));
        $body = [
            'fields' => [
                'fullName' => ['stringValue' => trim($fullName)],
                'email'    => ['stringValue' => trim($email)],
                'phone'    => ['stringValue' => trim($phone)],
                'message'  => ['stringValue' => trim($message)],
                'status'   => ['stringValue' => trim($status) !== '' ? trim($status) : 'New'],
            ]
        ];

        $res = $this->request('PATCH', "{$this->baseUrl}/{$id}?{$mask}", $body);
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => 'Contact message updated successfully.'];
    }

    public function deleteMessage(string $id): array
    {
        if (trim($id) === '') return ['success' => false, 'message' => 'Message ID is required.'];
        $res = $this->request('DELETE', "{$this->baseUrl}/{$id}");
        if (!$res['success']) return $res;
        return ['success' => true, 'message' => 'Contact message deleted successfully.'];
    }
}