<?php
require_once 'config.php';

class DiplomaManager {
    private string $projectId;
    private string $apiKey;
    private string $baseUrl;

    public function __construct() {
        $this->projectId = FIREBASE_PROJECT_ID;
        $this->apiKey    = FIREBASE_API_KEY;
        $this->baseUrl   = "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents/Diploma";
    }

    private function request(string $method, string $url, ?array $body = null): array {
        $url .= (str_contains($url, '?') ? '&' : '?') . "key={$this->apiKey}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['success' => false, 'message' => "cURL error: {$curlError}"];
        }

        $data = json_decode($response, true);

        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "HTTP {$httpCode} — " . substr($response, 0, 200);
            return ['success' => false, 'message' => "Firestore error: $msg"];
        }

        return ['success' => true, 'data' => $data];
    }

    private function parseDoc(array $doc): array {
        $fields = $doc['fields'] ?? [];
        $id     = basename($doc['name'] ?? '');
        return [
            'id'          => $id,
            'diplomaName' => $fields['diplomaName']['stringValue'] ?? '',
            'field'       => $fields['field']['stringValue']       ?? '',
            'university'  => $fields['university']['stringValue']  ?? '',
            'imageUrl'    => $fields['imageUrl']['stringValue']    ?? '',
        ];
    }

    private function buildDoc(string $diplomaName, string $field, string $university, string $imageUrl): array {
        return [
            'fields' => [
                'diplomaName' => ['stringValue' => $diplomaName],
                'field'       => ['stringValue' => $field],
                'university'  => ['stringValue' => $university],
                'imageUrl'    => ['stringValue' => $imageUrl],
            ]
        ];
    }

    public function getAllDiplomas(): array {
        $result = $this->request('GET', $this->baseUrl);
        if (!$result['success']) return $result;

        $diplomas = [];
        foreach ($result['data']['documents'] ?? [] as $doc) {
            $diplomas[] = $this->parseDoc($doc);
        }
        return ['success' => true, 'diplomas' => $diplomas];
    }

    public function addDiploma(string $diplomaId, string $diplomaName, string $field, string $university, string $imageUrl): array {
        if (empty($diplomaId) || empty($diplomaName)) {
            return ['success' => false, 'message' => 'Diploma ID and name are required.'];
        }
        $url    = $this->baseUrl . '?documentId=' . urlencode($diplomaId);
        $result = $this->request('POST', $url, $this->buildDoc($diplomaName, $field, $university, $imageUrl));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Diploma '{$diplomaName}' added successfully."];
    }

    public function updateDiploma(string $diplomaId, string $diplomaName, string $field, string $university, string $imageUrl): array {
        if (empty($diplomaId) || empty($diplomaName)) {
            return ['success' => false, 'message' => 'Diploma ID and name are required.'];
        }
        $mask   = 'updateMask.fieldPaths=diplomaName&updateMask.fieldPaths=field&updateMask.fieldPaths=university&updateMask.fieldPaths=imageUrl';
        $url    = "{$this->baseUrl}/{$diplomaId}?{$mask}";
        $result = $this->request('PATCH', $url, $this->buildDoc($diplomaName, $field, $university, $imageUrl));
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => "Diploma '{$diplomaName}' updated successfully."];
    }

    public function deleteDiploma(string $diplomaId): array {
        if (empty($diplomaId)) {
            return ['success' => false, 'message' => 'Diploma ID is required.'];
        }
        $result = $this->request('DELETE', "{$this->baseUrl}/{$diplomaId}");
        if (!$result['success']) return $result;
        return ['success' => true, 'message' => 'Diploma deleted successfully.'];
    }
}
