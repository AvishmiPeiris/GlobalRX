<?php
header('Content-Type: application/json');
require_once __DIR__ . '/ContactManager.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

$manager = new ContactManager();
$result = $manager->addMessage(
    $_POST['fullName'] ?? '',
    $_POST['email'] ?? '',
    $_POST['phone'] ?? '',
    $_POST['message'] ?? ''
);

http_response_code($result['success'] ? 200 : 400);
echo json_encode($result);