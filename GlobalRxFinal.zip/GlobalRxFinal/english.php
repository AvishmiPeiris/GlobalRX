<?php
session_start();

$isLoggedIn = !empty($_SESSION['signed_in']) && $_SESSION['signed_in'] === true;

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');

$initial = !empty($firstName) ? strtoupper($firstName[0]) : '?';

if (empty($fullName) && !empty($firstName)) {
    $fullName = $firstName;
}

require_once 'CourseManager.php';
$cm      = new CourseManager();
$result  = $cm->getAllCourses();
$courses = $result['success'] ? $result['courses'] : [];
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>A-Squared English Academy</title>
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800&family=Barlow+Condensed:wght@400;600;700;800&family=Montserrat:wght@400;600;700;800;900&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="englishAc.css">
  <style>
  /* ── NAV USER WIDGET ── */
  .nav-user { position: relative; }
  .nav-user-toggle {
    display: flex; align-items: center; gap: 8px;
    background: none; border: 1.5px solid #d0d0d0;
    border-radius: 50px; padding: 5px 14px 5px 6px;
    cursor: pointer; color: #111; transition: border-color .2s, background .2s;
    font-family: inherit;
  }
  .nav-user-toggle:hover { border-color: var(--red, #e63946); background: rgba(230,57,70,0.05); }
  .nav-avatar {
    width: 32px; height: 32px; border-radius: 50%;
    background: var(--red, #e63946); overflow: hidden;
    display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 14px; color: #fff; flex-shrink: 0;
  }
  .nav-avatar img { width: 100%; height: 100%; object-fit: cover; }
  .nav-user-name {
    font-size: 14px; font-weight: 600;
    max-width: 90px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    color: #111;
  }
  .nav-chevron { display: flex; align-items: center; }
  .nav-chevron svg {
    width: 10px; height: 6px; stroke: #555;
    fill: none; stroke-width: 2; transition: transform .25s;
  }
  .nav-user-toggle[aria-expanded="true"] .nav-chevron svg { transform: rotate(180deg); }

  /* Dropdown panel */
  .nav-user-menu {
    position: absolute; right: 0; top: calc(100% + 12px);
    width: 280px; background: #fff; border-radius: 16px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.14);
    border: 1px solid #ececec;
    padding: 8px;
    opacity: 0; transform: translateY(-8px) scale(.97);
    pointer-events: none; transition: opacity .22s, transform .22s;
    z-index: 1000;
  }
  .nav-user-menu.open {
    opacity: 1; transform: translateY(0) scale(1); pointer-events: all;
  }

  /* Profile header */
  .num-header {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 8px 12px;
  }
  .num-avatar-lg {
    width: 48px; height: 48px; border-radius: 50%; background: var(--red, #e63946);
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 19px; color: #fff; flex-shrink: 0; overflow: hidden;
  }
  .num-avatar-lg img { width: 100%; height: 100%; object-fit: cover; }
  .num-info { flex: 1; min-width: 0; }
  .num-name  { font-size: 14px; font-weight: 700; color: #111; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .num-email { font-size: 12px; color: #888; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .num-badge {
    display: inline-block;
    margin-top: 4px;
    padding: 2px 8px;
    background: #f0f0f0;
    color: #555;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.5px;
    border-radius: 50px;
    text-transform: capitalize;
  }
  .num-divider { height: 1px; background: #f0f0f0; margin: 4px 0; }
  .num-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 12px; border-radius: 10px; font-size: 13px; font-weight: 500;
    color: #222; text-decoration: none; transition: background .15s;
    width: 100%; background: none; border: none; cursor: pointer;
    text-align: left; font-family: inherit;
  }
  .num-item svg {
    width: 16px; height: 16px; flex-shrink: 0;
    color: #888; fill: currentColor;
  }
  .num-item:hover { background: #f6f6f6; }
  .num-logout { color: var(--red, #e63946) !important; }
  .num-logout svg { color: var(--red, #e63946) !important; }
  .num-logout:hover { background: #fff3f3 !important; }

  @media (max-width: 768px) {
    .nav-user-menu { width: 260px; right: -10px; }
    .nav-user-name { display: none; }
  }
  </style>
</head>
<body>

<!-- ══ NAV ══════════════════════════════════════════ -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared Higher Education Institute</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.php">About Us</a></li>
    <li><a href="contactus.php">Contact Us</a></li>
  </ul>

  <?php if ($isLoggedIn): ?>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron">
        <svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg>
      </span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <?php if ($role === 'admin' || $role === 'temp_admin'): ?>
      <a href="admin.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        Admin Dashboard
      </a>
      <?php else: ?>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        My Dashboard
      </a>
      <?php endif; ?>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z" fill="currentColor"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z" fill="currentColor"/></svg>
        Log Out
      </a>
    </div>
  </div>
  <?php else: ?>
  <div id="navLoggedOut">
    <a href="signup.html"><button class="nav-btn">Sign Up</button></a>
  </div>
  <?php endif; ?>
</nav>

<!-- ══ HERO BANNER ══════════════════════════════════ -->
<div class="hero-banner">
  <h1>English <span>Academy</span></h1>
  <div class="breadcrumb">
    <a href="index.php">Home</a>
    <span class="sep">›</span>
    <span class="bc-active">English Academy</span>
  </div>
</div>

<!-- ══ ABOUT ════════════════════════════════════════ -->
<section class="about-strip">
  <div class="about-left">
    <div class="sec-label">Who We Are</div>
    <h2 class="sec-title">A-SQUARED ACADEMY<br>AROUND <span class="hl">THE WORLD</span></h2>
    <p class="sec-text">A-Squared Academy is a leading provider of English language training programmes, serving students globally. Our expert tutors and accredited courses help learners of all levels achieve their goals — from business communication to Cambridge qualifications and TEFL certification.</p>
  </div>
  <div class="about-right">
    <div class="about-right-wrap">
      <div class="about-img-grid">
        <div class="aib tall"><img src="images/girl.jpg.jpg" style="width:100%;height:100%;object-fit:cover;" /></div>
        <div class="aib tall"><img src="images/all.jpg.jpg"  style="width:100%;height:100%;object-fit:cover;" /></div>
      </div>
      <div class="about-badge">2,400+<small>Students</small></div>
    </div>
  </div>
</section>

<!-- ══ STATS BAR ═════════════════════════════════════ -->
<div class="stats-bar">
  <div class="stat-item"><div class="stat-num">IELTS</div><div class="stat-lbl">Preparation</div></div>
  <div class="stat-item"><div class="stat-num">Cambridge</div><div class="stat-lbl">Qualifications</div></div>
  <div class="stat-item"><div class="stat-num">Business</div><div class="stat-lbl">English</div></div>
  <div class="stat-item"><div class="stat-num">TEFL</div><div class="stat-lbl">Certification</div></div>
  <div class="stat-item"><div class="stat-num">Academic</div><div class="stat-lbl">English</div></div>
</div>

<!-- ══ PROGRAMMES ════════════════════════════════════ -->
<section class="programmes">
  <div class="sec-header">
    <div>
      <div class="sec-label">What We Offer</div>
      <h2 class="sec-title">EXPLORE OUR <span class="hl">PROGRAMMES</span></h2>
    </div>
  </div>

  <div class="prog-grid">
    <?php if (!empty($courses)): ?>
      <?php foreach ($courses as $course): ?>
        <div class="prog-card">
          <div class="prog-icon">
            <?php if (!empty($course['iconUrl'])): ?>
              <img src="<?php echo htmlspecialchars($course['iconUrl']); ?>"
                   alt="<?php echo htmlspecialchars($course['cname']); ?>"
                   style="width:100%;height:100%;object-fit:contain;">
            <?php else: ?>
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3zM5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/>
              </svg>
            <?php endif; ?>
          </div>
          <p class="prog-title"><?php echo htmlspecialchars($course['cname']); ?></p>
          <p class="prog-description"><?php echo htmlspecialchars($course['description']); ?></p>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p style="grid-column:1/-1;text-align:center;color:#888;padding:40px 0;">
        No programmes available at the moment.
      </p>
    <?php endif; ?>
  </div>
</section>

<!-- ══ CAMBRIDGE ══════════════════════════════════════ -->
<section class="cambridge">
  <div class="cambridge-left">
    <div class="sec-label">Internationally Recognised</div>
    <h2 class="sec-title">CAMBRIDGE <span class="hl">ENGLISH</span> QUALIFICATIONS</h2>
    <p class="sec-text">Our Cambridge-approved programmes prepare students for globally recognised English qualifications. Whether you're aiming for B2 First, C1 Advanced or C2 Proficiency, our expert tutors guide you every step of the way.</p>
    <div class="cam-stats">
      <div class="cam-stat"><div class="cam-stat-num">B1</div><div class="cam-stat-lbl">Preliminary</div></div>
      <div class="cam-stat"><div class="cam-stat-num">B2</div><div class="cam-stat-lbl">First</div></div>
      <div class="cam-stat"><div class="cam-stat-num">C1</div><div class="cam-stat-lbl">Advanced</div></div>
      <div class="cam-stat"><div class="cam-stat-num">C2</div><div class="cam-stat-lbl">Proficiency</div></div>
    </div>
  </div>
  <div class="cambridge-right">
    <img src="images/cambridge.jpg" style="width:100%;height:100%;object-fit:cover;display:block;" />
  </div>
</section>

<!-- ══ ACCREDITED ═════════════════════════════════════ -->
<section class="accredited">
  <div class="accredited-left">
    <div class="acc-img-ph">
      <img src="images/teach.jpg" style="width:100%;height:100%;min-height:280px;object-fit:cover;display:block;" />
    </div>
  </div>
  <div class="accredited-right">
    <div class="sec-label">Credentials That Count</div>
    <h2 class="sec-title">ACCREDITED TEACHING<br><span class="hl">QUALIFICATIONS</span></h2>
    <ul class="acc-list">
      <li><div class="acc-dot"></div><div><p class="acc-item-title">Level 5 TEFL Certification</p><p>Internationally recognised — accepted in over 80 countries worldwide.</p></div></li>
      <li><div class="acc-dot"></div><div><p class="acc-item-title">Ofqual Regulated Qualifications</p><p>Regulated by Ofqual and recognised by top employers globally.</p></div></li>
      <li><div class="acc-dot"></div><div><p class="acc-item-title">CPD Accredited Courses</p><p>Continuing Professional Development credits accepted across all sectors.</p></div></li>
    </ul>
  </div>
</section>

<!-- ══ TEFL ═══════════════════════════════════════════ -->
<section class="tefl">
  <div>
    <div class="sec-label">Teach English Globally</div>
    <h2 class="sec-title">WHY CHOOSE OUR <span class="hl">TEFL</span> PROGRAMME?</h2>
    <ul class="tefl-list">
      <li><span class="tag-pill">01</span> Internationally accredited with placements in 80+ countries</li>
      <li><span class="tag-pill">02</span> Flexible online study — complete at your own pace</li>
      <li><span class="tag-pill">03</span> Dedicated job placement support and career guidance</li>
      <li><span class="tag-pill">04</span> Expert tutors with 10+ years classroom experience</li>
    </ul>
  </div>
  <div style="display:flex;align-items:center;justify-content:center;">
    <div class="tefl-badge">
      <span class="tefl-badge-top">TEFL</span>
      <span class="tefl-badge-mid">120</span>
      <span class="tefl-badge-bot">Hours</span>
    </div>
  </div>
</section>

<!-- ══ BIG STATS ══════════════════════════════════════ -->
<div class="big-stats">
  <div class="big-stat"><div class="big-stat-num">2,400<sup>+</sup></div><div class="big-stat-lbl">Students Enrolled</div></div>
  <div class="big-stat"><div class="big-stat-num">89<sup>%</sup></div><div class="big-stat-lbl">Pass Rate</div></div>
  <div class="big-stat"><div class="big-stat-num">12<sup>+</sup></div><div class="big-stat-lbl">Years Experience</div></div>
  <div class="big-stat"><div class="big-stat-num">40<sup>+</sup></div><div class="big-stat-lbl">Expert Tutors</div></div>
</div>

<!-- ══ ENROLLMENT BANNER ══════════════════════════════ -->
<div class="cta-banner">
  <div>
    <p class="cta-sub">Enrolment Now Open</p>
    <h2 class="cta-title">WANT TO JOIN OUR <span>COURSES?</span> YOU HAVE TO ENROL</h2>
  </div>
  <a href="enrollment.php">
    <button class="btn-white">Enroll Now</button>
  </a>
</div>

<!-- ══ FOOTER ════════════════════════════════════════ -->
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div class="footer-brand">
        <span class="nav-logo">GLOBAL <span style="color:var(--red)">RX</span></span>
        <p>Empowering individuals through education, language mastery, and international opportunities.</p>
      </div>
      <div class="footer-col">
        <h4>PAGES</h4>
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="aboutus.php">About Us</a></li>
          <li><a href="contactus.php">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>SUBSIDIARIES</h4>
        <ul>
          <li><a href="visa.php">A² Visa Consultation</a></li>
          <li><a href="higherEducation.php">A² Higher Education</a></li>
          <li><a href="english.php">A² English Academy</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>CONTACT</h4>
        <ul>
          <li><span>info@globalrx.com</span></li>
          <li><span>+1 (800) 000-0000</span></li>
          <li><span>Colombo, Sri Lanka</span></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Global RX Business. All rights reserved.</span>
      <div class="footer-dots">
        <div class="dot" style="background:var(--red)"></div>
        <div class="dot" style="background:var(--green)"></div>
        <div class="dot" style="background:var(--yellow)"></div>
      </div>
    </div>
  </div>
</footer>

<script>
  // Divisions dropdown
  function toggleDropdown() {
    document.getElementById('divDropdown').classList.toggle('open');
  }
  document.addEventListener('click', e => {
    const dd = document.getElementById('divDropdown');
    if (dd && !dd.contains(e.target)) dd.classList.remove('open');
  });

  // Nav shadow on scroll
  const nav = document.querySelector('nav');
  window.addEventListener('scroll', () => {
    nav.style.boxShadow = window.scrollY > 40
      ? '0 8px 32px rgba(0,0,0,0.14)'
      : '0 4px 24px rgba(0,0,0,0.06)';
  });

  // ── USER MENU DROPDOWN ──
  const navUserToggle = document.getElementById('navUserToggle');
  const navUserMenu   = document.getElementById('navUserMenu');

  if (navUserToggle && navUserMenu) {
    navUserToggle.addEventListener('click', e => {
      e.stopPropagation();
      const isOpen = navUserMenu.classList.toggle('open');
      navUserToggle.setAttribute('aria-expanded', isOpen);
    });

    // Close when clicking outside
    document.addEventListener('click', e => {
      const navUser = document.getElementById('navUser');
      if (navUser && !navUser.contains(e.target)) {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        navUserMenu.classList.remove('open');
        navUserToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }
</script>

</body>
</html>