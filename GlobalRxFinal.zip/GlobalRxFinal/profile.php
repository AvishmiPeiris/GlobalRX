<?php
session_start();

if (empty($_SESSION['signed_in']) || $_SESSION['signed_in'] !== true) {
    header('Location: signin.php');
    exit;
}

$firstName = htmlspecialchars($_SESSION['user_firstName'] ?? '', ENT_QUOTES, 'UTF-8');
$fullName  = htmlspecialchars($_SESSION['user_name']      ?? '', ENT_QUOTES, 'UTF-8');
$email     = htmlspecialchars($_SESSION['user_email']     ?? '', ENT_QUOTES, 'UTF-8');
$role      = htmlspecialchars($_SESSION['user_role']      ?? 'user', ENT_QUOTES, 'UTF-8');
$initial   = !empty($firstName) ? strtoupper($firstName[0]) : '?';
if (empty($fullName) && !empty($firstName)) $fullName = $firstName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Profile — Global RX</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --red:#e63946;--green:#2d9c5f;--yellow:#f4c430;
  --dark:#0d0d0d;--card:#1a1a1a;--border:#252525;--text:#f0f0f0;--sub:#888;
}
body{font-family:'DM Sans',sans-serif;background:var(--dark);color:var(--text);min-height:100vh;}

/* NAV — identical to dashboard */
nav{position:fixed;top:0;left:0;right:0;background:rgba(13,13,13,0.95);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:14px 48px;z-index:999;}
.nav-logo{font-size:1.1rem;font-weight:800;letter-spacing:1px;color:#fff;text-decoration:none;}
.nav-logo span{color:var(--red);}
.nav-links{display:flex;gap:28px;list-style:none;align-items:center;}
.nav-links a{text-decoration:none;color:#aaa;font-size:0.88rem;font-weight:500;transition:color .2s;}
.nav-links a:hover{color:#fff;}
.nav-dropdown{position:relative;}
.nav-dropdown-toggle{display:flex;align-items:center;gap:5px;color:#aaa;font-size:0.88rem;font-weight:500;cursor:pointer;background:none;border:none;font-family:inherit;padding:0;transition:color .2s;}
.nav-dropdown-toggle:hover{color:#fff;}
.nav-dropdown-toggle .chevron{width:14px;height:14px;display:flex;align-items:center;justify-content:center;transition:transform .25s;}
.nav-dropdown-toggle .chevron svg{width:10px;height:10px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round;}
.nav-dropdown.open .chevron{transform:rotate(180deg);}
.dropdown-menu{position:absolute;top:calc(100% + 14px);left:50%;background:#1e1e1e;border:1px solid var(--border);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.4);min-width:260px;padding:8px;opacity:0;pointer-events:none;transform:translateX(-50%) translateY(-6px);transition:opacity .2s,transform .2s;}
.nav-dropdown.open .dropdown-menu{opacity:1;pointer-events:all;transform:translateX(-50%) translateY(0);}
.dropdown-item{display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:9px;text-decoration:none;color:#ccc;font-size:0.88rem;font-weight:500;transition:background .15s,color .15s;}
.dropdown-item:hover{background:#2a2a2a;color:#fff;}
.dropdown-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
.dropdown-divider{height:1px;background:var(--border);margin:4px 8px;}
.nav-user{position:relative;}
.nav-user-toggle{display:flex;align-items:center;gap:8px;background:none;border:1.5px solid #333;border-radius:50px;padding:5px 14px 5px 6px;cursor:pointer;color:#fff;transition:border-color .2s;font-family:inherit;}
.nav-user-toggle:hover{border-color:var(--red);}
.nav-avatar{width:32px;height:32px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px;color:#fff;flex-shrink:0;}
.nav-user-name{font-size:14px;font-weight:600;color:#fff;max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.nav-chevron{display:flex;align-items:center;}
.nav-chevron svg{width:10px;height:6px;stroke:#aaa;fill:none;stroke-width:2;transition:transform .25s;}
.nav-user-toggle[aria-expanded="true"] .nav-chevron svg{transform:rotate(180deg);}
.nav-user-menu{position:absolute;right:0;top:calc(100% + 12px);width:260px;background:#1e1e1e;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,0.5);border:1px solid var(--border);padding:8px;opacity:0;transform:translateY(-8px) scale(.97);pointer-events:none;transition:opacity .22s,transform .22s;z-index:1000;}
.nav-user-menu.open{opacity:1;transform:translateY(0) scale(1);pointer-events:all;}
.num-header{display:flex;align-items:center;gap:12px;padding:10px 8px 12px;}
.num-avatar-lg{width:44px;height:44px;border-radius:50%;background:var(--red);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:17px;color:#fff;flex-shrink:0;}
.num-info{flex:1;min-width:0;}
.num-name{font-size:13px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.num-email{font-size:11px;color:#666;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.num-badge{display:inline-block;margin-top:4px;padding:2px 8px;background:#2a2a2a;color:#888;font-size:10px;font-weight:700;border-radius:50px;}
.num-divider{height:1px;background:var(--border);margin:4px 0;}
.num-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;font-size:13px;font-weight:500;color:#ccc;text-decoration:none;transition:background .15s;width:100%;background:none;border:none;cursor:pointer;text-align:left;font-family:inherit;}
.num-item svg{width:16px;height:16px;flex-shrink:0;color:#555;fill:currentColor;}
.num-item:hover{background:#252525;color:#fff;}
.num-logout{color:var(--red)!important;}
.num-logout svg{color:var(--red)!important;}
.num-logout:hover{background:#1f0a0a!important;}

/* PAGE */
.page-wrap{padding-top:72px;min-height:100vh;}

.profile-hero{
  background:linear-gradient(135deg,#0d0d0d 0%,#1a1a1a 100%);
  border-bottom:1px solid var(--border);
  padding:48px 60px 40px;
  position:relative;overflow:hidden;
}
.profile-hero::before{
  content:'PROFILE';
  position:absolute;right:-20px;top:50%;transform:translateY(-50%);
  font-family:'Playfair Display',Georgia,serif;
  font-size:clamp(5rem,12vw,9rem);font-weight:700;
  color:rgba(255,255,255,0.03);letter-spacing:4px;white-space:nowrap;pointer-events:none;
}
.profile-hero-inner{max-width:900px;margin:0 auto;display:flex;align-items:center;gap:24px;}
.profile-avatar-wrap{position:relative;}
.profile-avatar{
  width:80px;height:80px;border-radius:50%;background:var(--red);
  display:flex;align-items:center;justify-content:center;
  font-family:'Playfair Display',Georgia,serif;font-size:32px;font-weight:700;color:#fff;
  box-shadow:0 0 0 4px rgba(230,57,70,0.2);
}
.profile-hero-info{}
.profile-hero-label{color:#555;font-size:0.75rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px;}
.profile-hero-name{font-family:'Playfair Display',Georgia,serif;font-size:clamp(1.4rem,3vw,2rem);font-weight:700;color:#fff;line-height:1.2;}
.profile-hero-email{font-size:0.82rem;color:#555;margin-top:6px;}

/* BREADCRUMB */
.breadcrumb{max-width:900px;margin:0 auto;padding:20px 60px 0;display:flex;align-items:center;gap:8px;font-size:0.78rem;color:#444;}
.breadcrumb a{color:#555;text-decoration:none;transition:color .2s;}
.breadcrumb a:hover{color:#fff;}
.breadcrumb-sep{color:#333;}

/* CONTENT */
.profile-content{max-width:900px;margin:0 auto;padding:32px 60px 60px;}
.profile-grid{display:grid;grid-template-columns:1fr 1fr;gap:24px;}

/* CARDS */
.pcard{background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden;}
.pcard-header{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.pcard-header-icon{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:0.9rem;}
.pcard-header h3{font-size:0.85rem;font-weight:700;color:#fff;letter-spacing:0.5px;}
.pcard-body{padding:24px;}

/* Info rows (read-only) */
.info-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #1e1e1e;font-size:0.83rem;}
.info-row:last-child{border-bottom:none;}
.info-label{color:#555;font-weight:500;}
.info-value{color:#ccc;font-weight:500;text-align:right;max-width:60%;}
.info-value.loading{color:#333;}

/* FORM */
.form-group{margin-bottom:18px;}
.form-group:last-of-type{margin-bottom:0;}
.form-label{display:block;font-size:0.75rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#555;margin-bottom:8px;}
.form-input{
  width:100%;background:#111;border:1px solid var(--border);border-radius:10px;
  padding:11px 14px;font-size:0.88rem;font-family:inherit;color:#fff;
  outline:none;transition:border-color .2s,box-shadow .2s;
}
.form-input:focus{border-color:var(--red);box-shadow:0 0 0 3px rgba(230,57,70,0.12);}
.form-input::placeholder{color:#3a3a3a;}

/* Password strength bar */
.strength-wrap{margin-top:8px;display:none;}
.strength-bar{height:3px;border-radius:2px;background:#222;overflow:hidden;}
.strength-fill{height:100%;border-radius:2px;transition:width .3s,background .3s;}
.strength-label{font-size:0.7rem;color:#555;margin-top:4px;}

/* Submit btn */
.btn-submit{
  width:100%;background:var(--red);color:#fff;border:none;
  padding:12px;border-radius:10px;font-size:0.88rem;font-weight:700;
  font-family:inherit;cursor:pointer;margin-top:20px;
  transition:opacity .2s,transform .2s;letter-spacing:0.5px;
}
.btn-submit:hover:not(:disabled){opacity:.88;transform:translateY(-1px);}
.btn-submit:disabled{opacity:.4;cursor:not-allowed;}

/* Alert */
.alert{display:none;padding:12px 16px;border-radius:10px;font-size:0.83rem;font-weight:500;margin-top:16px;}
.alert.success{background:rgba(45,156,95,0.12);border:1px solid rgba(45,156,95,0.3);color:var(--green);}
.alert.error{background:rgba(230,57,70,0.1);border:1px solid rgba(230,57,70,0.25);color:var(--red);}

/* Full-width card */
.pcard.full{grid-column:1 / -1;}

/* Security tips */
.tip-list{display:flex;flex-direction:column;gap:10px;margin-top:4px;}
.tip{display:flex;align-items:flex-start;gap:10px;font-size:0.8rem;color:#555;}
.tip-icon{color:var(--green);flex-shrink:0;margin-top:1px;}

/* FOOTER */
footer{background:#0a0a0a;border-top:1px solid var(--border);padding:24px 60px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
footer span{font-size:0.78rem;color:#444;}
.footer-dots{display:flex;gap:8px;}
.dot{width:8px;height:8px;border-radius:50%;}

@media(max-width:800px){
  .profile-grid{grid-template-columns:1fr;}
  .pcard.full{grid-column:auto;}
  .profile-content,.breadcrumb{padding-left:24px;padding-right:24px;}
  .profile-hero{padding:36px 24px 32px;}
  nav{padding:14px 20px;}
  .nav-user-name{display:none;}
  footer{padding:20px 24px;}
}
</style>
</head>
<body>

<!-- NAV -->
<nav>
  <div class="nav-logo">GLOBAL <span>RX</span></div>
  <ul class="nav-links">
    <li><a href="index.php">Home</a></li>
    <li class="nav-dropdown" id="divDropdown">
      <button class="nav-dropdown-toggle" onclick="toggleDropdown()">
        Divisions
        <span class="chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
      </button>
      <div class="dropdown-menu">
        <a href="visa.php" class="dropdown-item"><span class="dropdown-dot" style="background:var(--red)"></span>A-Squared Visa Consultation</a>
        <div class="dropdown-divider"></div>
        <a href="higherEducation.html" class="dropdown-item"><span class="dropdown-dot" style="background:var(--green)"></span>A-Squared Higher Education</a>
        <div class="dropdown-divider"></div>
        <a href="english.php" class="dropdown-item"><span class="dropdown-dot" style="background:var(--yellow)"></span>A-Squared English Academy</a>
      </div>
    </li>
    <li><a href="aboutus.html">About Us</a></li>
    <li><a href="contactus.html">Contact Us</a></li>
  </ul>
  <div class="nav-user" id="navUser">
    <button class="nav-user-toggle" id="navUserToggle" aria-expanded="false">
      <div class="nav-avatar"><span><?= $initial ?></span></div>
      <span class="nav-user-name"><?= $firstName ?></span>
      <span class="nav-chevron"><svg viewBox="0 0 10 6"><polyline points="1,1 5,5 9,1"/></svg></span>
    </button>
    <div class="nav-user-menu" id="navUserMenu">
      <div class="num-header">
        <div class="num-avatar-lg"><span><?= $initial ?></span></div>
        <div class="num-info">
          <div class="num-name"><?= $fullName ?></div>
          <div class="num-email"><?= $email ?></div>
          <span class="num-badge"><?= ucfirst($role) ?></span>
        </div>
      </div>
      <div class="num-divider"></div>
      <a href="dashboard.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 4a1 1 0 011-1h5v6H3V4zm8-1h5a1 1 0 011 1v3h-6V3zM3 11h6v6H4a1 1 0 01-1-1v-5zm8 6v-6h6v5a1 1 0 01-1 1h-5z" fill="currentColor"/></svg>
        My Dashboard
      </a>
      <a href="profile.php" class="num-item">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M10 10a4 4 0 100-8 4 4 0 000 8zm-7 8a7 7 0 1114 0H3z" fill="currentColor"/></svg>
        Edit Profile
      </a>
      <div class="num-divider"></div>
      <a href="logout.php" class="num-item num-logout">
        <svg viewBox="0 0 20 20" width="16" height="16"><path d="M3 3h7v2H5v10h5v2H3V3zm10.293 3.293l4 4a1 1 0 010 1.414l-4 4-1.414-1.414L14.172 11H7V9h7.172l-2.293-2.293 1.414-1.414z" fill="currentColor"/></svg>
        Log Out
      </a>
    </div>
  </div>
</nav>

<div class="page-wrap">

  <!-- HERO -->
  <div class="profile-hero">
    <div class="profile-hero-inner">
      <div class="profile-avatar-wrap">
        <div class="profile-avatar"><?= $initial ?></div>
      </div>
      <div class="profile-hero-info">
        <div class="profile-hero-label">Account Settings</div>
        <div class="profile-hero-name"><?= $fullName ?></div>
        <div class="profile-hero-email"><?= $email ?></div>
      </div>
    </div>
  </div>

  <!-- BREADCRUMB -->
  <div class="breadcrumb">
    <a href="index.php">Home</a>
    <span class="breadcrumb-sep">›</span>
    <a href="dashboard.php">Dashboard</a>
    <span class="breadcrumb-sep">›</span>
    <span style="color:#777;">Edit Profile</span>
  </div>

  <!-- CONTENT -->
  <div class="profile-content">
    <div class="profile-grid">

      <!-- Account Info (read-only) -->
      <div class="pcard">
        <div class="pcard-header">
          <div class="pcard-header-icon" style="background:rgba(230,57,70,0.1);">👤</div>
          <h3>ACCOUNT INFORMATION</h3>
        </div>
        <div class="pcard-body">
          <div class="info-row">
            <span class="info-label">Full Name</span>
            <span class="info-value" id="infoFullName"><?= $fullName ?: '—' ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Email</span>
            <span class="info-value"><?= $email ?: '—' ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Role</span>
            <span class="info-value"><?= ucfirst($role) ?></span>
          </div>
          <div class="info-row">
            <span class="info-label">Status</span>
            <span class="info-value" id="infoStatus" style="color:var(--green);">Loading…</span>
          </div>
          <div class="info-row">
            <span class="info-label">Country</span>
            <span class="info-value loading" id="infoCountry">Loading…</span>
          </div>
          <div class="info-row">
            <span class="info-label">Phone</span>
            <span class="info-value loading" id="infoPhone">Loading…</span>
          </div>
          <div class="info-row">
            <span class="info-label">Date of Birth</span>
            <span class="info-value loading" id="infoDob">Loading…</span>
          </div>
          <div class="info-row">
            <span class="info-label">Member Since</span>
            <span class="info-value loading" id="infoSince">Loading…</span>
          </div>
        </div>
      </div>

      <!-- Security tips -->
      <div class="pcard">
        <div class="pcard-header">
          <div class="pcard-header-icon" style="background:rgba(45,156,95,0.1);">🛡️</div>
          <h3>SECURITY TIPS</h3>
        </div>
        <div class="pcard-body">
          <div class="tip-list">
            <div class="tip"><span class="tip-icon">✓</span><span>Use at least 8 characters with a mix of letters, numbers and symbols.</span></div>
            <div class="tip"><span class="tip-icon">✓</span><span>Never reuse passwords from other websites or services.</span></div>
            <div class="tip"><span class="tip-icon">✓</span><span>Do not share your password with anyone, including support staff.</span></div>
            <div class="tip"><span class="tip-icon">✓</span><span>Update your password regularly — at least every 6 months.</span></div>
            <div class="tip"><span class="tip-icon">✓</span><span>Log out of shared or public devices after each session.</span></div>
          </div>
        </div>
      </div>

      <!-- Change Password (full width) -->
      <div class="pcard full">
        <div class="pcard-header">
          <div class="pcard-header-icon" style="background:rgba(230,57,70,0.1);">🔑</div>
          <h3>CHANGE PASSWORD</h3>
        </div>
        <div class="pcard-body" style="max-width:480px;">
          <div class="form-group">
            <label class="form-label">Current Password</label>
            <input type="password" class="form-input" id="currentPassword" placeholder="Enter your current password" autocomplete="current-password">
          </div>
          <div class="form-group">
            <label class="form-label">New Password</label>
            <input type="password" class="form-input" id="newPassword" placeholder="Enter a new password" autocomplete="new-password" oninput="checkStrength(this.value)">
            <div class="strength-wrap" id="strengthWrap">
              <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
              <div class="strength-label" id="strengthLabel"></div>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Confirm New Password</label>
            <input type="password" class="form-input" id="confirmPassword" placeholder="Re-enter your new password" autocomplete="new-password">
          </div>

          <button class="btn-submit" id="changePasswordBtn" onclick="changePassword()">Update Password</button>
          <div class="alert" id="pwAlert"></div>
        </div>
      </div>

    </div>
  </div>
</div>

<!-- FOOTER -->
<footer>
  <span>© 2026 Global RX Business. All rights reserved.</span>
  <div class="footer-dots">
    <div class="dot" style="background:var(--red)"></div>
    <div class="dot" style="background:var(--green)"></div>
    <div class="dot" style="background:var(--yellow)"></div>
  </div>
</footer>

<!-- Firebase -->
<script type="module">
import { initializeApp }    from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getAuth, onAuthStateChanged, reauthenticateWithCredential, EmailAuthProvider, updatePassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// ── YOUR FIREBASE CONFIG ──
const firebaseConfig = {
  apiKey: "AIzaSyA8wy_aEO2Pc3uMaNPyEEN2UsoGE9nQzeU",
  authDomain: "globalrx-9085e.firebaseapp.com",
  projectId: "globalrx-9085e",
  storageBucket: "globalrx-9085e.firebasestorage.app",
  messagingSenderId: "632389557622",
  appId: "1:632389557622:web:1f5da5ef9ecb13b018ae57"
};

const app  = initializeApp(firebaseConfig);
const db   = getFirestore(app);
const auth = getAuth(app);

const userEmail = <?= json_encode($email) ?>;

// ── LOAD USER PROFILE ──
async function loadProfile() {
  try {
    const q        = query(collection(db, 'users'), where('email', '==', userEmail));
    const snapshot = await getDocs(q);
    if (snapshot.empty) return;

    const data = snapshot.docs[0].data();

    const set = (id, val, fallback='—') => {
      const el = document.getElementById(id);
      if (el) { el.textContent = val || fallback; el.classList.remove('loading'); }
    };

    set('infoStatus',  data.status  ? capitalise(data.status)  : null);
    set('infoCountry', data.country  || null);
    set('infoPhone',   data.telephone || null);
    set('infoDob',     data.dob      || null);

    if (data.status === 'active') {
      document.getElementById('infoStatus').style.color = 'var(--green)';
    } else {
      document.getElementById('infoStatus').style.color = 'var(--yellow)';
    }

    if (data.createdAt) {
      const d = data.createdAt.toDate ? data.createdAt.toDate() : new Date(data.createdAt);
      set('infoSince', d.toLocaleDateString('en-US',{month:'long',year:'numeric'}));
    } else {
      set('infoSince', null);
    }

  } catch(e) { console.error('Profile load error:', e); }
}

// ── CHANGE PASSWORD ──
window.changePassword = async function() {
  const btn      = document.getElementById('changePasswordBtn');
  const alert    = document.getElementById('pwAlert');
  const current  = document.getElementById('currentPassword').value.trim();
  const newPw    = document.getElementById('newPassword').value;
  const confirm  = document.getElementById('confirmPassword').value;

  showAlert('', '');

  if (!current || !newPw || !confirm) {
    return showAlert('error', 'Please fill in all fields.');
  }
  if (newPw.length < 8) {
    return showAlert('error', 'New password must be at least 8 characters.');
  }
  if (newPw !== confirm) {
    return showAlert('error', 'New passwords do not match.');
  }

  btn.disabled = true;
  btn.textContent = 'Updating…';

  onAuthStateChanged(auth, async (user) => {
    if (!user) {
      btn.disabled = false;
      btn.textContent = 'Update Password';
      return showAlert('error', 'Session expired. Please sign in again.');
    }
    try {
      const credential = EmailAuthProvider.credential(user.email, current);
      await reauthenticateWithCredential(user, credential);
      await updatePassword(user, newPw);

      showAlert('success', '✓ Password updated successfully!');
      document.getElementById('currentPassword').value = '';
      document.getElementById('newPassword').value     = '';
      document.getElementById('confirmPassword').value = '';
      document.getElementById('strengthWrap').style.display = 'none';

    } catch(e) {
      const msg = e.code === 'auth/wrong-password' || e.code === 'auth/invalid-credential'
        ? 'Current password is incorrect.'
        : e.code === 'auth/too-many-requests'
        ? 'Too many attempts. Please try again later.'
        : 'Something went wrong: ' + e.message;
      showAlert('error', msg);
    } finally {
      btn.disabled = false;
      btn.textContent = 'Update Password';
    }
  });
};

function showAlert(type, msg) {
  const el = document.getElementById('pwAlert');
  if (!type) { el.style.display = 'none'; return; }
  el.className = 'alert ' + type;
  el.textContent = msg;
  el.style.display = 'block';
}

function capitalise(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '—';
}

loadProfile();
</script>

<script>
// Password strength checker
function checkStrength(val) {
  const wrap  = document.getElementById('strengthWrap');
  const fill  = document.getElementById('strengthFill');
  const label = document.getElementById('strengthLabel');

  if (!val) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'block';

  let score = 0;
  if (val.length >= 8)  score++;
  if (val.length >= 12) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;

  const levels = [
    { pct:'20%', bg:'#e63946', lbl:'Very weak'  },
    { pct:'40%', bg:'#e63946', lbl:'Weak'       },
    { pct:'60%', bg:'#f4c430', lbl:'Fair'        },
    { pct:'80%', bg:'#2d9c5f', lbl:'Strong'     },
    { pct:'100%',bg:'#2d9c5f', lbl:'Very strong'},
  ];
  const lvl = levels[Math.min(score, 4)];
  fill.style.width      = lvl.pct;
  fill.style.background = lvl.bg;
  label.textContent     = lvl.lbl;
  label.style.color     = lvl.bg;
}

// Nav dropdowns
function toggleDropdown() {
  document.getElementById('divDropdown').classList.toggle('open');
}
document.addEventListener('click', e => {
  const dd = document.getElementById('divDropdown');
  if (dd && !dd.contains(e.target)) dd.classList.remove('open');
});

const navUserToggle = document.getElementById('navUserToggle');
const navUserMenu   = document.getElementById('navUserMenu');
if (navUserToggle && navUserMenu) {
  navUserToggle.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = navUserMenu.classList.toggle('open');
    navUserToggle.setAttribute('aria-expanded', isOpen);
  });
  document.addEventListener('click', e => {
    const navUser = document.getElementById('navUser');
    if (navUser && !navUser.contains(e.target)) {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      navUserMenu.classList.remove('open');
      navUserToggle.setAttribute('aria-expanded', 'false');
    }
  });
}
</script>
</body>
</html>