const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl: "http://localhost/GlobalRXv1",
    chromeWebSecurity: false,
    setupNodeEvents(on, config) {},
  },
});