<?php
// ================================================================
//  signin.php  —  GlobalRX Sign In Controller
//
//  TWO login paths:
//
//  PATH 1 — Temporary Admin Login (hardcoded)
//    Username : admin@globalrx.com
//    Password : Admin@Temp2025!
//    → Redirects to index.php (admin dashboard)
//    → Session role = 'temp_admin'
//    → The admin can then delete this and add a real account
//
//  PATH 2 — Regular Firebase User Login
//    → Authenticates via Firebase Auth (identitytoolkit API)
//    → Fetches Firestore profile
//    → If role === 'admin'  → redirects to index.php
//    → Otherwise            → redirects to home.html (student portal)
// ================================================================
ob_start();

ini_set('display_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ob_end_clean();
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

require_once __DIR__ . '/UserManager.php';

$email    = trim($_POST['email']    ?? '');
$password =       $_POST['password'] ?? '';

// Basic validation
if (!$email) {
    ob_end_clean(); http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email is required.']); exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ob_end_clean(); http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']); exit;
}
if (!$password) {
    ob_end_clean(); http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password is required.']); exit;
}

// ══════════════════════════════════════════════════════════════
//  PATH 1 — TEMPORARY ADMIN CREDENTIAL CHECK
//  Change these before going live, then delete via the dashboard
// ══════════════════════════════════════════════════════════════
define('TEMP_ADMIN_EMAIL',    'admin@globalrx.com');
define('TEMP_ADMIN_PASSWORD', 'Admin@Temp2025!');
define('TEMP_ADMIN_ACTIVE',   false);   // ← set false once real admin is added

if (TEMP_ADMIN_ACTIVE
    && strtolower($email) === strtolower(TEMP_ADMIN_EMAIL)
    && $password           === TEMP_ADMIN_PASSWORD)
{
    // Store temp admin session
    $_SESSION['user_uid']       = 'temp_admin';
    $_SESSION['user_name']      = 'Temporary Admin';
    $_SESSION['user_firstName'] = 'Temporary';
    $_SESSION['user_email']     = TEMP_ADMIN_EMAIL;
    $_SESSION['user_country']   = '';
    $_SESSION['user_role']      = 'temp_admin';
    $_SESSION['signed_in']      = true;
    $_SESSION['signed_in_at']   = time();
    $_SESSION['is_temp_admin']  = true;  // flag used by admin panel

    ob_end_clean();
    http_response_code(200);
    echo json_encode([
        'success'       => true,
        'message'       => 'Signed in as temporary admin.',
        'redirect'      => 'admin.php',
        'is_temp_admin' => true,
        'user'          => ['name' => 'Temporary Admin', 'email' => TEMP_ADMIN_EMAIL, 'role' => 'temp_admin'],
    ]);
    exit;
}

// ══════════════════════════════════════════════════════════════
//  PATH 2 — FIREBASE AUTHENTICATION
// ══════════════════════════════════════════════════════════════
$manager = new UserManager();
$result  = $manager->signIn($email, $password);

if (!$result['success']) {
    $raw = $result['message'] ?? '';
    $friendly = match(true) {
        str_contains($raw, 'EMAIL_NOT_FOUND')            => 'No account found with this email address.',
        str_contains($raw, 'INVALID_PASSWORD')           => 'Incorrect password. Please try again.',
        str_contains($raw, 'INVALID_LOGIN_CREDENTIALS')  => 'Incorrect email or password. Please try again.',
        str_contains($raw, 'USER_DISABLED')              => 'This account has been disabled. Contact support.',
        str_contains($raw, 'TOO_MANY_ATTEMPTS_TRY_LATER')=> 'Too many failed attempts. Please wait and try again.',
        str_contains($raw, 'INVALID_EMAIL')              => 'The email address is not valid.',
        str_contains($raw, 'cURL error')                 => 'Could not connect. Check your internet connection.',
        default                                          => $raw ?: 'Sign-in failed. Please check your credentials.',
    };
    ob_end_clean(); http_response_code(401);
    echo json_encode(['success' => false, 'message' => $friendly]);
    exit;
}

$user = $result['user'] ?? [];
$role = strtolower($user['role'] ?? 'user');

// Store in session
$_SESSION['user_uid']       = $user['uid']       ?? '';
$_SESSION['user_name']      = $user['name']      ?? '';
$_SESSION['user_firstName'] = $user['firstName'] ?? '';
$_SESSION['user_email']     = $user['email']     ?? $email;
$_SESSION['user_country']   = $user['country']   ?? '';
$_SESSION['user_role']      = $role;
$_SESSION['signed_in']      = true;
$_SESSION['signed_in_at']   = time();
$_SESSION['is_temp_admin']  = false;

// Admins go to admin panel, everyone else to student portal
$redirect = ($role === 'admin') ? 'admin.php' : 'index.php';

ob_end_clean();
http_response_code(200);
echo json_encode([
    'success'  => true,
    'message'  => 'Sign-in successful!',
    'redirect' => $redirect,
    'user'     => ['name' => $_SESSION['user_name'], 'email' => $_SESSION['user_email'], 'role' => $role],
]);
exit;
